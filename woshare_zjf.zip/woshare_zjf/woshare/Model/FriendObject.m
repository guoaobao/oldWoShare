//
//  FriendObject.m
//  HappyShareSE
//
//  Created by 胡波 on 13-12-12.
//  Copyright (c) 2013年 胡 波. All rights reserved.
//

#import "FriendObject.h"

@implementation FriendObject

@end
