//
//  MsgListResponse.m
//  woshare
//
//  Created by 胡波 on 14-4-2.
//  Copyright (c) 2014年 胡波. All rights reserved.
//

#import "MsgListResponse.h"

@implementation MsgListResponse

@end
