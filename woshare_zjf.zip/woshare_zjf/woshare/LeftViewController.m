//
//  LeftViewController.m
//  EasySample
//
//  Created by Marian PAUL on 12/06/12.
//  Copyright (c) 2012 Marian PAUL aka ipodishima — iPuP SARL. All rights reserved.
//

#import "LeftViewController.h"
#import "RequestManager.h"
#import "ShareSquareViewController.h"
#import "SettingViewController.h"
#import "MyFrendViewController.h"
#import "MessageViewController.h"
#import "MBProgressHUD.h"
#import "LinkViewController.h"
#import "SearchInfoViewController.h"
#import "FVKit.h"
@interface LeftViewController ()
@property (nonatomic,strong)ShareSquareViewController *ssvc;
@property (nonatomic,strong)SettingViewController *svc;
@property (nonatomic,strong)MyFrendViewController *mfvc;
@property (nonatomic,strong)MessageViewController *mvc;
@property (nonatomic,strong)LinkViewController  *cvc;
@property (nonatomic,strong)SearchInfoViewController    *sivc;
@end

@implementation LeftViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    _settingArray = [[NSArray alloc]initWithObjects:@"分享币",@"搜资源",@"消息",@"圈子",@"设置",nil];
    self.tableView.backgroundColor = [UIColor colorWithR:47 G:53 B:56 A:1];
    self.tableView.bounces = NO;
    self.tableView.separatorColor = [UIColor colorWithR:34 G:39 B:41 A:1];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView reloadData];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if ([RequestManager sharedManager].isLogined)
    {
        UIView *v = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 320,57)];
        v.backgroundColor = [UIColor clearColor];
        UIButton *logoutBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        logoutBtn.frame = CGRectMake((320 -151)/2+80, 10, 151, 57);
        [logoutBtn  setBackgroundImage:[UIImage imageNamed:@"侧边退出"] forState:UIControlStateNormal];
        [logoutBtn addTarget:self action:@selector(logout) forControlEvents:UIControlEventTouchUpInside];
        [v addSubview:logoutBtn];
        self.tableView.tableFooterView = v;
        [self.tableView reloadData];
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_settingArray count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [cell.contentView removeAllSubviews];
    UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(190, 26, 28, 28)];
    image.image = [UIImage imageNamed:[NSString stringWithFormat:@"侧边%@",[_settingArray objectAtIndex:indexPath.row]]];
    image.contentMode = UIViewContentModeScaleAspectFit;
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(230, 32, 100, 16)];
    label.text = [NSString stringWithFormat:@"%@",[_settingArray objectAtIndex:indexPath.row]];
    label.textColor = [UIColor whiteColor];
    label.backgroundColor = [UIColor clearColor];
    label.userInteractionEnabled = NO;
    image.userInteractionEnabled = NO;
    [cell.contentView addSubview:image];
    [cell.contentView addSubview:label];
    UIImageView *lineimage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 79, 320, 1)];
    lineimage.backgroundColor = [UIColor colorWithR:34 G:39 B:41 A:1];
    [cell.contentView addSubview:lineimage];
    cell.contentView.backgroundColor = [UIColor colorWithR:47 G:53 B:56 A:1];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
//        case 0:
//        {
//            if (!_ssvc) {
//                _ssvc = [[ShareSquareViewController alloc]initWithNibName:nil bundle:nil];
//            }
//            
//            UIBaseNavigationController *navi = (UIBaseNavigationController*)[[AppDelegate sharedAppDelegate].tabbar.viewControllers objectAtIndex:[AppDelegate sharedAppDelegate].indexPage];
//            if ([navi.viewControllers containsObject:_ssvc]) {
//                [[AppDelegate sharedAppDelegate].slideview popViewControllerAnimated:YES completion:^{[navi popToViewController:_ssvc animated:YES];}];
//                
//            }
//            else
//            {
//                [[AppDelegate sharedAppDelegate].slideview popViewControllerAnimated:YES completion:^{[navi pushViewController:_ssvc animated:YES];}];
//            }
//        }break;
        case 0:
        {
            if (![RequestManager sharedManager].isLogined) {
                [[AppDelegate sharedAppDelegate]showLoginFrom:self];
                return;
            }
            if (!_cvc) {
                _cvc = [[LinkViewController alloc]initWithNibName:nil bundle:nil];
                NSString *aToken = [NSString stringWithFormat:@"v=%@",[[RequestManager sharedManager].userInfo.token length]==0?@"":[RequestManager sharedManager].userInfo.token];
                _cvc.linkURL = [NSString stringWithFormat:@"%@?%@",@"http://happy.hn165.com/wap/jifen/index.php", aToken];
            }
            [[RequestManager sharedManager]startRequestWithType:kRequestTypeSetPageVisitLog withData:[NSDictionary dictionaryWithObjectsAndKeys:@"slide",@"module",@"money",@"action", nil]];
            UIBaseNavigationController *navi =  (UIBaseNavigationController*)[[AppDelegate sharedAppDelegate].tabbar.viewControllers objectAtIndex:[AppDelegate sharedAppDelegate].indexPage];
            if ([navi.viewControllers containsObject:_cvc]) {
                [[AppDelegate sharedAppDelegate].slideview popViewControllerAnimated:YES completion:^{[navi popToViewController:_cvc animated:YES];}];
                
            }
            else
            {
                [[AppDelegate sharedAppDelegate].slideview popViewControllerAnimated:YES completion:^{[navi pushViewController:_cvc animated:YES];}];
            }
        }break;
        case 1:
        {
            if (!_sivc) {
                _sivc = [[SearchInfoViewController alloc]initWithNibName:nil bundle:nil];
            }
            
            UIBaseNavigationController *navi =  (UIBaseNavigationController*)[[AppDelegate sharedAppDelegate].tabbar.viewControllers objectAtIndex:[AppDelegate sharedAppDelegate].indexPage];
            [[RequestManager sharedManager]startRequestWithType:kRequestTypeSetPageVisitLog withData:[NSDictionary dictionaryWithObjectsAndKeys:@"slide",@"module",@"searchinfo",@"action", nil]];
            if ([navi.viewControllers containsObject:_sivc]) {
                [[AppDelegate sharedAppDelegate].slideview popViewControllerAnimated:YES completion:^{[navi popToViewController:_sivc animated:YES];}];
                
            }
            else
            {
                [[AppDelegate sharedAppDelegate].slideview popViewControllerAnimated:YES completion:^{[navi pushViewController:_sivc animated:YES];}];
            }
        }break;
        case 2:
        {
            if (![RequestManager sharedManager].isLogined) {
                [[AppDelegate sharedAppDelegate]showLoginFrom:self];
                return;
            }
            if (!_mvc) {
                _mvc = [[MessageViewController alloc]initWithNibName:nil bundle:nil];
            }
            [[RequestManager sharedManager]startRequestWithType:kRequestTypeSetPageVisitLog withData:[NSDictionary dictionaryWithObjectsAndKeys:@"slide",@"module",@"message",@"action", nil]];
            
            UIBaseNavigationController *navi =  (UIBaseNavigationController*)[[AppDelegate sharedAppDelegate].tabbar.viewControllers objectAtIndex:[AppDelegate sharedAppDelegate].indexPage];
            if ([navi.viewControllers containsObject:_mvc]) {
                [[AppDelegate sharedAppDelegate].slideview popViewControllerAnimated:YES completion:^{[navi popToViewController:_mvc animated:YES];}];
                
            }
            else
            {
                [[AppDelegate sharedAppDelegate].slideview popViewControllerAnimated:YES completion:^{[navi pushViewController:_mvc animated:YES];}];
            }
        }break;
        case 3:
        {
            if (![RequestManager sharedManager].isLogined) {
                [[AppDelegate sharedAppDelegate]showLoginFrom:self];
                return;
            }
            if (!_mfvc) {
                _mfvc = [[MyFrendViewController alloc]initWithNibName:nil bundle:nil];
            }
            [[RequestManager sharedManager]startRequestWithType:kRequestTypeSetPageVisitLog withData:[NSDictionary dictionaryWithObjectsAndKeys:@"slide",@"module",@"circle",@"action", nil]];
            UIBaseNavigationController *navi =  (UIBaseNavigationController*)[[AppDelegate sharedAppDelegate].tabbar.viewControllers objectAtIndex:[AppDelegate sharedAppDelegate].indexPage];
            if ([navi.viewControllers containsObject:_mfvc]) {
                [[AppDelegate sharedAppDelegate].slideview popViewControllerAnimated:YES completion:^{[navi popToViewController:_mfvc animated:YES];}];
                
            }
            else
            {
                [[AppDelegate sharedAppDelegate].slideview popViewControllerAnimated:YES completion:^{[navi pushViewController:_mfvc animated:YES];}];
            }
        }break;
        case 4:
        {
            if (!_svc) {
                _svc = [[SettingViewController alloc]initWithNibName:nil bundle:nil];
            }
            [[RequestManager sharedManager]startRequestWithType:kRequestTypeSetPageVisitLog withData:[NSDictionary dictionaryWithObjectsAndKeys:@"slide",@"module",@"set",@"action", nil]];
            UIBaseNavigationController *navi =  (UIBaseNavigationController*)[[AppDelegate sharedAppDelegate].tabbar.viewControllers objectAtIndex:[AppDelegate sharedAppDelegate].indexPage];
            if ([navi.viewControllers containsObject:_svc]) {
                [[AppDelegate sharedAppDelegate].slideview popViewControllerAnimated:YES completion:^{[navi popToViewController:_svc animated:YES];}];
                
            }
            else
            {
                [[AppDelegate sharedAppDelegate].slideview popViewControllerAnimated:YES completion:^{[navi pushViewController:_svc animated:YES];}];
            }
        }break;
        default:
            break;
    }
}

- (SinaWeibo*)getSinaWeibo
{
    return [AppDelegate sharedAppDelegate].sinaWeibo;
}

- (GeeUploadManager *)getGeeUploadManager
{
    return [AppDelegate sharedAppDelegate].geeUploadManager;
}

#pragma mark - Request
- (void)logout
{
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeSetPageVisitLog withData:[NSDictionary dictionaryWithObjectsAndKeys:@"slide",@"module",@"logout",@"action", nil]];
    [[RequestManager sharedManager]logout];
    [Config removeLocToken];
    if ([self getSinaWeibo].isLoggedIn) {
        [[self getSinaWeibo] logOut];
    }
    if ([AppDelegate sharedAppDelegate].tencentOAuth.isSessionValid) {
        [[AppDelegate sharedAppDelegate] logOutQzone:nil];
    }
    if ([AppDelegate sharedAppDelegate].weiboApi.isAuthValid) {
        [[AppDelegate sharedAppDelegate].weiboApi cancelAuth];
    }
    [Config shareInstance].isInit = NO;
    //取消上传队列
    [[self getGeeUploadManager] stopAll];
    [Config shareInstance].hasNewMessage = 0;
    [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationLogout object:nil];
    self.tableView.tableFooterView.hidden = YES;
    [self.tableView reloadData];
    _mvc = nil;
    [[AppDelegate sharedAppDelegate].slideview popViewControllerAnimated:YES completion:^{
        [[[AppDelegate sharedAppDelegate].tabbar.viewControllers objectAtIndex:0]popToRootViewControllerAnimated:NO];
        [AppDelegate sharedAppDelegate].tabbar.selectedViewController = [[AppDelegate sharedAppDelegate].tabbar.viewControllers objectAtIndex:0];
    }];
}

- (void)sinaweiboDidLogOut:(SinaWeibo *)sinaweibo
{
    
}

- (void)tencentDidLogout
{
    
}


@end
