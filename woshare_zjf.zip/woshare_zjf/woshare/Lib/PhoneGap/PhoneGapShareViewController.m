//
//  PhoneGapShareViewController.m
//  woshare
//
//  Created by 胡波 on 14-5-4.
//  Copyright (c) 2014年 胡波. All rights reserved.
//

#import "PhoneGapShareViewController.h"
#import <TencentOpenAPI/sdkdef.h>
#import "TencentOpenAPI/QQApiInterface.h"
#import "FVKit.h"
@interface PhoneGapShareViewController ()

@end

@implementation PhoneGapShareViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [self setShareBriefTV:nil];
    [self setShareImageView:nil];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.tencentOAuth.sessionDelegate = self;
    self.wbApi.authDelegate = self;
}

- (void)viewWillDisappear:(BOOL)animated
{
    self.tencentOAuth.sessionDelegate = nil;
    self.wbApi.authDelegate = nil;
    [super viewWillDisappear:animated];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initBgImage];
    [self initNavigationBar];
    [self initBackButton];
    [self initNaviDoneBtn];
    [self hideTabbar];
    
    self.shareImageView.imageURL = [NSURL URLWithString:self.image];
    self.shareBriefTV.text = self.content;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)backAction
{
    if (_aDelegate && [_aDelegate respondsToSelector:@selector(shareRewardsCancel)]) {
        [_aDelegate shareRewardsCancel];
    }
    [super backAction];
}

-(SinaWeibo*)sinaWeibo
{
    return [AppDelegate sharedAppDelegate].sinaWeibo;
}

- (void)navigationDoneButtonAction:(id)sender
{
    switch (self.shareTag) {
        case 1:
        {
            SinaWeibo *sinaWB = [self getSinaWeibo];
            sinaWB.delegate = self;
            [self.shareBriefTV resignFirstResponder];
            if ([sinaWB isAuthValid])
            {
                [self shareAction];
            }
            else
            {
                [sinaWB logIn];
            }
        }break;
        case 2:
        {
            [self qzoneShare];
        }break;
        case 3:
        {
            if (self.wbApi.isAuthValid) {
                [self tencentShare];
            }
            else
            {
                [self showLoginTXWeibo];
            }
        }break;
        default:
            break;
    }
    
    
}

- (void)shareAction
{
    [self.sinaWeibo requestWithURL:@"statuses/upload.json"
                          params:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                                  self.shareBriefTV.text , @"status",
                                  self.shareImageView.image, @"pic", nil]
                      httpMethod:@"POST"
                        delegate:self];
}

-(void)qzoneShare
{
    NSString *url = nil;
    QQApiNewsObject *news = [[QQApiNewsObject alloc]initWithURL:[NSURL URLWithString:url?:@""]
                                                          title:self.shareBriefTV.text?:@""
                                                    description:self.shareBriefTV.text?:@""
                                                previewImageURL:[NSURL URLWithString:self.image]
                                              targetContentType:QQApiURLTargetTypeNews];
    SendMessageToQQReq *req = [SendMessageToQQReq reqWithContent:news];
    QQApiSendResultCode send = [QQApiInterface sendReq:req];
    
    [self handleSendResult:send];
}

- (void)handleSendResult:(QQApiSendResultCode)sendResult
{
    switch (sendResult)
    {
        case EQQAPIAPPNOTREGISTED:
        {
            UIAlertView *msgbox = [[UIAlertView alloc] initWithTitle:@"Error" message:@"App未注册" delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:nil];
            [msgbox show];
            
            break;
        }
        case EQQAPIMESSAGECONTENTINVALID:
        case EQQAPIMESSAGECONTENTNULL:
        case EQQAPIMESSAGETYPEINVALID:
        {
            UIAlertView *msgbox = [[UIAlertView alloc] initWithTitle:@"Error" message:@"发送参数错误" delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:nil];
            [msgbox show];
            
            break;
        }
        case EQQAPIQQNOTINSTALLED:
        {
            UIAlertView *msgbox = [[UIAlertView alloc] initWithTitle:@"Error" message:@"未安装手Q" delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:nil];
            [msgbox show];
            
            break;
        }
        case EQQAPIQQNOTSUPPORTAPI:
        {
            UIAlertView *msgbox = [[UIAlertView alloc] initWithTitle:@"Error" message:@"API接口不支持" delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:nil];
            [msgbox show];
            
            break;
        }
        case EQQAPISENDFAILD:
        {
            UIAlertView *msgbox = [[UIAlertView alloc] initWithTitle:@"Error" message:@"发送失败" delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:nil];
            [msgbox show];
            
            break;
        }
        default:
        {
            [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetCredit withData:[NSDictionary dictionaryWithObjectsAndKeys:@"share",@"action", nil]];
            break;
        }
    }
}

-(void)tencentShare
{
    UIImage *pic = self.shareImageView.image;
    NSMutableDictionary *params = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"json",@"format",
                                   self.shareBriefTV.text, @"content",
                                   pic, @"pic",
                                   nil];
    [self.wbApi requestWithParams:params apiName:@"t/add_pic" httpMethod:@"POST" delegate:self];
}

#pragma mark - SinaWeibo Delegate

- (void)sinaweiboDidLogIn:(SinaWeibo *)sinaweibo
{
    NSLog(@"sinaweiboDidLogIn userID = %@ accesstoken = %@ expirationDate = %@ refresh_token = %@", sinaweibo.userID, sinaweibo.accessToken, sinaweibo.expirationDate,sinaweibo.refreshToken);
    
    [self storeAuthData];
    [RequestManager sharedManager].userInfo.sinauid = sinaweibo.userID;
    [RequestManager sharedManager].userInfo.sinaToken = sinaweibo.accessToken;
    [RequestManager sharedManager].userInfo.sinaExpiration = sinaweibo.expirationDate;
    
    //微博登陆成功了，然后检查是否绑定过
    if ([RequestManager sharedManager].isLogined)
    {
        [self bindingSinaByUid];
    }
    else
    {
        [self checkSinaBinding];
        [self shareAction];
    }
    
}
- (void)storeAuthData
{
    SinaWeibo *sinaweibo = [self getSinaWeibo];
    
    NSDictionary *authData = [NSDictionary dictionaryWithObjectsAndKeys:
                              sinaweibo.accessToken, @"AccessTokenKey",
                              sinaweibo.expirationDate, @"ExpirationDateKey",
                              sinaweibo.userID, @"UserIDKey",
                              sinaweibo.refreshToken, @"refresh_token", nil];
    [[NSUserDefaults standardUserDefaults] setObject:authData forKey:@"SinaWeiboAuthData"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)sinaweiboLogInDidCancel:(SinaWeibo *)sinaweibo
{
    NSLog(@"sinaweiboLogInDidCancel");
}

- (void)sinaweibo:(SinaWeibo *)sinaweibo logInDidFailWithError:(NSError *)error
{
    NSLog(@"sinaweibo logInDidFailWithError %@", error);
    [self toast:@"新浪微博登录失败"];
}

- (void)sinaweibo:(SinaWeibo *)sinaweibo accessTokenInvalidOrExpired:(NSError *)error
{
    NSLog(@"sinaweiboAccessTokenInvalidOrExpired %@", error);
}

#pragma mark - SinaWeiboRequest Delegate

- (void)request:(SinaWeiboRequest *)request didFailWithError:(NSError *)error
{
    
    if ([request.url hasSuffix:@"statuses/upload.json"])
    {
        [self toast:error.description];
    }
}

- (void)request:(SinaWeiboRequest *)request didFinishLoadingWithResult:(id)result
{
    if ([request.url hasSuffix:@"statuses/upload.json"])
    {
        NSString *errorCode = [result objectForKey:@"error_code"];
        if (errorCode)
        {
            if ([errorCode intValue] == 20012)
            {
                [self toast:@"分享文字太长了哦！"];
            }
            else
            {
                [self toast:@"分享失败"];
            }
        }
        else
        {
            [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetCredit withData:[NSDictionary dictionaryWithObjectsAndKeys:@"share",@"action", nil]];
        }
    }
}

#pragma mark WeiboAuthDelegate

- (void)DidAuthRefreshed:(WeiboApi *)wbapi_
{
    [self tencentShare];
}

- (void)DidAuthRefreshFail:(NSError *)error
{
    FVLog(@"tencent weibo error = %@\n",[error localizedDescription]);
}

- (void)DidAuthFinished:(WeiboApi *)wbapi_
{
    [self tencentShare];
}

- (void)DidAuthCanceled:(WeiboApi *)wbapi_
{
    
}

- (void)DidAuthFailWithError:(NSError *)error
{
    FVLog(@"tencent weibo error = %@\n",[error localizedDescription]);
}

#pragma mark WeiboRequestDelegate

/**
 * @brief   接口调用成功后的回调
 * @param   INPUT   data    接口返回的数据
 * @param   INPUT   request 发起请求时的请求对象，可以用来管理异步请求
 * @return  无返回
 */
- (void)didReceiveRawData:(NSData *)data reqNo:(int)reqno
{
    NSString *strResult = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
    NSLog(@"result = %@",strResult);
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetCredit withData:[NSDictionary dictionaryWithObjectsAndKeys:@"share",@"action", nil]];
}
/**
 * @brief   接口调用失败后的回调
 * @param   INPUT   error   接口返回的错误信息
 * @param   INPUT   request 发起请求时的请求对象，可以用来管理异步请求
 * @return  无返回
 */
- (void)didFailWithError:(NSError *)error reqNo:(int)reqno
{
    NSString *str = [[NSString alloc] initWithFormat:@"refresh token error, errcode = %@",error.userInfo];
    NSLog(@"error = %@",str);
}


#pragma mark - Request
//新浪微博登陆成功之后检查帐号绑定状态
- (void)checkSinaBinding
{
    [self showIndicator];
    NSDictionary *dic = @{@"thirduid":self.sinaWeibo.userID,
                          @"token":self.sinaWeibo.accessToken,
                          @"expiration": [NSString stringWithFormat:@"%lf",[self.sinaWeibo.expirationDate timeIntervalSince1970]],
                          @"autologin":@"0"
                          };
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetSinaAuthinfo withData:dic];
}


- (void)bindingSinaByUid
{
    [self showIndicator];
    NSDictionary *dic = @{@"thirduid":[self getSinaWeibo].userID,
                          @"token":[self getSinaWeibo].accessToken,
                          @"expiration": [NSString stringWithFormat:@"%lf",[[self getSinaWeibo].expirationDate timeIntervalSince1970]],
                          @"autologin":@"1"
                          };
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeBindSinaUserByUid withData:dic];
}

- (void)getUsersNoteUidList
{
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetNoteList withData:nil];
}

#pragma mark request callback
-(void)webServiceRequest:(RequestType)requestType response:(id)response userData:(id)userData originalData:(id)data
{
    if (requestType==kRequestTypeBindSinaUserByUid) {
        [self shareAction];
        [self getUsersNoteUidList];
    }
    else if(requestType == kRequestTypeGetNoteList)
    {
        [Config shareInstance].myNoteUids = [NSMutableArray arrayWithArray:response];
    }
    else if(requestType == kRequestTypeGetCredit)
    {
        NSString *str;
        if ([[[data objectForKey:@"data"]objectForKey:@"addcredit"]integerValue]>0) {
            str= [NSString stringWithFormat:@"获得分享币%@个",[[data objectForKey:@"data"]objectForKey:@"addcredit"]];
        }
        else
            str = nil;
        [[AppDelegate sharedAppDelegate] creditView:@"分享成功" withCredit:str];
        if (_aDelegate && [_aDelegate respondsToSelector:@selector(confirmShare)]) {
            [_aDelegate confirmShare];
        }
        [self.navigationController popViewControllerAnimated:YES];
    }
}

-(void)webServiceRequest:(RequestType)requestType errorString:(NSString*)errorString userData:(id)userData
{
    if (requestType==kRequestTypeBindSinaUserByUid) {
        [self hideIndicator];
        [self toast:errorString];
    }
    else if(requestType == kRequestTypeGetNoteList)
    {
    }
    else if (requestType == kRequestTypeGetCredit)
    {
        [self toast:errorString];
        if (_aDelegate && [_aDelegate respondsToSelector:@selector(confirmShare)]) {
            [_aDelegate confirmShare];
        }
        [self.navigationController popViewControllerAnimated:YES];
    }
}


@end
