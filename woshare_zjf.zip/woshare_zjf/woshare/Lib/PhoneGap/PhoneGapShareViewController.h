//
//  PhoneGapShareViewController.h
//  woshare
//
//  Created by 胡波 on 14-5-4.
//  Copyright (c) 2014年 胡波. All rights reserved.
//

#import "UIBaseViewController.h"
#import "EGOImageView.h"

@protocol PhoneGapShareViewControllerDelegate <NSObject>

-(void)confirmShare;
-(void)shareRewardsCancel;

@end

@interface PhoneGapShareViewController : UIBaseViewController<SinaWeiboDelegate,SinaWeiboRequestDelegate,TencentLoginDelegate>
@property (retain,nonatomic) IBOutlet UITextView *shareBriefTV;
@property (retain,nonatomic) IBOutlet EGOImageView *shareImageView;
@property (assign,nonatomic) SinaWeibo       *sinaWeibo;
@property (nonatomic,assign) int     shareTag;
@property (nonatomic,assign) id<PhoneGapShareViewControllerDelegate> aDelegate;

@property (nonatomic, strong) NSString *content;
@property (nonatomic, strong) NSString *downUrl;
@property (nonatomic, strong) NSString *image;
@end
