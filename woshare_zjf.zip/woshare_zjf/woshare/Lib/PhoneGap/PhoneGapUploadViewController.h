//
//  PhoneGapUploadViewController.h
//  woshare
//
//  Created by 胡波 on 14-5-5.
//  Copyright (c) 2014年 胡波. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "UIBaseViewController.h"
#import "EventClassResponse.h"
#import "SinaWeibo.h"
#import "UploadData.h"

@protocol PhoneGapUploadDelegate <NSObject>

-(void)confirmUpload:(NSDictionary*)dic;

-(void)uploadCancle;

@end

@interface PhoneGapUploadViewController : UIBaseViewController<UITextViewDelegate,SinaWeiboDelegate,GeeUploadDelegate,UIActionSheetDelegate>
{
    SinaWeibo   *sinaWeibo;
    MBProgressHUD *hud;
}
@property (retain, nonatomic) IBOutlet UITextView *titleTV;
@property (retain, nonatomic) IBOutlet UITextView *briefTV;
@property (retain, nonatomic) IBOutlet UIButton *sinaBtn;
@property (retain, nonatomic) IBOutlet UITableView *uploadTableView;
@property (retain, nonatomic) IBOutlet UILabel *eventTips;
@property (retain, nonatomic) IBOutlet UILabel *eventName;
@property (retain, nonatomic) IBOutlet UILabel *tips;
@property (retain, nonatomic) IBOutlet UILabel *sinaNameLbl;
@property (retain, nonatomic) IBOutlet UILabel *textNumberLbl;
@property (retain, nonatomic) IBOutlet UIButton *agreementBtn;
@property (assign, nonatomic)id<PhoneGapUploadDelegate> aDelegate;

@property (retain, nonatomic) NSMutableArray *uploadArray;
@property (retain, nonatomic) EventResponse  *event;

- (IBAction)sinaBindBtnClick:(id)sender;
- (IBAction)lookAgreement:(id)sender;
- (IBAction)agreementBtnClick:(id)sender;


@end
