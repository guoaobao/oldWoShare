//
//  PhoneGapViewController.m
//  wisdomcloud
//
//  Created by liuleijie on 14-3-25.
//  Copyright (c) 2014年 llj. All rights reserved.
//

#import "PhoneGapViewController.h"

@interface PhoneGapViewController ()

@end

@implementation PhoneGapViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
//        self.title = @"PhoneGap";
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    [self setHidesBottomBarWhenPushed: YES];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initBackButton];
    self.webView.backgroundColor = [UIColor whiteColor];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)navBackButtonClick
{
    if (self.webView.canGoBack) {
        [self.webView goBack];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)initBackButton
{
    UIButton *searchbutton = [UIButton buttonWithType:UIButtonTypeCustom];
    [searchbutton setFrame:CGRectMake(0, 0, 22, 22)];
    [searchbutton setImage:[UIImage imageNamed:@"Nav返回"] forState:UIControlStateNormal];
    [searchbutton addTarget:self action:@selector(navBackButtonClick) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:searchbutton];
    self.navigationItem.leftBarButtonItem = item;
    
    //    _backButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd  target:self action:@selector(backAction)];
    //    self.navigationItem.leftBarButtonItem = _backButton;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [super webViewDidFinishLoad:webView];
    NSString *lJs2 = @"document.title";
    NSString *lHtml2 = [self.webView stringByEvaluatingJavaScriptFromString:lJs2];
    self.title = lHtml2;
}

@end


@implementation PhoneGapCommandDelegate

/* To override the methods, uncomment the line in the init function(s)
 in MainViewController.m
 */

#pragma mark CDVCommandDelegate implementation

- (id)getCommandInstance:(NSString*)className
{
    return [super getCommandInstance:className];
}

/*
 NOTE: this will only inspect execute calls coming explicitly from native plugins,
 not the commandQueue (from JavaScript). To see execute calls from JavaScript, see
 MainCommandQueue below
 */
- (BOOL)execute:(CDVInvokedUrlCommand*)command
{
    return [super execute:command];
}

- (NSString*)pathForResource:(NSString*)resourcepath;
{
    return [super pathForResource:resourcepath];
}

@end

@implementation PhoneGapCommandQueue

/* To override, uncomment the line in the init function(s)
 in MainViewController.m
 */
- (BOOL)execute:(CDVInvokedUrlCommand*)command
{
    return [super execute:command];
}

@end