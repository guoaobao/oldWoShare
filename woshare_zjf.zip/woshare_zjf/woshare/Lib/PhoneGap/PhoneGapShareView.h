//
//  PhoneGapShareView.h
//  woshare
//
//  Created by 胡波 on 14-5-6.
//  Copyright (c) 2014年 胡波. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol PhoneGapShareViewDelegate <NSObject>

-(void)clickAtButtonIndex:(NSInteger)index;

-(void)cancelButtonClick;

@end

@interface PhoneGapShareView : UIView
@property (nonatomic,retain)UIImageView     *backgroundView;
@property (nonatomic,retain)UIButton        *cancelButton;
@property (nonatomic,retain)NSArray         *channelArray;
@property (nonatomic,assign)id<PhoneGapShareViewDelegate>   aDelegate;
@end
