//
//  PhoneGapShareView.m
//  woshare
//
//  Created by 胡波 on 14-5-6.
//  Copyright (c) 2014年 胡波. All rights reserved.
//

#import "PhoneGapShareView.h"

@implementation PhoneGapShareView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void)setChannelArray:(NSArray *)channelArray
{
    _channelArray = channelArray;
    self.backgroundColor = [UIColor lightGrayColor];
    _cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
    if ([_channelArray count]<4) {
        self.frame = CGRectMake(0, 0, 320, 148);
        [_cancelButton setFrame:CGRectMake(14, 103, 292, 41)];
    }
    else{
        self.frame = CGRectMake(0, 0, 320, 243);
        [_cancelButton setFrame:CGRectMake(14, 197, 292, 41)];
    }
    [_cancelButton setBackgroundImage:[UIImage imageNamed:@"取消分享"] forState:UIControlStateNormal];
    [_cancelButton setTitle:@"取消分享" forState:UIControlStateNormal];
    [_cancelButton addTarget:self action:@selector(cancelAction) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_cancelButton];
    for (NSString *str in channelArray) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:[self getRect:[channelArray indexOfObject:str]]];
        [button setBackgroundImage:[self getImage:str] forState:UIControlStateNormal];
        button.tag = [channelArray indexOfObject:str];
        [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button];
    }
}

-(void)cancelAction
{
    if (_aDelegate && [_aDelegate respondsToSelector:@selector(cancelButtonClick)]) {
        [_aDelegate cancelButtonClick];
    }
}

-(void)buttonClick:(NSInteger)index
{
    if (_aDelegate && [_aDelegate respondsToSelector:@selector(clickAtButtonIndex:)]) {
        [_aDelegate clickAtButtonIndex:index];
    }
}

-(UIImage*)getImage:(NSString*)str
{
    if ([str isEqualToString:@"sina"]) {
        return [UIImage imageNamed:@"SINA分享"];
    }
    else if([str isEqualToString:@"tqq"]) {
        return [UIImage imageNamed:@"TENCENT分享"];
    }
    else if([str isEqualToString:@"wx"]) {
        return [UIImage imageNamed:@"WX好友"];
    }
    else if([str isEqualToString:@"pyq"]) {
        return [UIImage imageNamed:@"朋友圈分享"];
    }
    else if([str isEqualToString:@"qq"]) {
        return [UIImage imageNamed:@"QQ分享"];
    }
    else if([str isEqualToString:@"sms"]) {
        return [UIImage imageNamed:@"SMS分享"];
    }
    else if([str isEqualToString:@"copy"]) {
        return [UIImage imageNamed:@"URL拷贝"];
    }
    else
        return nil;
}

-(CGRect)getRect:(NSInteger)index
{
    switch (index) {
        case 0:
            return CGRectMake(12, 15, 65, 60);
            break;
        case 1:
            return CGRectMake(89, 15, 65, 60);
            break;
        case 2:
            return CGRectMake(166, 15, 65, 60);
            break;
        case 3:
            return CGRectMake(243, 15, 65, 60);
            break;
        case 4:
            return CGRectMake(12, 100, 65, 60);
            break;
        case 5:
            return CGRectMake(89, 100, 65, 60);
            break;
        case 6:
            return CGRectMake(166, 100, 65, 60);
            break;
        case 7:
            return CGRectMake(243, 100, 65, 60);
            break;
        default:
            return CGRectMake(0, 0, 0, 0);
            break;
    }
}

@end
