//
//  CDVGetDevice.h
//  wisdomcloud
//
//  Created by liuleijie on 14-4-17.
//  Copyright (c) 2014年 llj. All rights reserved.
//

#import "CDVPlugin.h"

@interface CDVGetDevice : CDVPlugin

@property (nonatomic, strong) NSString *callBackID;
@property (nonatomic, strong) CDVPluginResult *pluginResult;

-(void)getDevice:(CDVInvokedUrlCommand *)commad;

@end
