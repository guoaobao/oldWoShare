//
//  CDVWebLoginPlugin.m
//  wisdomcloud
//
//  Created by liuleijie on 14-3-25.
//  Copyright (c) 2014年 llj. All rights reserved.
//

#import "CDVWebLoginPlugin.h"
#import "AppDelegate.h"
#import "LoginViewController.h"

#define KVOUSERINFOTOKEN            @"userInfo"

@implementation CDVWebLoginPlugin
@synthesize callBackID = _callBackID;
@synthesize pluginResult =_pluginResult;


-(void)webLogin:(CDVInvokedUrlCommand *)commad
{
    self.callBackID = commad.callbackId;
    if ([RequestManager sharedManager].isLogined) {
        [self callBackWithToken:[RequestManager sharedManager].userInfo.token];
    }
    else
    {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginAction) name:kNotificationLogin object:nil];
        [[AppDelegate sharedAppDelegate] showLoginFrom:[AppDelegate sharedAppDelegate].tabbar];
    }
}

-(void)loginAction
{
    if ([RequestManager sharedManager].isLogined) {
        [self callBackWithToken:[RequestManager sharedManager].userInfo.token];
    }
}

-(void)callBackWithToken:(NSString *)aToken
{
    self.pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:[aToken stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    [self writeJavascript:[self.pluginResult toSuccessCallbackString:self.callBackID]];
}



@end
