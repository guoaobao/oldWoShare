//
//  GCUploadPlugin.m
//  woshare
//
//  Created by 胡波 on 14-5-5.
//  Copyright (c) 2014年 胡波. All rights reserved.
//

#import "GCUploadPlugin.h"
#import "AppDelegate.h"
#import <MobileCoreServices/UTCoreTypes.h>
#import "CoreMedia/CoreMedia.h"
#import "AVFoundation/AVFoundation.h"

@implementation GCUploadPlugin

-(void)upload:(CDVInvokedUrlCommand*)command
{
    self.callbackID = command.callbackId;
    NSString *stringObtainedFromJavascript = [command.arguments objectAtIndex:0];
    NSDictionary *dic = [stringObtainedFromJavascript objectFromJSONString];
    
    self.actyId = [dic objectForKey:@"actyId"];
    self.actyTitle = [dic objectForKey:@"actyTitle"];
    self.fileType = [dic objectForKey:@"fileType"];
    
    [self convertFileType:self.fileType];
    
    
}

-(void)convertFileType:(NSString*)str
{
    NSArray *b = [str componentsSeparatedByString:@"|"];
    NSMutableArray *titleArray = [[NSMutableArray alloc]initWithCapacity:0];
    if ([b count]>0) {
        for (NSString *s in b) {
            if ([s isEqualToString:@"li"]) {
                [titleArray addObject:@"相册"];
            }
            else if([s isEqualToString:@"lv"]){
                [titleArray addObject:@"本地视频"];
            }
            else if([s isEqualToString:@"si"]){
                [titleArray addObject:@"拍照片"];
            }
            else if ([s isEqualToString:@"sv"]){
                [titleArray addObject:@"拍视频"];
            }
            else
            {
                if ([titleArray count]>0) {
                    [titleArray removeAllObjects];
                }
                [titleArray addObject:@"相册"];
                [titleArray addObject:@"本地视频"];
                [titleArray addObject:@"拍照片"];
                [titleArray addObject:@"拍视频"];
                break;
            }
        }
    }
    if ([titleArray count]>0) {
        [self showActionSheet:titleArray];
    }
}

-(void)showActionSheet:(NSArray*)titleArray
{
    UIActionSheet *actionSheet ;
    switch ([titleArray count]) {
        case 1:
            actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle: nil otherButtonTitles:[titleArray objectAtIndex:0], nil];
            break;
        case 2:
            actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle: nil otherButtonTitles:[titleArray objectAtIndex:0],[titleArray objectAtIndex:1], nil];
            break;
        case 3:
            actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle: nil otherButtonTitles:[titleArray objectAtIndex:0],[titleArray objectAtIndex:1],[titleArray objectAtIndex:2], nil];
            break;
        case 4:
            actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle: nil otherButtonTitles:[titleArray objectAtIndex:0],[titleArray objectAtIndex:1],[titleArray objectAtIndex:2],[titleArray objectAtIndex:3], nil];
            break;
        default:
            break;
    }
    self.buttonArray = titleArray;
    [actionSheet showInView:[AppDelegate sharedAppDelegate].window];
}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *str = [self.buttonArray objectAtIndex:buttonIndex];
    if ([str isEqualToString:@"拍照片"])
    {
        [self getMediaFromSource:UIImagePickerControllerSourceTypeCamera mediaType:nil];
    }
    else if ([str isEqualToString:@"拍视频"])
    {
        [self getMediaFromSource:UIImagePickerControllerSourceTypeCamera mediaType:(NSString *)kUTTypeMovie];
    }
    else if ([str isEqualToString:@"相册"])
    {
        [self getMediaFromSource:UIImagePickerControllerSourceTypePhotoLibrary mediaType:(NSString*)kUTTypeImage];
    }
    else if([str isEqualToString:@"本地视频"])
    {
        [self getMediaFromSource:UIImagePickerControllerSourceTypePhotoLibrary mediaType:(NSString*)kUTTypeMovie];
    }
}

- (void)getMediaFromSource:(UIImagePickerControllerSourceType)sourceType mediaType:(NSString *)mediaType
{
    NSArray *mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:sourceType];
    if ([UIImagePickerController isSourceTypeAvailable: sourceType] && [mediaTypes count] > 0)
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        if (mediaType)
        {
            picker.mediaTypes = [NSArray arrayWithObject:mediaType];
        }
        picker.delegate = self;
        picker.allowsEditing = NO;
        picker.sourceType = sourceType;
        picker.videoMaximumDuration = 30;
		picker.videoQuality = UIImagePickerControllerQualityTypeMedium;
        [[AppDelegate sharedAppDelegate].tabbar.navigationController presentViewController:picker animated:YES completion:nil];
    }
}

#pragma mark UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
	NSString *mediaType = [info objectForKey:UIImagePickerControllerMediaType];
    
    UploadData *uploadingData;
    
    NSString *fileName = nil;
    //取图 取视频 都是有这个URL的
    if ([info objectForKey:UIImagePickerControllerReferenceURL])
    {
        NSString *url = [[info objectForKey:UIImagePickerControllerReferenceURL] absoluteString];
        //ReferenceURL的类型为NSURL 无法直接使用  必须用absoluteString 转换，照相机返回的没有UIImagePickerControllerReferenceURL，会报错
        fileName = [self createNameByURL:url];
        
        if ([mediaType isEqualToString:@"public.image"])
        {
            UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
            UIImage *rotatedImage = [UIImage rotateImage:image];
            NSData *imageData = UIImageJPEGRepresentation(rotatedImage, 1.0);
            uploadingData = [[UploadData alloc] initWithFileData:imageData fileURL:nil fileName:[self createNameByTime:@"jpg"]];
            uploadingData.coverImage = rotatedImage;
        }
        else
        {
            NSURL *fileURL = [info objectForKey:UIImagePickerControllerMediaURL];
            uploadingData = [[UploadData alloc] initWithFileData:nil fileURL:fileURL fileName:[self createNameByTime:@"mov"]];
            NSDictionary *opts = [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:NO] forKey:AVURLAssetPreferPreciseDurationAndTimingKey];
            AVURLAsset *urlAsset = [AVURLAsset URLAssetWithURL:fileURL options:opts];
            AVAssetImageGenerator *generator = [AVAssetImageGenerator assetImageGeneratorWithAsset:urlAsset];
            generator.appliesPreferredTrackTransform = YES;
            NSError *error = nil;
            CGImageRef img = [generator copyCGImageAtTime:CMTimeMake(10, 10) actualTime:NULL error:&error];
            if (!error)
            {
                UIImage *image = [UIImage rotateImage:[UIImage imageWithCGImage:img]];
                uploadingData.coverImage = image;
            }
        }
    }
    else
    {
        if ([mediaType isEqualToString:@"public.image"])
        {
            UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
            UIImage *rotatedImage = [UIImage rotateImage:image];
            NSData *imageData = UIImageJPEGRepresentation(rotatedImage, 1.0);
            uploadingData = [[UploadData alloc] initWithFileData:imageData fileURL:nil fileName:[self createNameByTime:@"jpg"]];
            //保存
            uploadingData.coverImage = rotatedImage;
            [NSThread detachNewThreadSelector:@selector(saveImage:) toTarget:self withObject:image];
        }
        else
        {
            NSURL *fileURL = [info objectForKey:UIImagePickerControllerMediaURL];
            uploadingData = [[UploadData alloc] initWithFileData:nil fileURL:fileURL fileName:[self createNameByTime:@"mov"]];
            
            //保存视频
            BOOL compatible = UIVideoAtPathIsCompatibleWithSavedPhotosAlbum([fileURL path]);
            if (compatible)
            {
                UISaveVideoAtPathToSavedPhotosAlbum([fileURL path], self, nil, NULL);
            }
            
            NSDictionary *opts = [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:NO] forKey:AVURLAssetPreferPreciseDurationAndTimingKey];
            AVURLAsset *urlAsset = [AVURLAsset URLAssetWithURL:fileURL options:opts];
            AVAssetImageGenerator *generator = [AVAssetImageGenerator assetImageGeneratorWithAsset:urlAsset];
            generator.appliesPreferredTrackTransform = YES;
            NSError *error = nil;
            CGImageRef img = [generator copyCGImageAtTime:CMTimeMake(10, 10) actualTime:NULL error:&error];
            if (!error)
            {
                UIImage *image = [UIImage rotateImage:[UIImage imageWithCGImage:img]];
                uploadingData.coverImage = image;
            }
        }
    }
    [picker dismissViewControllerAnimated:YES completion:^{
        PhoneGapUploadViewController *pvc = [[PhoneGapUploadViewController alloc]initWithNibName:nil bundle:nil];
        [pvc.uploadArray addObject:uploadingData];
        EventResponse *event = [[EventResponse alloc]init];
        event.eventid = self.actyId;
        event.title = self.actyTitle;
        pvc.event = event;
        [[AppDelegate sharedAppDelegate].tabbar.navigationController pushViewController:pvc animated:YES];
    }];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:^{
        [self uploadCancle];
    }];
}

- (void)saveImage:(UIImage *)image
{
    UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
}

- (NSString *)createNameByTime:(NSString *)ext
{
    NSDate* date = [NSDate date];
    NSString *nowTime = [NSString stringWithDate:date formater:@"yyyyMMddHHmmSS"];
    NSString *fileName = [NSString stringWithFormat:@"%@.%@",nowTime,ext];
    return fileName;
}
- (NSString *)createNameByURL:(NSString *)url
{
    NSArray *temp = [url componentsSeparatedByString:@"&ext="];
	NSString *suffix = [temp lastObject];
	temp = [[temp objectAtIndex:0] componentsSeparatedByString:@"?id="];
	NSString *name = [temp lastObject];
	name = [name stringByAppendingFormat:@".%@",suffix];
    return name;
}

-(void)confirmUpload:(NSDictionary*)dic
{
    self.pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:dic];
    [self writeJavascript:[self.pluginResult toSuccessCallbackString:self.callbackID]];
}

-(void)uploadCancle
{
    self.pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:@"0"];
    [self writeJavascript:[self.pluginResult toErrorCallbackString:self.callbackID]];
}


@end
