//
//  GEEShowShare.h
//  GeeCloudPhoneGapDemo
//
//  Created by liuleijie on 14-1-7.
//  Copyright (c) 2014年 liuleijie. All rights reserved.
//

#import "CDVPlugin.h"
#import "AppDelegate.h"

@interface GEEShowShare : CDVPlugin <WXManagerDelegate>
{
}
@property (nonatomic, copy) NSString    *callbackID;
@property (nonatomic, retain) CDVPluginResult *pluginResult;
-(void)showActionShare:(CDVInvokedUrlCommand*)command;


@end
