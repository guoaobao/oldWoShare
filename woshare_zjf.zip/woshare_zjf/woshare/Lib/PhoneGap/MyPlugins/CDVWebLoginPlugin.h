//
//  CDVWebLoginPlugin.h
//  wisdomcloud
//
//  Created by liuleijie on 14-3-25.
//  Copyright (c) 2014年 llj. All rights reserved.
//

#import "CDVPlugin.h"

@interface CDVWebLoginPlugin : CDVPlugin


@property (nonatomic, strong) NSString *callBackID;
@property (nonatomic, strong) CDVPluginResult *pluginResult;

-(void)webLogin:(CDVInvokedUrlCommand *)commad;

@end
