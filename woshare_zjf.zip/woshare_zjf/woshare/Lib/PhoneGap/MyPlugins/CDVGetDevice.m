//
//  CDVGetDevice.m
//  wisdomcloud
//
//  Created by liuleijie on 14-4-17.
//  Copyright (c) 2014年 llj. All rights reserved.
//

#import "CDVGetDevice.h"

#import "URLDefine.h"
#import "DataSource.h"
#import "FVConstant.h"

#import "JSONKit.h"
#import "RequestManager.h"
@implementation CDVGetDevice


-(void)getDevice:(CDVInvokedUrlCommand *)commad
{
    self.callBackID = commad.callbackId;
    NSMutableDictionary *tempDictionary = [NSMutableDictionary dictionary];
    [tempDictionary setObject:@"1" forKey:@"appid"];
    [tempDictionary setObject:@"ios" forKey:@"clienttype"];
    [tempDictionary setObject:sourced forKey:@"source"];
    [tempDictionary setObject:devID forKey:@"deviceid"];
    [tempDictionary setObject:FVBundleVersion() forKey:@"version"];
    [tempDictionary setObject:[RequestManager sharedManager].userInfo.token?[RequestManager sharedManager].userInfo.token:@"" forKey:@"v"];
    [tempDictionary setObject:[RequestManager sharedManager].userInfo.username?[RequestManager sharedManager].userInfo.username:@"" forKey:@"nickname"];
    [tempDictionary setObject:[RequestManager sharedManager].userInfo.mobile?[RequestManager sharedManager].userInfo.mobile:@"" forKey:@"mob"];
    [tempDictionary setObject:[[[NSBundle mainBundle] infoDictionary] objectForKey:@"versionNumber"] forKey:@"vnum"];
    [tempDictionary setObject:[RequestManager sharedManager].userInfo.usertype?[RequestManager sharedManager].userInfo.usertype:@"" forKey:@"usertype"];
    
    NSString *tempString = [tempDictionary JSONString];
    self.pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:[tempString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    self.pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:tempDictionary];
    [self writeJavascript:[self.pluginResult toSuccessCallbackString:self.callBackID]];
    
}


@end
