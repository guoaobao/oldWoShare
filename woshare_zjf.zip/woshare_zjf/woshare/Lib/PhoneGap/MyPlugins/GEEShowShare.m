//
//  GEEShowShare.m
//  GeeCloudPhoneGapDemo
//
//  Created by liuleijie on 14-1-7.
//  Copyright (c) 2014年 liuleijie. All rights reserved.
//

#import "GEEShowShare.h"
#import "JSONKit.h"
#import "AppDelegate.h"
#import "PhoneGapShareViewController.h"
#import "PhoneGapShareView.h"
#import <AddressBook/AddressBook.h>
#import <MessageUI/MFMessageComposeViewController.h>
@interface GEEShowShare () <PhoneGapShareViewControllerDelegate,PhoneGapShareViewDelegate,MFMessageComposeViewControllerDelegate>
{
    BOOL    isShow;
    PhoneGapShareView   *shareView;
    NSInteger   shareViewHeight;
    CGRect      showRect;
    CGRect      hideRect;
}
@property (nonatomic, strong) NSString *content;
@property (nonatomic, strong) NSString *image;
@property (nonatomic, strong) NSString *channel;
@property (nonatomic, strong) NSArray  *channelArray;
@end

@implementation GEEShowShare
@synthesize callbackID = _callbackID;
@synthesize pluginResult = _pluginResult;

-(void)showActionShare:(CDVInvokedUrlCommand *)command
{
    self.callbackID = command.callbackId;
    
    NSString *stringObtainedFromJavascript = [command.arguments objectAtIndex:0];
    
    NSDictionary *dic = [stringObtainedFromJavascript objectFromJSONString];

    self.content = [dic objectForKey:@"content"];
    self.image = [dic objectForKey:@"image"];
    self.channel = [dic objectForKey:@"channel"];
    
    NSArray *b = [self.channel componentsSeparatedByString:@"|"];

    if ([[b objectAtIndex:0] isEqualToString:@"all"]) {
        _channelArray = [NSArray arrayWithObjects:@"sina",@"tqq",@"qq",@"wx",@"pyq",@"sms",@"copy", nil];
    }
    else
        _channelArray = [NSArray arrayWithArray:b];
    
    shareView = [[PhoneGapShareView alloc]init];
    shareView.channelArray = _channelArray;
    shareView.aDelegate = self;
    shareViewHeight = shareView.frame.size.height;
    showRect = CGRectMake(0, kWindowFrame.size.height-shareViewHeight, 320, shareViewHeight);
    hideRect = CGRectMake(0, kWindowFrame.size.height, 320, shareViewHeight);
    [shareView setFrame:hideRect];
    [[AppDelegate sharedAppDelegate].window addSubview:shareView];
    [self snsThreeShareAction];
}

-(void)confirmShare
{
    self.pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:@"1"];
    [self writeJavascript:[self.pluginResult toSuccessCallbackString:self.callbackID]];
    [[WXManager shareInstance]removeWxManagerDelegate];
}

-(void)shareRewardsCancel
{
    self.pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:@"0"];
    [self writeJavascript:[self.pluginResult toErrorCallbackString:self.callbackID]];
    [[WXManager shareInstance]removeWxManagerDelegate];
}

#pragma mark -
#pragma mark - share block
#pragma mark -

-(void)snsThreeShareAction
{
    if (isShow) {
        return;
    }
    [[AppDelegate sharedAppDelegate].window bringSubviewToFront:shareView];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationDelegate:self];
    [shareView setFrame:showRect];
    isShow = YES;
    [UIView commitAnimations];
    [[WXManager shareInstance]setWxManagerDelegate:self];
}

-(void)cancelShare
{
    [self cancelShare];
    [self snsThreeDismissAction];
}

-(void)snsThreeDismissAction
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [shareView setFrame:hideRect];
    isShow = NO;
    [UIView commitAnimations];
}

-(void)clickAtButtonIndex:(NSInteger)index
{
    NSString *str = [self.channelArray objectAtIndex:index];
    if ([str isEqualToString:@"sina"]) {
        [self sinaChoose];
    }
    else if([str isEqualToString:@"tqq"]) {
        [self tencentChoose];
    }
    else if([str isEqualToString:@"wx"]) {
        [self wechatChoose];
    }
    else if([str isEqualToString:@"pyq"]) {
        [self timeLineChoose];
    }
    else if([str isEqualToString:@"qq"]) {
        [self qqChoose];
    }
    else if([str isEqualToString:@"sms"]) {
        
    }
    else if([str isEqualToString:@"copy"]) {
    }
}

-(void)cancelButtonClick
{
    [self snsThreeDismissAction];
    [self shareRewardsCancel];
}

-(void)tencentChoose
{
    [self snsThreeDismissAction];
    PhoneGapShareViewController *pvc = [[PhoneGapShareViewController alloc]initWithNibName:nil bundle:nil];
    pvc.shareTag = 3;
    pvc.content = self.content;
    pvc.image = self.image;
    pvc.aDelegate = self;
    [[AppDelegate sharedAppDelegate].tabbar.navigationController pushViewController:pvc animated:YES];
}

-(void)qqChoose
{
    [self snsThreeDismissAction];
    PhoneGapShareViewController *pvc = [[PhoneGapShareViewController alloc]initWithNibName:nil bundle:nil];
    pvc.shareTag = 2;
    pvc.content = self.content;
    pvc.image = self.image;
    pvc.aDelegate = self;
    [[AppDelegate sharedAppDelegate].tabbar.navigationController pushViewController:pvc animated:YES];
}

-(void)sinaChoose
{
    [self snsThreeDismissAction];
    PhoneGapShareViewController *pvc = [[PhoneGapShareViewController alloc]initWithNibName:nil bundle:nil];
    pvc.shareTag = 1;
    pvc.content = self.content;
    pvc.image = self.image;
    pvc.aDelegate = self;
    [[AppDelegate sharedAppDelegate].tabbar.navigationController pushViewController:pvc animated:YES];
}

-(void)timeLineChoose
{
    
    if (![[WXManager shareInstance] isWXAppInstalled]) {
//        [self toast:@"微信尚未安装，请安装后重试"];
        return;
    }
    [self snsThreeDismissAction];
    [[WXManager shareInstance] setScene:WXSceneTimeline];
    //    NSString *content = [NSString stringWithFormat:@"%@ %@%@",[Config shareInstance].sinaShareContent,[Config shareInstance].sinaShareInfoLink,self.info._id];
    //    UIImage *newsImage = [UIImage imageFromURLString:[self.info getSmallestImageURLString]];
    //    [[WXManager shareInstance] sendNewsContent:content title:self.info.title thumbImage:newsImage webPageUrl:[NSString stringWithFormat:@"%@%@",[Config shareInstance].sinaShareInfoLink,self.info._id]];
    [[WXManager shareInstance] sendTextContent:self.content];
    [self snsThreeDismissAction];
}

-(void)wechatChoose
{
    if (![[WXManager shareInstance] isWXAppInstalled]) {
//        [self toast:@"微信尚未安装，请安装后重试"];
        return;
    }
    [self snsThreeDismissAction];
    [[WXManager shareInstance] setScene:WXSceneSession];
//    NSString *content = [NSString stringWithFormat:@"%@ %@%@",[Config shareInstance].sinaShareContent,[Config shareInstance].sinaShareInfoLink,self.info._id];
//    UIImage *newsImage = [UIImage imageFromURLString:[self.info getSmallestImageURLString]];
//    [[WXManager shareInstance] sendNewsContent:content title:self.info.title thumbImage:newsImage webPageUrl:[NSString stringWithFormat:@"%@%@",[Config shareInstance].sinaShareInfoLink,self.info._id]];
    [[WXManager shareInstance] sendTextContent:self.content];
    [self snsThreeDismissAction];
}

-(void)sendContentErrorCode:(enum WXErrCode)errCode erroeStr:(NSString *)errorStr scene:(enum WXScene)ascene
{
    if (errCode == 0) {
        [self confirmShare];
        [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetCredit withData:[NSDictionary dictionaryWithObjectsAndKeys:@"share",@"action", nil]];
    }
    else
    {
        [self cancelShare];
    }
}

- (void)smsShare
{
    [self snsThreeDismissAction];
    ABAddressBookRef addressBook = nil;
    
    __block BOOL accessGranted = NO;
    if ([[UIDevice currentDevice].systemVersion floatValue] >= 6.0)
    {
        CFErrorRef error;
        addressBook = ABAddressBookCreateWithOptions(NULL, &error);
        //等待同意后向下执行
        dispatch_semaphore_t sema = dispatch_semaphore_create(0);
        ABAddressBookRequestAccessWithCompletion(addressBook, ^(bool granted, CFErrorRef error)
                                                 {
                                                     accessGranted = granted;
                                                     dispatch_semaphore_signal(sema);
                                                 });
        dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
        //                dispatch_release(sema);
    }
    else
    {
        accessGranted = YES;
    }
    if (accessGranted) {
        Class messageClass = (NSClassFromString(@"MFMessageComposeViewController"));
        
        if (messageClass != nil && [messageClass canSendText])
        {
            NSString *content ;
            content = self.content;
            MFMessageComposeViewController *picker = [[MFMessageComposeViewController alloc] init];
            picker.messageComposeDelegate = self;
            picker.body = content;
            [[AppDelegate sharedAppDelegate].tabbar.navigationController presentViewController:picker  animated:YES completion:nil];
        }
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"授权提示"
                                                        message:LJSMSALERTTEXT
                                                       delegate:nil
                                              cancelButtonTitle:nil
                                              otherButtonTitles:@"确定", nil];
        alert.tag = 100202;
        [alert show];
    }
}

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    [[AppDelegate sharedAppDelegate].tabbar.navigationController dismissViewControllerAnimated:YES completion:nil];
    if (result == MessageComposeResultCancelled)
        [self shareRewardsCancel];
    else if (result == MessageComposeResultSent)
        [self confirmShare];
    else
        [self shareRewardsCancel];
}

-(void)copyLinkAction
{
    [self snsThreeDismissAction];
    [[UIPasteboard generalPasteboard] setPersistent:YES];
    [[UIPasteboard generalPasteboard] setValue:self.content forPasteboardType:[UIPasteboardTypeListString objectAtIndex:0]];
}


@end
