//
//  GCUploadPlugin.h
//  woshare
//
//  Created by 胡波 on 14-5-5.
//  Copyright (c) 2014年 胡波. All rights reserved.
//

#import "CDVPlugin.h"
#import "PhoneGapUploadViewController.h"
@interface GCUploadPlugin : CDVPlugin <UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,PhoneGapUploadDelegate>
@property (nonatomic, copy) NSString    *callbackID;
@property (nonatomic, retain) CDVPluginResult *pluginResult;
@property (nonatomic, strong) NSString *actyId;
@property (nonatomic, strong) NSString *actyTitle;
@property (nonatomic, strong) NSString *fileType;
@property (nonatomic, strong) NSArray *buttonArray;

-(void)upload:(CDVInvokedUrlCommand*)command;
@end
