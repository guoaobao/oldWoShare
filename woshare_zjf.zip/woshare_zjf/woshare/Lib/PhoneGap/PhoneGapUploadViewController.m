//
//  PhoneGapUploadViewController.m
//  woshare
//
//  Created by 胡波 on 14-5-5.
//  Copyright (c) 2014年 胡波. All rights reserved.
//

#import "PhoneGapUploadViewController.h"
#import "EGOImageButton.h"
#import "EventClassResponse.h"
#import "EventResponse.h"
#import "GeeUploadParam.h"
#import "UploadData.h"
#import "GeeUploadManager.h"
#import "SinaWeibo.h"
#import "AppDelegate.h"
#import "AgreementViewController.h"
#import <MobileCoreServices/UTCoreTypes.h>
#import "CoreMedia/CoreMedia.h"
#import "AVFoundation/AVFoundation.h"
#import "InfoListResponse.h"
#import "FVKit.h"
#define kSelectedViewTag 1000

@interface PhoneGapUploadViewController () <UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (nonatomic,assign)kInfoType   type;
@end

@implementation PhoneGapUploadViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        _uploadArray = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.briefTV.text = kDefaultUploadBrief;
    self.titleTV.text = @"添加一个有吸引力的标题";
    self.titleTV.tag = 10011;
    sinaWeibo = [self getSinaWeibo];
    [self initBgImage];
    [self initNavigationBar];
    [self getEventCategory];
    [self initNaviDoneBtn];
    [self initBackButton];
    [self hideTabbar];
    
    self.agreementBtn.selected = [Config getAgreementSetting];
    [self.navigationItem.rightBarButtonItem setEnabled:self.agreementBtn.selected];
    if (!self.event)
    {
        self.eventName.hidden = YES;
        self.eventTips.hidden = YES;
        self.tips.frame = CGRectMake(self.tips.frame.origin.x, self.tips.frame.origin.y - 26, self.tips.frame.size.width, self.tips.frame.size.height);
    }
    else
    {
        self.eventName.text = self.event.title;
    }
    
    if ([[RequestManager sharedManager].userInfo.sinauid length]>0)
    {
        [self getSinaUserInfo];
    }
    
    self.title = @"资源上传";
    [self.uploadTableView reloadData];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self getGeeUploadManager].delegate = self;
    [AppDelegate sharedAppDelegate].indexPage = 2;
}

-(void)viewWillDisappear:(BOOL)animated
{
    [self getGeeUploadManager].delegate = nil;
    sinaWeibo.delegate = nil;
    [super viewWillDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setBriefTV:nil];
    [self setSinaBtn:nil];
    [self setEventTips:nil];
    [self setEventName:nil];
    [self setTips:nil];
    [self setSinaNameLbl:nil];
    [self setTextNumberLbl:nil];
    [self setAgreementBtn:nil];
    [super viewDidUnload];
}

#pragma mark - IBAction
-(void)backAction
{
    if (_aDelegate && [_aDelegate respondsToSelector:@selector(uploadCancle)]) {
        [_aDelegate uploadCancle];
    }
    [super backAction];
}

- (IBAction)sinaBindBtnClick:(id)sender
{
    sinaWeibo.delegate = self;
    if (self.sinaBtn.selected)
    {
        self.sinaBtn.selected = NO;
        self.sinaNameLbl.textColor = [UIColor blackColor];
    }
    else
    {
        if (sinaWeibo.isLoggedIn) {
            self.sinaBtn.selected = YES;
        }
        else
            [sinaWeibo logIn];
    }
}

- (IBAction)lookAgreement:(id)sender
{
    AgreementViewController *agreeVC = [[AgreementViewController alloc] initWithNibName:@"AgreementViewController" bundle:nil];
    [self.navigationController pushViewController:agreeVC animated:YES];
}

- (IBAction)agreementBtnClick:(id)sender
{
    self.agreementBtn.selected = !self.agreementBtn.selected;
    [Config setAgreementSetting:self.agreementBtn.selected];
    [self.navigationItem.rightBarButtonItem setEnabled:self.agreementBtn.selected];
}


- (void)navigationDoneButtonAction:(id)sender
{
    [self.briefTV resignFirstResponder];
    [self.titleTV resignFirstResponder];
    if (![RequestManager sharedManager].isLogined)
    {
        [[AppDelegate sharedAppDelegate] showLoginFrom:self];
        return;
    }
    if (!self.agreementBtn.selected)
    {
        [self showTips:kBundleName message:@"请查看并同意用户许可协议再上传"];
        return;
    }
    
    if ([self.titleTV.text isEqualToString:@"添加一个有吸引力的标题"] || self.briefTV.text.length == 0)
    {
        [self toast:@"标题不能为空"];
        return;
    }
    
    if ([self.briefTV.text isEqualToString:kDefaultUploadBrief] || self.briefTV.text.length < 2 || self.briefTV.text.length > 70)
    {
        [self toast:@"资源描述需为2－70个字符"];
        return;
    }
    
    if ([RequestManager sharedManager].currentReachabilityStatus == NotReachable)
    {
        [self toast:@"没有可用网络"];
        return;
    }
    if ([Config getDeafultTransferNerWork] == kTransferNetworkWifi && [RequestManager sharedManager].currentReachabilityStatus == ReachableViaWWAN)
    {
        //        SetNetWorkViewController *setNetVC = [[SetNetWorkViewController alloc] initWithNibName:@"SetNetWorkViewController" bundle:nil];
        //        setNetVC.bShowTips = YES;
        //        [self.navigationController pushViewController:setNetVC animated:YES];
        return;
    }
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeSetPageVisitLog withData:[NSDictionary dictionaryWithObjectsAndKeys:@"upload",@"module",@"submit",@"action", nil]];
    
    if ([self.uploadArray count]==0) {
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:self.titleTV.text,@"title",self.briefTV.text,@"brief",[NSString stringWithFormat:@"%d",kInfoTypeDocument],@"ft",self.event==nil?nil:self.event.eventid,@"eventid",nil];
        [[RequestManager sharedManager]startRequestWithType:kRequestTypeAddInfo withData:dic];
        return;
    }
    GeeUploadParam* param = [GeeUploadParam alloc];
    param.uid = [RequestManager sharedManager].userInfo.uid;
    param.brief = self.briefTV.text;
    NSMutableArray *array = [[NSMutableArray alloc]initWithCapacity:0];
    param.fileinfos =array;
    param.title = self.titleTV.text;
    for (UploadData *data in self.uploadArray) {
        GeeUploadFileInfo *info = [[GeeUploadFileInfo alloc]init];
        info.filename = data.fileName;
        info.image = [UIImage imageWithData:data.fileData];
        info.videourl = data.videoURL;
        [param.fileinfos addObject:info];
    }
    _type = kInfoTypePicture;
    for (GeeUploadFileInfo *info in param.fileinfos) {
        if (info.videourl.absoluteString.length>0) {
            _type = kInfoTypeMovie;
            break;
        }
    }
    
    EventResponse *event = self.event;
    if (event)
    {
        param.eventid = event.eventid;
        param.eventtitle = event.title;
    }
    else
    {
        param.eventid = @"";
        param.eventtitle = @"";
    }
    if (self.sinaBtn.selected)
    {
        param.sinaShare = YES;
    }
    else
    {
        param.sinaShare = NO;
    }
    
    [[self getGeeUploadManager] addTask:param];
    [Config shareInstance].uploadingData = nil;
    
    if (!hud)
    {
        MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:[AppDelegate sharedAppDelegate].window];
        hud = HUD;
        hud.mode = MBProgressHUDModeAnnularDeterminate;
    }
    [self.view addSubview:hud];
	[hud show:YES];
}

-(void)takeMorePhoto
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle: nil otherButtonTitles:@"拍照片",@"拍视频",@"相册",@"本地视频", nil];
    [actionSheet showInView:[AppDelegate sharedAppDelegate].window];
}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)
    {
        [self getMediaFromSource:UIImagePickerControllerSourceTypeCamera mediaType:nil];
    }
    
    if (buttonIndex == 1)
    {
        [self getMediaFromSource:UIImagePickerControllerSourceTypeCamera mediaType:(NSString *)kUTTypeMovie];
    }
    
    if (buttonIndex == 2)
    {
        [self getMediaFromSource:UIImagePickerControllerSourceTypePhotoLibrary mediaType:(NSString*)kUTTypeImage];
    }
    else if(buttonIndex == 3)
    {
        [self getMediaFromSource:UIImagePickerControllerSourceTypePhotoLibrary mediaType:(NSString*)kUTTypeMovie];
    }
}

- (void)getMediaFromSource:(UIImagePickerControllerSourceType)sourceType mediaType:(NSString *)mediaType
{
    NSArray *mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:sourceType];
    if ([UIImagePickerController isSourceTypeAvailable: sourceType] && [mediaTypes count] > 0)
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        if (mediaType)
        {
            picker.mediaTypes = [NSArray arrayWithObject:mediaType];
        }
        picker.delegate = self;
        picker.allowsEditing = NO;
        picker.sourceType = sourceType;
        picker.videoMaximumDuration = 30;
		picker.videoQuality = UIImagePickerControllerQualityTypeMedium;
        [[AppDelegate sharedAppDelegate].tabbar.navigationController presentViewController:picker animated:YES completion:nil];
    }
}

#pragma mark UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
	NSString *mediaType = [info objectForKey:UIImagePickerControllerMediaType];
    
    UploadData *uploadingData;
    
    NSString *fileName = nil;
    //取图 取视频 都是有这个URL的
    if ([info objectForKey:UIImagePickerControllerReferenceURL])
    {
        NSString *url = [[info objectForKey:UIImagePickerControllerReferenceURL] absoluteString];
        //ReferenceURL的类型为NSURL 无法直接使用  必须用absoluteString 转换，照相机返回的没有UIImagePickerControllerReferenceURL，会报错
        fileName = [self createNameByURL:url];
        
        if ([mediaType isEqualToString:@"public.image"])
        {
            UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
            UIImage *rotatedImage = [UIImage rotateImage:image];
            NSData *imageData = UIImageJPEGRepresentation(rotatedImage, 1.0);
            uploadingData = [[UploadData alloc] initWithFileData:imageData fileURL:nil fileName:[self createNameByTime:@"jpg"]];
            uploadingData.coverImage = rotatedImage;
        }
        else
        {
            NSURL *fileURL = [info objectForKey:UIImagePickerControllerMediaURL];
            uploadingData = [[UploadData alloc] initWithFileData:nil fileURL:fileURL fileName:[self createNameByTime:@"mov"]];
            NSDictionary *opts = [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:NO] forKey:AVURLAssetPreferPreciseDurationAndTimingKey];
            AVURLAsset *urlAsset = [AVURLAsset URLAssetWithURL:fileURL options:opts];
            AVAssetImageGenerator *generator = [AVAssetImageGenerator assetImageGeneratorWithAsset:urlAsset];
            generator.appliesPreferredTrackTransform = YES;
            NSError *error = nil;
            CGImageRef img = [generator copyCGImageAtTime:CMTimeMake(10, 10) actualTime:NULL error:&error];
            if (!error)
            {
                UIImage *image = [UIImage rotateImage:[UIImage imageWithCGImage:img]];
                uploadingData.coverImage = image;
            }
        }
    }
    else
    {
        if ([mediaType isEqualToString:@"public.image"])
        {
            UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
            UIImage *rotatedImage = [UIImage rotateImage:image];
            NSData *imageData = UIImageJPEGRepresentation(rotatedImage, 1.0);
            uploadingData = [[UploadData alloc] initWithFileData:imageData fileURL:nil fileName:[self createNameByTime:@"jpg"]];
            //保存
            uploadingData.coverImage = rotatedImage;
            [NSThread detachNewThreadSelector:@selector(saveImage:) toTarget:self withObject:image];
        }
        else
        {
            NSURL *fileURL = [info objectForKey:UIImagePickerControllerMediaURL];
            uploadingData = [[UploadData alloc] initWithFileData:nil fileURL:fileURL fileName:[self createNameByTime:@"mov"]];
            
            //保存视频
            BOOL compatible = UIVideoAtPathIsCompatibleWithSavedPhotosAlbum([fileURL path]);
            if (compatible)
            {
                UISaveVideoAtPathToSavedPhotosAlbum([fileURL path], self, nil, NULL);
            }
            
            NSDictionary *opts = [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:NO] forKey:AVURLAssetPreferPreciseDurationAndTimingKey];
            AVURLAsset *urlAsset = [AVURLAsset URLAssetWithURL:fileURL options:opts];
            AVAssetImageGenerator *generator = [AVAssetImageGenerator assetImageGeneratorWithAsset:urlAsset];
            generator.appliesPreferredTrackTransform = YES;
            NSError *error = nil;
            CGImageRef img = [generator copyCGImageAtTime:CMTimeMake(10, 10) actualTime:NULL error:&error];
            if (!error)
            {
                UIImage *image = [UIImage rotateImage:[UIImage imageWithCGImage:img]];
                uploadingData.coverImage = image;
            }
        }
    }
    if (uploadingData!=nil) {
        [_uploadArray addObject:uploadingData];
        [self.uploadTableView reloadData];
    }
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)saveImage:(UIImage *)image
{
    UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
}

- (NSString *)createNameByTime:(NSString *)ext
{
    NSDate* date = [NSDate date];
    NSString *nowTime = [NSString stringWithDate:date formater:@"yyyyMMddHHmmSS"];
    NSString *fileName = [NSString stringWithFormat:@"%@.%@",nowTime,ext];
    return fileName;
}
- (NSString *)createNameByURL:(NSString *)url
{
    NSArray *temp = [url componentsSeparatedByString:@"&ext="];
	NSString *suffix = [temp lastObject];
	temp = [[temp objectAtIndex:0] componentsSeparatedByString:@"?id="];
	NSString *name = [temp lastObject];
	name = [name stringByAppendingFormat:@".%@",suffix];
    return name;
}


#pragma mark - UITableView Delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 90;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.uploadArray count] == 0 ? 1 :[self.uploadArray count] / 3 + 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellId = @"Cell";
    UITableViewCell *cells = [tableView dequeueReusableCellWithIdentifier:CellId];
    if (cells == nil)
    {
        cells = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellId];
        cells.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [cells.contentView removeAllSubviews];
    if ([self.uploadArray count]==0) {
        CGRect rect = [self getResourceRect:0];
        UIButton *addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [addBtn setFrame:rect];
        [addBtn setBackgroundImage:[UIImage imageNamed:@"增加图片"] forState:UIControlStateNormal];
        [addBtn addTarget:self action:@selector(takeMorePhoto) forControlEvents:UIControlEventTouchUpInside];
        [cells.contentView addSubview:addBtn];
    }
    else
    {
        int totalCount = [self.uploadArray count];
        int count = (indexPath.row == (totalCount -1)/3 ? (totalCount % 3 == 0? 3: totalCount % 3) : 3);
        if (indexPath.row*3==totalCount) {
            count=0;
        }
        for (int i = 0 ; i < count; ++i)
        {
            UploadData *data = [self.uploadArray objectAtIndex:(indexPath.row *3+ i)];
            UIButton *resourceBtn = [[UIButton alloc] initWithFrame:[self getResourceRect:i]];
            resourceBtn.tag = indexPath.row *3 + i;
            //            [resourceBtn addTarget:self action:@selector(resourceClicked:) forControlEvents:UIControlEventTouchUpInside];
            [resourceBtn setBackgroundImage:data.coverImage forState:UIControlStateNormal];
            CALayer *layer = [resourceBtn layer];
            [layer setMasksToBounds:YES];
            [layer setCornerRadius:3.0];
            
            
            UIButton *delBtn = [[UIButton alloc] initWithFrame:[self getDeleteRect:i]];
            delBtn.tag = indexPath.row *3 + i;
            [delBtn addTarget:self action:@selector(deleteAction:) forControlEvents:UIControlEventTouchUpInside];
            [delBtn setBackgroundImage:[UIImage imageNamed:@"减少图片"] forState:UIControlStateNormal];
            
            [cells.contentView addSubview:resourceBtn];
            [cells.contentView addSubview:delBtn];
        }
        if (count<=2) {
            CGRect rect = [self getResourceRect:count];
            UIButton *addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            [addBtn setFrame:rect];
            [addBtn setBackgroundImage:[UIImage imageNamed:@"增加图片"] forState:UIControlStateNormal];
            [addBtn addTarget:self action:@selector(takeMorePhoto) forControlEvents:UIControlEventTouchUpInside];
            [cells.contentView addSubview:addBtn];
        }
    }
    cells.backgroundColor = [UIColor clearColor];
    cells.contentView.backgroundColor = [UIColor clearColor];
    return cells;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

- (CGRect)getResourceRect:(int)index
{
    CGRect rectangle;
    
    switch (index)
    {
        case 0:
            rectangle = CGRectMake(25, 12, 73, 73);
            break;
        case 1:
            rectangle = CGRectMake(125, 12, 73, 73);
            break;
        case 2:
            rectangle = CGRectMake(223, 12, 73, 73);
            break;
        default:
            break;
    }
    return rectangle;
}

- (CGRect)getDeleteRect:(int)index
{
    CGRect rectangle;
    
    switch (index)
    {
        case 0:
            rectangle = CGRectMake(83, 0, 23, 23);
            break;
        case 1:
            rectangle = CGRectMake(183, 0, 23, 23);
            break;
        case 2:
            rectangle = CGRectMake(283, 0, 23, 23);
            break;
        default:
            break;
    }
    return rectangle;
}

-(void)deleteAction:(UIButton*)sender
{
    UIButton *button = (UIButton *)sender;
    UploadData *data = [self.uploadArray objectAtIndex:button.tag];
    [self.uploadArray removeObject:data];
    [self.uploadTableView reloadData];
}



#pragma mark - Request
- (void)getEventCategory
{
    [self showIndicator];
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetEventClassList withData:nil];
}

- (void)getSinaUserInfo
{
    sinaWeibo.delegate = self;
    [sinaWeibo requestWithURL:@"users/show.json"
                       params:[NSMutableDictionary dictionaryWithObject:sinaWeibo.userID forKey:@"uid"]==nil?nil:[NSMutableDictionary dictionaryWithObject:sinaWeibo.userID forKey:@"uid"]
                   httpMethod:@"GET"
                     delegate:self];
}

- (void)bindingSinaByUid
{
    [self showIndicator];
    NSDictionary *dic = @{@"thirduid":[self getSinaWeibo].userID,
                          @"token":[self getSinaWeibo].accessToken,
                          @"expiration": [NSString stringWithFormat:@"%lf",[[self getSinaWeibo].expirationDate timeIntervalSince1970]],
                          @"autologin":@"1"
                          };
    
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeBindSinaUserByUid withData:dic];
}

#pragma mark - share
- (void)sinaShareAction
{
    // post image status
    SinaWeibo *sinaweibo = [self getSinaWeibo];
    
    if ([sinaweibo isAuthValid])
    {
        [sinaweibo requestWithURL:@"statuses/update.json"
                           params:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   self.titleTV.text , @"status", nil]
                       httpMethod:@"POST"
                         delegate:self];
    }
    else
    {
        [sinaweibo logIn];
    }
    
}

#pragma mark request callback
-(void)webServiceRequest:(RequestType)requestType response:(id)response userData:(id)userData originalData:(id)data
{
    if (requestType == kRequestTypeBindSinaUserByUid) {
        [self hideIndicator];
        [self getSinaUserInfo];
    }
    else if (requestType == kRequestTypeAddInfo) {
        NSString *str;
        if ([[data objectForKey:@"data"]objectForKey:@"addcredit"]) {
            if ([[[data objectForKey:@"data"]objectForKey:@"addcredit"]integerValue]!=0) {
                str= [NSString stringWithFormat:@"获得%@积分",[[data objectForKey:@"data"]objectForKey:@"addcredit"]];
            }
            else
                [self toast:@"发布成功"];
        }
        else
            str = nil;
        [[AppDelegate sharedAppDelegate] creditView:@"发布成功" withCredit:str];
        
        if (_aDelegate && [_aDelegate respondsToSelector:@selector(confirmUpload:)]) {
            [_aDelegate confirmUpload:[NSDictionary dictionaryWithObjectsAndKeys:response,@"id",self.titleTV.text,@"title", nil]];
        }
        [self.navigationController popViewControllerAnimated:YES];
    }
}

-(void)webServiceRequest:(RequestType)requestType errorString:(NSString*)errorString userData:(id)userData
{
    [self hideIndicator];
    [self toast:errorString];
    if (requestType == kRequestTypeBindSinaUserByUid) {
        SinaWeibo *sinaWB = [self getSinaWeibo];
        [sinaWB logOut];
    }
    else if (requestType == kRequestTypeGetEventClassList)
    {
        
    }
    else if (requestType == kRequestTypeAddInfo)
    {
        [self toast:@"发布失败"];
    }
}

#pragma mark - TextView Delegate
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    if ([textView.text isEqualToString:kDefaultUploadBrief])
    {
        textView.text = @"";
    }
    if ([textView.text isEqualToString:@"添加一个有吸引力的标题"]) {
        textView.text = @"";
    }
    return YES;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    
    if ([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

- (void)textViewDidChange:(UITextView *)textView
{
    self.textNumberLbl.text = [NSString stringWithFormat:@"%d/70",textView.text.length];
}

#pragma mark - sinaDelegate
- (void)request:(SinaWeiboRequest *)request didFinishLoadingWithResult:(id)result
{
    if ([request.url hasSuffix:@"users/show.json"])
    {
        self.sinaNameLbl.text = [result objectForKey:@"name"];
        self.sinaBtn.selected = YES;
    }
}


- (void)sinaweiboDidLogIn:(SinaWeibo *)sinaweibo
{
    [RequestManager sharedManager].userInfo.sinauid = sinaweibo.userID;
    [RequestManager sharedManager].userInfo.sinaToken = sinaweibo.accessToken;
    [RequestManager sharedManager].userInfo.sinaExpiration = sinaweibo.expirationDate;
    //微博登陆成功了，然后检查是否绑定过
    [self bindingSinaByUid];
}

- (void)sinaweibo:(SinaWeibo *)sinaweibo logInDidFailWithError:(NSError *)error
{
    FVLog(@"sinaweibo logInDidFailWithError %@", error);
}

- (void)addInfo:(NSArray*)nsids
{
    NSString *ft = [NSString stringWithFormat:@"%d",_type];
    if (self.sinaBtn.selected) {
        [self sinaShareAction];
    }
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:self.titleTV.text,@"title",self.briefTV.text,@"brief",nsids,@"nsids", ft,@"ft",self.event==nil?nil:self.event.eventid,@"eventid",nil];
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeAddInfo withData:dic];
}

-(void)setProgress:(NSString*)progress
{
    if (hud) {
        hud.progress = [progress floatValue];
    }
}

-(void)setHudHidden
{
    if (hud) {
        [hud hide:YES];
    }
}

#pragma mark - GeeUploadManager Delegate

- (void)progressCallback:(IOSProgressCallbackData*)obj
{
    [self performSelectorOnMainThread:@selector(setProgress:) withObject:[NSString stringWithFormat:@"%lf",obj.per] waitUntilDone:NO];
}

- (void)uploadCompleteCallback:(GeeUploadResult *)gr obj:(IGeeUploadData *)obj
{
    NSMutableArray *nsids = [[NSMutableArray alloc]initWithCapacity:0];
    for (GeeUploadFileInfo *info in obj.param.fileinfos) {
        if ([info.nsid length]>0) {
            [nsids addObject:info.nsid];
        }
    }
    [self performSelectorOnMainThread:@selector(setHudHidden) withObject:nil waitUntilDone:NO];
    if (gr.result == 1) {
        
        [self performSelectorOnMainThread:@selector(addInfo:) withObject:nsids waitUntilDone:YES];
    }
    else
    {
        [self performSelectorOnMainThread:@selector(toast:) withObject:[gr toString] waitUntilDone:YES];
    }
}

@end
