//
//  PhoneGapViewController.h
//  wisdomcloud
//
//  Created by liuleijie on 14-3-25.
//  Copyright (c) 2014年 llj. All rights reserved.
//

#import "CDVViewController.h"
#import "CDVCommandDelegate.h"
#import "CDVCommandDelegateImpl.h"
#import "CDVCommandQueue.h"

@interface PhoneGapViewController : CDVViewController

@end

@interface PhoneGapCommandDelegate : CDVCommandDelegateImpl

@end

@interface PhoneGapCommandQueue : CDVCommandQueue

@end
