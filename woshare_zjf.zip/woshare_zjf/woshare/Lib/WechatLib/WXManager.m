//
//  WXManager.m
//  GeeCloudDemo
//
//  Created by liuleijie on 刘磊杰13-8-23.
//  Copyright (c) 2013年 zlvod. All rights reserved.
//

#import "WXManager.h"


#define WXGISTERAPPID   @"wxa84971f204e7d28d"

@implementation WXManager
@synthesize scene = _scene;
@synthesize wxManagerDelegate = _delegate;
static WXManager    *manager;


+(id)shareInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[WXManager alloc] init];
        [WXApi registerApp:WXGISTERAPPID];
    });
    return manager;
}


-(id)init
{
    self = [super init];
    if (self) {
        _scene = WXSceneSession;
    }
    return self;
}

-(void)setWxManagerDelegate:(id<WXManagerDelegate>)aDelegate
{
    _delegate = aDelegate;
}
-(void)removeWxManagerDelegate
{
    _delegate = nil;
}

//检查微信是否已被用户安装
-(BOOL)isWXAppInstalled
{
    return [WXApi isWXAppInstalled];
}

//判断当前微信的版本是否支持OpenApi
-(BOOL) isWXAppSupportApi
{
    return [WXApi isWXAppSupportApi];
}

////获取当前微信的版本所支持的API最高版本
//-(NSString *) getWXAppSupportMaxApiVersion
//{
//    return [WXApi getWXAppSupportMaxApiVersion];
//}

//获取当前微信SDK的版本号
-(NSString *) getApiVersion
{
    return [WXApi getApiVersion];
}

//获取微信的itunes安装地址
-(NSString *) getWXAppInstallUrl
{
    return [WXApi getWXAppInstallUrl];
}

//打开微信
-(BOOL) openWXApp
{
    return [WXApi openWXApp];
}

/*! @brief 发送请求到微信,等待微信返回onResp
 *
 * 函数调用后，会切换到微信的界面。第三方应用程序等待微信返回onResp。微信在异步处理完成后一定会调用onResp。可能发送的请求有
 * SendMessageToWXReq、SendAuthReq等。
 * @param req 具体的发送请求，在调用函数后，请自己释放。
 * @return 成功返回YES，失败返回NO。
 */
-(BOOL) sendReq:(BaseReq*)req
{
    return [WXApi sendReq:req];
}

/*! @brief 收到微信onReq的请求，发送对应的应答给微信，并切换到微信界面
 *
 * 函数调用后，会切换到微信的界面。第三方应用程序收到微信onReq的请求，异步处理该请求，完成后必须调用该函数。可能发送的相应有
 * GetMessageFromWXResp、ShowMessageFromWXResp等。
 * @param resp 具体的应答内容，调用函数后，请自己释放
 * @return 成功返回YES，失败返回NO。
 */
-(BOOL) sendResp:(BaseResp*)resp
{
    return [WXApi sendResp:resp];
}

#pragma mark 发送的东西

//发送Photo消息给微信
- (void) sendImageContent:(NSData *)imageData thumbImage:(UIImage *)aImage
{
    //发送内容给微信
    WXMediaMessage *message = [WXMediaMessage message];
    [message setThumbImage:aImage];
    
    WXImageObject *ext = [WXImageObject object];
    ext.imageData = imageData;
    
    message.mediaObject = ext;
    
    SendMessageToWXReq* req = [[[SendMessageToWXReq alloc] init]autorelease];
    req.bText = NO;
    req.message = message;
    req.scene = _scene;
    
    [WXApi sendReq:req];
}

//发送News消息给微信
- (void) sendNewsContent:(NSString *)aDescription title:(NSString *)aTitle thumbImage:(UIImage *)aImage webPageUrl:(NSString *)aUrl
{
    WXMediaMessage *message = [WXMediaMessage message];
    message.title = aTitle;
    message.description = aDescription;
    [message setThumbImage:aImage];
    
    WXWebpageObject *ext = [WXWebpageObject object];
    ext.webpageUrl = aUrl;
    
    message.mediaObject = ext;
    
    SendMessageToWXReq* req = [[[SendMessageToWXReq alloc] init]autorelease];
    req.bText = NO;
    req.message = message;
    req.scene = _scene;
    
    [WXApi sendReq:req];
}

//发送Music消息给微信
-(void) sendMusicContent:(NSString *)aDescription title:(NSString *)aTitle thumbImage:(UIImage *)aImage musicUrl:(NSString *)aMusicUrl musicDataUrl:(NSString *)aMusicDataUrl
{
    WXMediaMessage *message = [WXMediaMessage message];
    message.title = aTitle;
    message.description = aDescription;
    [message setThumbImage:aImage];
    
    WXMusicObject *ext = [WXMusicObject object];
    ext.musicUrl = aMusicUrl;
    ext.musicDataUrl = aMusicDataUrl;
    
    message.mediaObject = ext;
    
    SendMessageToWXReq* req = [[[SendMessageToWXReq alloc] init]autorelease];
    req.bText = NO;
    req.message = message;
    req.scene = _scene;
    
    [WXApi sendReq:req];
}

//发送Video消息给微信
-(void) sendVideoContent:(NSString *)aDescription title:(NSString *)aTitle thumbImage:(UIImage *)aImage videoUrl:(NSString *)aVideoUrl
{
    WXMediaMessage *message = [WXMediaMessage message];
    message.title = aTitle;
    message.description = aDescription;
    [message setThumbImage:aImage];
    
    WXVideoObject *ext = [WXVideoObject object];
    ext.videoUrl = aVideoUrl;
    
    message.mediaObject = ext;
    
    SendMessageToWXReq* req = [[[SendMessageToWXReq alloc] init]autorelease];
    req.bText = NO;
    req.message = message;
    req.scene = _scene;
    
    [WXApi sendReq:req];
}

//发送文本消息给微信
- (void) sendTextContent:(NSString*)nsText
{
    SendMessageToWXReq* req = [[[SendMessageToWXReq alloc] init]autorelease];
    req.bText = YES;
    req.text = nsText;
    req.scene = _scene;
    
    [WXApi sendReq:req];
}


//发送App消息给微信
//#define BUFFER_SIZE 1024 * 100
- (void) sendAppContent:(NSString *)aDescription title:(NSString *)aTitle thumbImage:(UIImage *)aImage extInfo:(NSString *)aExtInfo appUrl:(NSString *)aAppUrl fileData:(NSData *)aFileData
{
    WXMediaMessage *message = [WXMediaMessage message];
    message.title = aTitle;
    message.description = aDescription;
    [message setThumbImage:aImage];
    
    WXAppExtendObject *ext = [WXAppExtendObject object];
    ext.extInfo = aExtInfo;
    ext.url = aAppUrl;
    
//    Byte* pBuffer = (Byte *)malloc(BUFFER_SIZE);
//    memset(pBuffer, 0, BUFFER_SIZE);
//    NSData* data = [NSData dataWithBytes:pBuffer length:BUFFER_SIZE];
//    free(pBuffer);
    
    ext.fileData = aFileData;
    
    message.mediaObject = ext;
    
    SendMessageToWXReq* req = [[[SendMessageToWXReq alloc] init]autorelease];
    req.bText = NO;
    req.message = message;
    req.scene = _scene;
    
    [WXApi sendReq:req];
}

//发送非gif消息给微信
- (void) sendNonGifContent:(NSData *)imageData thumbImage:(UIImage *)aImage
{
    WXMediaMessage *message = [WXMediaMessage message];
    [message setThumbImage:aImage];
    
    WXEmoticonObject *ext = [WXEmoticonObject object];
    ext.emoticonData = imageData;
    
    message.mediaObject = ext;
    
    SendMessageToWXReq* req = [[[SendMessageToWXReq alloc] init]autorelease];
    req.bText = NO;
    req.message = message;
    req.scene = _scene;
    
    [WXApi sendReq:req];
}

//发送gif消息给微信
- (void) sendGifContent:(NSString *)aFilePath thumbImage:(UIImage *)aImage
{
    WXMediaMessage *message = [WXMediaMessage message];
    [message setThumbImage:aImage];
    
    WXEmoticonObject *ext = [WXEmoticonObject object];
    ext.emoticonData = [NSData dataWithContentsOfFile:aFilePath] ;
    
    message.mediaObject = ext;
    
    SendMessageToWXReq* req = [[[SendMessageToWXReq alloc] init]autorelease];
    req.bText = NO;
    req.message = message;
    req.scene = _scene;
    
    [WXApi sendReq:req];
}


#pragma mark WXApiDelegate

-(void) onReq:(BaseReq*)req
{
    NSLog(@"%@",req);
}


-(void) onResp:(BaseResp*)resp
{
    if([resp isKindOfClass:[SendMessageToWXResp class]])
    {
        NSString *strTitle = [NSString stringWithFormat:@"发送结果"];
        NSString *strMsg = [NSString stringWithFormat:@"发送媒体消息结果:%d", resp.errCode];
        
        NSLog(@"%@%@",strTitle,strMsg);
        
    }
//    else if([resp isKindOfClass:[SendAuthResp class]])
//    {
//        NSString *strMsg = [NSString stringWithFormat:@"Auth结果:%d", resp.errCode];
//        NSLog(@"%@",strMsg);
//    }
    
    if (_delegate && [_delegate respondsToSelector:@selector(sendContentErrorCode:erroeStr:scene:)]) {
        
        [_delegate sendContentErrorCode:resp.errCode
                               erroeStr:resp.errStr
                                  scene:resp.type];
    }
    
    
}

@end
