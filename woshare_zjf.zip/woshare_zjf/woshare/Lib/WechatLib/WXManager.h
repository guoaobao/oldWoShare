//
//  WXManager.h
//  GeeCloudDemo
//
//  Created by liuleijie on 刘磊杰13-8-23.
//  Copyright (c) 2013年 zlvod. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WXApiObject.h"
#import "WXApi.h"

@protocol WXManagerDelegate <NSObject>

@optional
-(void)sendContentErrorCode:(enum WXErrCode)errCode erroeStr:(NSString *)errorStr scene:(enum WXScene)ascene;

@end


@interface WXManager : NSObject<WXApiDelegate>
{
    enum WXScene _scene;
    id<WXManagerDelegate>_delegate;
}

@property (nonatomic, assign) enum WXScene scene;       //发送到哪里 默认为会话-WXSceneSession  修改 可以改为朋友圈
@property (nonatomic, assign) id<WXManagerDelegate>wxManagerDelegate;

-(id)init;
+(id)shareInstance;

-(void)setWxManagerDelegate:(id<WXManagerDelegate>)aDelegate;
-(void)removeWxManagerDelegate;

-(BOOL)isWXAppInstalled;
-(BOOL) isWXAppSupportApi;
//-(NSString *) getWXAppSupportMaxApiVersion;
-(NSString *) getApiVersion;
-(NSString *) getWXAppInstallUrl;
-(BOOL) openWXApp;
-(BOOL) sendReq:(BaseReq*)req;
-(BOOL) sendResp:(BaseResp*)resp;

- (void) sendImageContent:(NSData *)imageData thumbImage:(UIImage *)aImage;
- (void) sendNewsContent:(NSString *)aDescription title:(NSString *)aTitle thumbImage:(UIImage *)aImage webPageUrl:(NSString *)aUrl;
-(void) sendMusicContent:(NSString *)aDescription title:(NSString *)aTitle thumbImage:(UIImage *)aImage musicUrl:(NSString *)aMusicUrl musicDataUrl:(NSString *)aMusicDataUrl;
-(void) sendVideoContent:(NSString *)aDescription title:(NSString *)aTitle thumbImage:(UIImage *)aImage videoUrl:(NSString *)aVideoUrl;
- (void) sendTextContent:(NSString*)nsText;
- (void) sendAppContent:(NSString *)aDescription title:(NSString *)aTitle thumbImage:(UIImage *)aImage extInfo:(NSString *)aExtInfo appUrl:(NSString *)aAppUrl fileData:(NSData *)aFileData;
- (void) sendNonGifContent:(NSData *)imageData thumbImage:(UIImage *)aImage;
- (void) sendGifContent:(NSString *)aFilePath thumbImage:(UIImage *)aImage;


#pragma mark Delegate
-(void) onReq:(BaseReq*)req;
-(void) onResp:(BaseResp*)resp;
@end
