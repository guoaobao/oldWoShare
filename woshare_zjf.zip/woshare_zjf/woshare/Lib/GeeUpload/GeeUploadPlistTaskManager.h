//
//  GeeUploadPlistTaskManager.h
//  HappyShare
//
//  Created by eingbol on 13-5-9.
//  Copyright (c) 2013年 Lin Pan. All rights reserved.
//

#import "GeeUploadMemTaskManager.h"

@interface GeeUploadPlistTaskManager : GeeUploadMemTaskManager

@end
