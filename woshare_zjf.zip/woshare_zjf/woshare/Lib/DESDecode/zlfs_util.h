#ifndef ZLFS_UTIL_H
#define ZLFS_UTIL_H

void hex2ascii(unsigned char b, char *ch1, char *ch2);
unsigned char ascii2hex(unsigned char *buffer);

#endif
