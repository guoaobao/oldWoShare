//
//  AddressBookManage.m
//  fjlt
//
//  Created by liuleijie on 13-1-8.
//  Copyright (c) 2013年 zlvod. All rights reserved.
//

#import "AddressBookManage.h"

#import "ABContactsHelper.h"
#import "ABGroup.h"
#import "JSONKit.h"
#import "SNSUserResponse.h"
#import "UserInfoResponse.h"


@implementation AddressBookManage

static AddressBookManage *_sharedAddressBookManageInstance = nil;

+(AddressBookManage *)sharedAddressBookManage{
    
    if (_sharedAddressBookManageInstance) {
        _sharedAddressBookManageInstance = [[self alloc] init];
        return _sharedAddressBookManageInstance;
    }
    return nil;
}

+(void)purgeSharedAddressBookManage{
    
    [_sharedAddressBookManageInstance release];
    _sharedAddressBookManageInstance = nil;
}

-(void)dealloc{
    [super dealloc];
}

+(NSArray *)GetAddressBookJson{
    NSMutableArray *photo_Array = [[[NSMutableArray alloc] init] autorelease];
    NSArray *personArray = [ABContactsHelper contacts];
    
    for (int i=0; i<[personArray count]; i++) {
        NSMutableDictionary *datainfoDict = [[NSMutableDictionary alloc] init];
        ABContact *ABConractInfo = (ABContact *)[personArray objectAtIndex:i];
        [datainfoDict setObject:[NSString stringWithFormat:@"%d",ABConractInfo.recordID] forKey:@"id"];
        NSString *firstname = [ABConractInfo.firstname length]>0?ABConractInfo.firstname:@"";
        NSString *lastname = [ABConractInfo.lastname length]>0?ABConractInfo.lastname:@"";
        NSString *name = [NSString stringWithFormat:@"%@%@",lastname,firstname];
        NSArray *photoArr = [self replacePhoneArray:ABConractInfo.phoneArray];
        [datainfoDict setObject:name forKey:@"nm"];
        [datainfoDict setObject:photoArr forKey:@"ph"];
        if ([photoArr count]>0) {
            [photo_Array addObject:datainfoDict];
        }
        [datainfoDict release];
    }
    
    return photo_Array;
}

+(NSArray *)replacePhoneArray:(NSArray *)phoneArray{
    NSMutableArray *RePhoneArray = [[[NSMutableArray alloc] init] autorelease];
    for (int i=0; i<[phoneArray count]; i++) {
        NSString *phone = [phoneArray objectAtIndex:i];
        phone = [self replacephone:(NSString *)phone];
        int phone_leng = [phone length];
        if (phone_leng>10) {
            [RePhoneArray addObject:[phone substringFromIndex:phone_leng-11]];
        }
    }
    return RePhoneArray;
}

+(NSString *)replacephone:(NSString *)Pstr{
    Pstr = [Pstr stringByReplacingOccurrencesOfString:@" " withString:@""];
    Pstr = [Pstr stringByReplacingOccurrencesOfString:@"-" withString:@""];
    Pstr = [Pstr stringByReplacingOccurrencesOfString:@"+86" withString:@""];
    Pstr = [Pstr stringByReplacingOccurrencesOfString:@"(" withString:@""];
    Pstr = [Pstr stringByReplacingOccurrencesOfString:@")" withString:@""];
    return Pstr;
}

#pragma mark 上传通讯录
-(void)uploadAddress:(BOOL)isUpload{
//    LinkInviteListParameter *linkInviteList = [[LinkInviteListParameter alloc] init];
//    if (isUpload) {
//        linkInviteList.phonelist = [AddressBookManage GetAddressBookJson];
//    }
//    [[RequestManager sharedManager]  startRequestWithParameter:linkInviteList];
//    LLJ_RELEASE(linkInviteList)
}


+(NSArray *)GetTheRestAdress:(NSArray *)httpAdress{
    NSMutableArray *RestAdressArray = [[[NSMutableArray alloc] init] autorelease];
    NSArray *personArray = [ABContactsHelper contacts];
    
    for (int i=0; i<[personArray count]; i++) {
        ABContact *ABConractInfo = (ABContact *)[personArray objectAtIndex:i];
        NSArray *phoArray = [self replacePhoneArray:ABConractInfo.phoneArray];
        BOOL isAdd = YES;
        for (int i=0; i<[phoArray count]; i++) {
            for (int j=0; j<[httpAdress count]; j++) {
                SNSUserResponse *snsInfo = [[SNSUserResponse alloc]initWithDict:[httpAdress objectAtIndex:j ] withRequestType:2];
                if ([[phoArray objectAtIndex:i] isEqualToString:snsInfo.mobile]) {
                    isAdd = NO;
                    break;
                }
            }
        }
        if (isAdd) {
            [RestAdressArray addObject:ABConractInfo];
        }
    }
    return RestAdressArray;
}

+(NSArray *)GetTheAdress:(NSArray *)httpAdress{
    NSMutableArray *RestAdressArray = [[[NSMutableArray alloc] init] autorelease];
    NSArray *personArray = [ABContactsHelper contacts];
    for (int i=0; i<[personArray count]; i++) {
        ABContact *ABConractInfo = (ABContact *)[personArray objectAtIndex:i];
        NSString *firstname = [ABConractInfo.firstname length]>0?ABConractInfo.firstname:@"";
        NSString *lastname = [ABConractInfo.lastname length]>0?ABConractInfo.lastname:@"";
        NSString *name = [NSString stringWithFormat:@"%@%@",lastname,firstname];
        NSArray *phoArray = [self replacePhoneArray:ABConractInfo.phoneArray];
        for (int j=0; j<[httpAdress count]; j++) {
             UserInfoResponse *snsInfo =[[[UserInfoResponse alloc]initWithDict:[httpAdress objectAtIndex:j] withRequestType:0]autorelease];
            snsInfo.truename = name;
            for (int k = 0; k<[phoArray count]; k++) {
                if ([[phoArray objectAtIndex:k] isEqualToString:snsInfo.mobile]) {
                    [RestAdressArray insertObject:snsInfo atIndex:0];
                    break;
                }
            }
        }
    }
    return RestAdressArray;
}



@end
