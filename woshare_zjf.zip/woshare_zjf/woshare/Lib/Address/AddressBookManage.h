//
//  AddressBookManage.h
//  fjlt
//
//  Created by liuleijie on 13-1-8.
//  Copyright (c) 2013年 zlvod. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ABContact.h"

@interface AddressBookManage : NSObject{

}


+(AddressBookManage *)sharedAddressBookManage;

+(NSArray *)GetAddressBookJson;

+(NSArray *)GetTheRestAdress:(NSArray *)httpAdress;

+(NSArray *)GetTheAdress:(NSArray *)httpAdress;
@end
