//
//  GCAppDelegate.m
//  woshare
//
//  Created by 胡波 on 14-2-21.
//  Copyright (c) 2014年 胡波. All rights reserved.
//

#import "AppDelegate.h"
#import "MobClick.h"
#import "IntroView.h"
#import "ASIHTTPRequest.h"
#import "URLDefine.h"
#import "EGOCache.h"
#import "FVKit.h"
#import "ServicePushViewController.h"

#import "GeeUploadPlistTaskManager.h"
//#import "ShareKitManager.h"

#import "HomeViewController.h"
#import "EventListViewController.h"
#import "UploadViewController.h"
#import "DisPortViewController.h"
#import "ZoneViewController.h"
#import "LoginViewController.h"
#import "RightSlideViewController.h"
#import "LinkViewController.h"

#import "ThemePostViewController.h"
#import "SpecialViewController.h"
#import "MovieViewController.h"
#import "LeftViewController.h"
#import "JSONKit.h"
#import "BPush.h"
#define kMustUpdateAlert 100001
#define kChoiceAlert     100002
#define kHelpViewTag     100003
#define kPushAlertTag    200003

@implementation AppDelegate

+(AppDelegate*)sharedAppDelegate
{
    return (AppDelegate*)[[UIApplication sharedApplication] delegate];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    if ([Config getAutoClearCacheValue])
    {
        [[EGOCache currentCache] clearCache];
        NSString    *cache = FVGetPathWithType(kFVPathTypeCache, nil);
        [[NSFileManager defaultManager] removeItemAtPath:cache error:nil];
    }
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationNone];
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes: UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert];
    
    [MobClick startWithAppkey: kUmengAppKey];
    [[RequestManager sharedManager]addDelegate:self];
    [[RequestManager sharedManager]startService];
//    by llj old
//    if (launchOptions) {
//        self.hasPush = YES;
//        self.pushUserInfo =  [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
//    }
//    by llj new
    if (launchOptions) {
        [self performSelector:@selector(handlePushMessage:) withObject:[launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey] afterDelay:0.1];
    }
    
    [self getConfig];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginAction) name:kNotificationLogin object:nil];
    
    _tabbar = [[AKTabBarController alloc] initWithTabBarHeight:(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) ? 70 : 49];
    [_tabbar setMinimumHeightToDisplayTitle:40.0];
    
    UploadViewController *uvc =[[UploadViewController alloc] initWithNibName:@"UploadViewController" bundle:nil];
    uvc.isTabbar = YES;
    UIBaseNavigationController *setNavi= [[UIBaseNavigationController alloc]initWithRootViewController:uvc];
    
    UIBaseNavigationController *homeNavi= [[UIBaseNavigationController alloc]initWithRootViewController:[[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil]];
    
    UIBaseNavigationController *EventNavi= [[UIBaseNavigationController alloc]initWithRootViewController:[[EventListViewController alloc] initWithNibName:@"EventListViewController" bundle:nil]];
    
    ZoneViewController *zone    =[[ZoneViewController alloc] initWithNibName:@"ZoneViewController" bundle:nil];
    zone.isTabBar = YES;
    UIBaseNavigationController *ZoneNavi= [[UIBaseNavigationController alloc]initWithRootViewController:zone];
    
    UIBaseNavigationController *HappyNavi= [[UIBaseNavigationController alloc]initWithRootViewController:[[DisPortViewController alloc] initWithNibName:@"DisPortViewController" bundle:nil]];
    
    [_tabbar setViewControllers:[NSMutableArray arrayWithObjects:
                                           homeNavi,
                                           EventNavi,
                                           setNavi,
                                           HappyNavi,
                                           ZoneNavi,nil]];
    
    
    [self setTabBar];
    
    [BPush setupChannel:launchOptions];
    // 必须。参数对象必须实现(void)onMethod:(NSString*)method response:(NSDictionary*)data 方法,本示例中为 self
    [BPush setDelegate:self];
    
    _navigationController= [[UIBaseNavigationController alloc]initWithRootViewController:_tabbar];
    _navigationController.navigationBarHidden = YES;
    
    _slideview = [[PPRevealSideViewController alloc] initWithRootViewController:_navigationController];
    
    [_slideview setDirectionsToShowBounce:PPRevealSideDirectionNone];
    [_slideview setPanInteractionsWhenClosed:PPRevealSideInteractionContentView | PPRevealSideInteractionNavigationBar];
    LeftViewController *left = [[LeftViewController alloc]initWithNibName:Nil bundle:nil];
    [_slideview preloadViewController:left forSide:PPRevealSideDirectionRight];
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];   
    self.window.rootViewController = _slideview;
    [self.window makeKeyAndVisible];
    return YES;
}

-(void)getBootCategory
{
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"27",@"catid",@"6",@"idlevel", nil];
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetTopCategory withData:dic];
}

- (void)setTabBar
{
    // Below you will find an example of possible customization, just uncomment the lines
    
    // Tab background Image
    [_tabbar setBackgroundImageName:@"Tab背景"];
    [_tabbar setSelectedBackgroundImageName:@"hs_homepage_bottom_choose"];
    
    // Tabs top embos Color
    //    [_tabBarController setTabEdgeColor:[UIColor colorWithRed:0.2 green:0.2 blue:0.2 alpha:0.8]];
    //    [_tabBarController setTabEdgeColor:[UIColor clearColor]];
    // Tabs Colors settings
    //    [_tabBarController setTabColors:@[[UIColor colorWithRed:0.1 green:0.1 blue:0.1 alpha:0.0],
    //                                      [UIColor colorWithRed:0.6 green:0.6 blue:0.6 alpha:1.0]]]; // MAX 2 Colors
    
    //    [_tabBarController setSelectedTabColors:@[[UIColor colorWithRed:0.7 green:0.7 blue:0.7 alpha:1.0],
    //                                              [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.0]]]; // MAX 2 Colors
    
    // Tab Stroke Color
    //    [_tabBarController setTabStrokeColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0]];
    
    // Icons Color settings
    //    [_tabBarController setIconColors:@[[UIColor colorWithRed:174.0/255.0 green:174.0/255.0 blue:174.0/255.0 alpha:1],
    //                                       [UIColor colorWithRed:228.0/255.0 green:228.0/255.0 blue:228.0/255.0 alpha:1]]]; // MAX 2 Colors
    
    [_tabbar setSelectedIconColors:@[[UIColor colorWithRed:70.0/255 green:193.0/255 blue:201.0/255 alpha:1.0],
                                               [UIColor colorWithRed:70.0/255 green:193.0/255 blue:201.0/255 alpha:1.0]]]; // MAX 2 Colors
    
    // Text Color
    //    [_tabBarController setTextColor:[UIColor colorWithRed:157.0/255.0 green:157.0/255.0 blue:157.0/255.0 alpha:1.0]];
    [_tabbar setSelectedTextColor:[UIColor colorWithRed:70.0/255 green:193.0/255 blue:201.0/255 alpha:1.0]];
    
    // Hide / Show glossy on tab icons
    //    [_tabBarController setIconGlossyIsHidden:YES];
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    kUpdateType update = [self checkVersion];
    if (update == kUpdateMust)
    {
        [self showMustUpdateAlert];
    }
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    [self.sinaWeibo applicationDidBecomeActive];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

//- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
//{
//    return [[ShareKitManager sharedInstance] handleOpenURL:url];
//}
//
//- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
//{
//    return [[ShareKitManager sharedInstance] handleOpenURL:url];
//}

#pragma mark -
#pragma mark - Apple Push Srevice

- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
    [BPush registerDeviceToken: deviceToken];
    [BPush bindChannel];
}

- (void) onMethod:(NSString*)method response:(NSDictionary*)data {
    NSLog(@"On method:%@", method);
    NSLog(@"data:%@", [data description]);
}

- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error
{

}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
//    [UIApplication sharedApplication].applicationIconBadgeNumber = 1;
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
//    by llj old
    if ([[userInfo objectForKey:@"aps"] objectForKey:@"alert"]!=NULL) {
        AlertViewWithData* alert = [[AlertViewWithData alloc] initWithTitle:@"推送消息"
                                                                    message:[[userInfo objectForKey:@"aps"] objectForKey:@"alert"]
                                                                   delegate:self
                                                          cancelButtonTitle:@"忽略"
                                                          otherButtonTitles:@"查看详情",nil];
        alert.tag = kPushAlertTag;
        alert.userData = userInfo;
        [alert show];
    }
}

-(void)handlePushMessage:(NSDictionary*)userInfo
{
//    [UIApplication sharedApplication].applicationIconBadgeNumber = 1;
//    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    NSString *msgid = [userInfo objectForKey:@"msgid"]==nil?@"":[userInfo objectForKey:@"msgid"];
    NSString *idkey = [userInfo objectForKey:@"idkey"]==nil?@"":[userInfo objectForKey:@"idkey"];
    NSString *idvalue = [userInfo objectForKey:@"idvalue"]==nil?@"":[userInfo objectForKey:@"idvalue"];
    AKTabBarController *ak = self.tabbar;
    UIBaseNavigationController *navi = [ak.viewControllers objectAtIndex:_indexPage];
    if ([idkey isEqualToString:@"info"]) {
        [self getInfoInfo:idvalue];
        [self completeReadData:msgid];
    }
    else if ([idkey isEqualToString:@"file"])
    {
        [self getNameSpaceInfo:idvalue];
        [self completeReadData:msgid];
    }
    else if ([idkey isEqualToString:@"link"])
    {
        
        [self completeReadData:msgid];
        NSString *aToken = [NSString stringWithFormat:@"v=%@",[[RequestManager sharedManager].userInfo.token length]==0?@"":[RequestManager sharedManager].userInfo.token];
        NSRange rang = [idvalue rangeOfString:@"?"];
        NSString *url;
        if (rang.length == 0 ) {
            url = [NSString stringWithFormat:@"%@?%@%@",idvalue,AppParams,aToken];
        }
        else
        {
            url = [NSString stringWithFormat:@"%@&%@%@",idvalue,AppParams,aToken];
        }
        
        LinkViewController *lvc = [[LinkViewController alloc]initWithNibName:@"LinkViewController" bundle:nil];
        lvc.linkURL = url;
//        UIBaseNavigationController *nav = [[UIBaseNavigationController alloc] initWithRootViewController:lvc];
//        [self.tabbar presentViewController:nav animated:YES completion:NULL];
        [navi pushViewController:lvc animated:YES];
    }
    else if ([idkey isEqualToString:@"acty"])
    {
        [self completeReadData:msgid];
    }
    else
    {
        [[RequestManager sharedManager]startRequestWithType:kRequestTypeCompleteRead withData:[NSDictionary dictionaryWithObjectsAndKeys:msgid,@"pmid",@"0",@"readtype",@"1",@"msg",nil]];
    }
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
}

- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
    application.applicationIconBadgeNumber = 0;
    [self handlePushMessage:notification.userInfo];
}

-(BOOL)determineTheAddressBookUpload{
    int ludateline = [Config shareInstance].ludateline;
    int linkupdatelimit = [Config shareInstance].linkupdatelimit ;
    if (ludateline == 0) {
        return YES;
    }else{
        int newDate = (int)[[NSDate new] timeIntervalSince1970];
        return newDate>(ludateline + linkupdatelimit * 60 * 60)?YES:NO;
    }
}

- (void)showIndicator
{
    if (!_HUD)
    {
        MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:[AppDelegate sharedAppDelegate].window];
        self.HUD = HUD;
    }
    
	[[AppDelegate sharedAppDelegate].window addSubview:_HUD];
	[_HUD show:YES];
    [_HUD setUserInteractionEnabled:NO];
}

- (void)hideIndicator
{
    [self.HUD hide:YES];
}

//检查版本号
- (kUpdateType)checkVersion
{
    int versionNum =   [[[[NSBundle mainBundle] infoDictionary] objectForKey:@"versionNumber"] intValue];
    
    //    NSString *name = [[NSBundle mainBundle] bundleIdentifier];
    int leastVer = [[Config shareInstance].minVersionNum intValue];
    int highestVer = [[Config shareInstance].versionNum intValue];
    FVLog(@"本地版本 %d， 服务器 %d,%d",versionNum,leastVer,highestVer);
    
    if(versionNum < leastVer)
    {
        return kUpdateMust;
    }
    else if(versionNum >= leastVer && versionNum < highestVer)
    {
        return kUpdateChoice;
    }
    
    return kUpdateNone;
}

- (void)showMustUpdateAlert
{
    NSString *desc = [NSString stringWithFormat:@"%@\n%@",@"您当前程序的版本与最新版本不兼容，请下载安装最新版本",[Config shareInstance].versionDescription];
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:kBundleName message:desc delegate:self cancelButtonTitle:nil otherButtonTitles:@"更新", nil];
    alert.tag = kMustUpdateAlert;
    [alert show];
}

- (void)showChoiceUpdateAlert
{
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:kBundleName message:[Config shareInstance].versionDescription  delegate:self cancelButtonTitle:@"更新" otherButtonTitles:@"暂不更新", nil];
    alert.tag = kChoiceAlert;
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    int tag = alertView.tag;
    if (tag == kMustUpdateAlert || (tag == kChoiceAlert && buttonIndex == 0))
    {
        NSString *escapedValue = (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(nil,(CFStringRef)[Config shareInstance].downloadLink,NULL,NULL,kCFStringEncodingUTF8)) ;
        
        NSURL *itunesUrl = [NSURL URLWithString:escapedValue];
        if (![[UIApplication sharedApplication] openURL:itunesUrl])
            FVLog(@"%@%@",@"Failed to open url:",[itunesUrl description]);
        
    }
    else if (tag == 10023 && buttonIndex==0)
    {
        
    }
    else if (tag == kPushAlertTag)
    {
        AlertViewWithData *alert = (AlertViewWithData*)alertView;
        if (buttonIndex==1) {
            [self handlePushMessage:alert.userData];
        }
    }
}

#pragma mark - get config

-(void)getConfig
{
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseAppURL,GetConfigURL]];
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    [request startSynchronous];
    NSError *error = [request error];
    if (!error) {
        NSString *response = [request responseString];
        NSString *path = FVGetPathWithType(kFVPathTypeConfigCache, nil);
        NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithObjectsAndKeys:response,@"jsondic",[NSDate date],@"savedate", nil];
        BOOL result = [dict writeToFile:path atomically:YES];
        if (!result) {
            //            FVLog(@"cache error with code 4068");
        }
        else
        {
            //            FVLog(@"\n-------------------------------------\nconfig cache ok\n-------------------------------------\n");
        }
//        _isGotConfig = YES;
        NSData *resultData = [response dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *resultDict = [resultData objectFromJSONData];
        [self parseConfig:[resultDict objectForKey:@"data"]];
        [self initSinaWeibo];
        [self initQZone];
        [self initTencentWeibo];
        kUpdateType update = [self checkVersion];
        if (update == kUpdateMust)
        {
            [self showMustUpdateAlert];
        }
        else if(update == kUpdateChoice)
        {
            [self showChoiceUpdateAlert];
        }
    }
    else
    {
        NSString *path = FVGetPathWithType(kFVPathTypeConfigCache, nil);
        NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:path];
        if ([dic objectForKey:@"jsondic"] ==nil) {
//            _isGotConfig = NO;
        }
        else
        {
//            _isGotConfig = YES;
            NSData *resultData = [[dic objectForKey:@"jsondic"] dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *resultDict = [resultData objectFromJSONData];
            [self parseConfig:[resultDict objectForKey:@"data"]];
            [self initSinaWeibo];
            [self initQZone];
            [self initTencentWeibo];
        }
    }
}

-(void)initSinaWeibo
{
    _sinaWeibo = [[SinaWeibo alloc] initWithAppKey:[Config shareInstance].sinaAppKey
                                         appSecret:[Config shareInstance].sinaAppSecret
                                    appRedirectURI:[Config shareInstance].sinaAuthCallbackUrl
                                       andDelegate:nil];
}

-(void)initQZone
{
    _tencentOAuth = [[TencentOAuth alloc] initWithAppId:[Config shareInstance].qZoneAppKey
											andDelegate:self];
}

-(void)loginQzone:(id)owner
{
    NSMutableArray *_permissions = [NSMutableArray arrayWithObjects:
                                    kOPEN_PERMISSION_GET_USER_INFO,
                                    kOPEN_PERMISSION_GET_SIMPLE_USER_INFO,
                                    kOPEN_PERMISSION_ADD_ALBUM,
                                    kOPEN_PERMISSION_ADD_IDOL,
                                    kOPEN_PERMISSION_ADD_ONE_BLOG,
                                    kOPEN_PERMISSION_ADD_PIC_T,
                                    kOPEN_PERMISSION_ADD_SHARE,
                                    kOPEN_PERMISSION_ADD_TOPIC,
                                    kOPEN_PERMISSION_CHECK_PAGE_FANS,
                                    kOPEN_PERMISSION_DEL_IDOL,
                                    kOPEN_PERMISSION_DEL_T,
                                    kOPEN_PERMISSION_GET_FANSLIST,
                                    kOPEN_PERMISSION_GET_IDOLLIST,
                                    kOPEN_PERMISSION_GET_INFO,
                                    kOPEN_PERMISSION_GET_OTHER_INFO,
                                    kOPEN_PERMISSION_GET_REPOST_LIST,
                                    kOPEN_PERMISSION_LIST_ALBUM,
                                    kOPEN_PERMISSION_UPLOAD_PIC,
                                    kOPEN_PERMISSION_GET_VIP_INFO,
                                    kOPEN_PERMISSION_GET_VIP_RICH_INFO,
                                    kOPEN_PERMISSION_GET_INTIMATE_FRIENDS_WEIBO,
                                    kOPEN_PERMISSION_MATCH_NICK_TIPS_WEIBO,
                                    nil];
    if (!self.tencentOAuth.isSessionValid) {
        [_tencentOAuth authorize:_permissions inSafari:YES];
    }
}

-(void)logOutQzone:(id)owner
{
    if (self.tencentOAuth.isSessionValid) {
        [_tencentOAuth logout:owner];
    }
}

-(void)getQQUserInfo:(id)owner
{
    if (self.tencentOAuth.isSessionValid) {
        _tencentOAuth.sessionDelegate = owner;
        [_tencentOAuth getUserInfo];
    }
}


-(void)initTencentWeibo
{
    _weiboApi = [[WeiboApi alloc]initWithAppKey:[Config shareInstance].TXWBAppKey andSecret:[Config shareInstance].TXWBAppSecret andRedirectUri:[Config shareInstance].TXWBAuthCallbackUrl] ;
}



- (void)parseConfig:(NSDictionary *)dic
{
    NSDictionary *defaultInfoDic = [dic objectForKey:@"defaultinfo"];
    NSDictionary *iphoneCopyRightDic = [dic objectForKey:@"iphone_copyrightinfo"];
    NSDictionary *thirdUserInfoDic = [dic objectForKey:@"thirduser"];
    NSDictionary *weixinInfoDic = [thirdUserInfoDic objectForKey:@"weixin"];
    NSDictionary *qqInfoDic = [thirdUserInfoDic objectForKey:@"qq"];
    NSDictionary *tencentInfoDic = [thirdUserInfoDic objectForKey:@"tencent"];
    NSDictionary *sinaInfoDic = [thirdUserInfoDic objectForKey:@"sina"];
    NSDictionary *smsDic = [thirdUserInfoDic objectForKey:@"sms"];
    NSDictionary *supereyeDic = [thirdUserInfoDic objectForKey:@"supereyes"];
    [Config shareInstance].versionDescription = [iphoneCopyRightDic objectForKey:@"description"];
    [Config shareInstance].minVersionNum = [iphoneCopyRightDic objectForKey:@"minversion"];
    [Config shareInstance].versionNum = [iphoneCopyRightDic objectForKey:@"version"];
    [Config shareInstance].capthcaTime = [defaultInfoDic objectForKey:@"captchafailtime"];
    [Config shareInstance].resourceDownUrl = [defaultInfoDic objectForKey:@"resourcedownurl"];
    [Config shareInstance].defaultMood = [defaultInfoDic objectForKey:@"defaultmood"];
    [Config shareInstance].sinaAppKey = [sinaInfoDic objectForKey:@"appkey"];
    [Config shareInstance].sinaAppSecret = [sinaInfoDic objectForKey:@"appsecret"];
    [Config shareInstance].sinaAuthCallbackUrl = [sinaInfoDic objectForKey:@"authcburl"];
    [Config shareInstance].sinaShareContent = [sinaInfoDic objectForKey:@"sharecontent"];
    [Config shareInstance].sinaInviteContent = [sinaInfoDic objectForKey:@"invitecontent"];
    [Config shareInstance].sinaShareInfoLink = [sinaInfoDic objectForKey:@"shareinfolink"];
    [Config shareInstance].sinaShareLink = [sinaInfoDic objectForKey:@"sharelink"];
    [Config shareInstance].smsShareContent = [smsDic objectForKey:@"sharecontent"];
    [Config shareInstance].smsShareLink = [smsDic objectForKey:@"sharelink"];
    [Config shareInstance].smsInviteContent = [smsDic objectForKey:@"invitecontent"];
    [Config shareInstance].smsShareInfoLink = [smsDic objectForKey:@"shareinfolink"];
    
    [Config shareInstance].defaultResourceBrief = [defaultInfoDic objectForKey:@"defaultbrief"];
    [Config shareInstance].downloadLink = [iphoneCopyRightDic objectForKey:@"downloadurl"];
    [Config shareInstance].useProtocolUrl = [defaultInfoDic objectForKey:@"useprotocolurl"];
    [Config shareInstance].ludateline = [[dic objectForKey:@"ludateline"]doubleValue];
    [Config shareInstance].linkupdatelimit = [[defaultInfoDic objectForKey:@"linkupdatelimit"]doubleValue];
    [Config shareInstance].rtspappcode = [supereyeDic objectForKey:@"appcode"];
    [Config shareInstance].rtsppassword = [supereyeDic objectForKey:@"password"];
    [Config shareInstance].rtsptoken = [supereyeDic objectForKey:@"token"];
    [Config shareInstance].rtspusername = [supereyeDic objectForKey:@"username"];
    
    [Config shareInstance].WXAppKey = [weixinInfoDic objectForKey:@"appkey"];
    [Config shareInstance].WXAppSecret = [weixinInfoDic objectForKey:@"appsecret"];
    [Config shareInstance].WXAuthCallbackUrl = [weixinInfoDic objectForKey:@"authcburl"];
    [Config shareInstance].WXShareContent = [weixinInfoDic objectForKey:@"sharecontent"];
    [Config shareInstance].WXInviteContent = [weixinInfoDic objectForKey:@"invitecontent"];
    [Config shareInstance].WXShareInfoLink = [weixinInfoDic objectForKey:@"shareinfolink"];
    [Config shareInstance].WXShareLink = [weixinInfoDic objectForKey:@"sharelink"];
    
    [Config shareInstance].TXWBAppKey = [tencentInfoDic objectForKey:@"appkey"];
    [Config shareInstance].TXWBAppSecret = [tencentInfoDic objectForKey:@"appsecret"];
    [Config shareInstance].TXWBAuthCallbackUrl = [tencentInfoDic objectForKey:@"authcburl"];
    [Config shareInstance].TXWBShareContent = [tencentInfoDic objectForKey:@"sharecontent"];
    [Config shareInstance].TXWBInviteContent = [tencentInfoDic objectForKey:@"invitecontent"];
    [Config shareInstance].TXWBShareInfoLink = [tencentInfoDic objectForKey:@"shareinfolink"];
    [Config shareInstance].TXWBShareLink = [tencentInfoDic objectForKey:@"sharelink"];
    
    [Config shareInstance].qZoneAppKey = [qqInfoDic objectForKey:@"appkey"];
    [Config shareInstance].qZoneAppSecret = [qqInfoDic objectForKey:@"appsecret"];
    [Config shareInstance].qZoneAuthCallbackUrl = [qqInfoDic objectForKey:@"authcburl"];
    [Config shareInstance].qZoneShareContent = [qqInfoDic objectForKey:@"sharecontent"];
    [Config shareInstance].qZoneInviteContent = [qqInfoDic objectForKey:@"invitecontent"];
    [Config shareInstance].qZoneShareInfoLink = [qqInfoDic objectForKey:@"shareinfolink"];
    [Config shareInstance].qZoneShareLink = [qqInfoDic objectForKey:@"sharelink"];
}


#pragma mark -help tip

-(void)showHelp
{
    NSMutableArray *tipsArr = [[NSMutableArray alloc] init];
    for (int i = 1; i <= 4; ++i)
    {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = kWindowFrame;
        NSString *tipName = [NSString stringWithFormat:@"%d.png",i*10];
        [btn setBackgroundImage:[self deviceImageNamed:tipName] forState:UIControlStateNormal];
        [btn setBackgroundImage:[self deviceImageNamed:tipName] forState:UIControlStateHighlighted];
        [tipsArr addObject:btn];
    }
    IntroView *intro = [[IntroView alloc] initWithFrame:self.window.bounds andPages:tipsArr];
    intro.pages = tipsArr;
    [intro setDelegate:self];
    [intro showInView:self.window animateDuration:0.0];
}

- (UIImage *)deviceImageNamed:(NSString *)name
{
    NSString *imageName = name;
    if (FVIsIPhone5())
    {
        imageName = [NSString stringWithFormat:@"%@-iphone5.%@",name.stringByDeletingPathExtension, name.pathExtension];
    }
    return [UIImage imageNamed:imageName];
}

- (void)introDidFinish {
    FVLog(@"Intro callback");
}

- (void)creditView:(NSString *)string withCredit:(NSString *)credit
{
    if (text) {
        [self dissMissCredit];
    }
    text = [[UILabel alloc]init];
    text.backgroundColor = [UIColor colorWithR:70 G:193 B:203 A:0.9];
    text.numberOfLines = 0;
    int height = [NSString caluLabelHeight:[NSString stringWithFormat:@"%@\n%@",string,credit] contentWidth:150 fontsize:18]+1;
    text.font = [UIFont systemFontOfSize:18];
    text.textAlignment = NSTextAlignmentCenter;
    CALayer *l = [text layer];
    [l setMasksToBounds:YES];
    [l setCornerRadius:5];
    if (!credit) {
        text.frame = CGRectMake(0, 0, 150, height);
        text.text = string;
    }
    else
    {
        text.frame = CGRectMake(0, 0, 150, height);
        text.text = [NSString stringWithFormat:@"%@\n%@",string,credit];
    }
    text.center = CGPointMake(160, self.window.center.y+125);
    text.textColor = [UIColor whiteColor];
    text.alpha = 0;
    [self.window addSubview:text];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    text.alpha = 1;
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(dissMissCredit)];
    [UIView commitAnimations];
}

-(void)dissMissCredit
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationDelay:1];
    text.alpha = 0;
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(hideView)];
    [UIView commitAnimations];
}

-(void)hideView
{
    text = nil;
}

#pragma mark -loginAction

- (void)showLoginFrom:(UIViewController*)owner
{
    LoginViewController *loginVC = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
//    if ([owner isKindOfClass:[ZoneViewController class]]) {
//        loginVC.isZone = YES;
//    }
    UIBaseNavigationController *nav = [[UIBaseNavigationController alloc] initWithRootViewController:loginVC];
//    [nav setNavigationBarHidden:YES];
    //    [owner.navigationController pushViewController:loginVC animated:YES];
    [self.tabbar.navigationController presentViewController:nav animated:NO completion:nil];
}


-(void)loginAction
{
    if([Config shareInstance].isInit)
        return;
    [Config shareInstance].isInit = YES;
    [Config shareInstance].intoEdit = YES;
    
    
    if ([[RequestManager sharedManager].userInfo.addcredit integerValue]>0) {
         NSString *str= [NSString stringWithFormat:@"获得%@分享币",[RequestManager sharedManager].userInfo.addcredit];
        NSString *str2= [NSString stringWithFormat:@"连续%@登录",[RequestManager sharedManager].userInfo.cyclelogindays];
        cdv = [[[NSBundle mainBundle] loadNibNamed:@"CreditDayView" owner:self options:nil] objectAtIndex:0];
        cdv.creditLabel.text = str;
        cdv.loginLabel.text = str2;
        cdv.center = self.window.center;
        [cdv.closeButton addTarget:self action:@selector(closeButtonAction) forControlEvents:UIControlEventTouchUpInside];
        [self.window addSubview:cdv];
    }
    
    SinaWeibo *sinaWB = self.sinaWeibo;
    sinaWB.accessToken = [RequestManager sharedManager].userInfo.sinaToken;
    sinaWB.expirationDate = [RequestManager sharedManager].userInfo.sinaExpiration;
    sinaWB.userID = [RequestManager sharedManager].userInfo.sinauid;
    
    if (!self.tencentOAuth.isSessionValid) {
        TencentOAuth *qZone = self.tencentOAuth;
        qZone.accessToken = [RequestManager sharedManager].userInfo.qqToken;
        qZone.expirationDate = [RequestManager sharedManager].userInfo.qqExpiration;
        qZone.openId = [RequestManager sharedManager].userInfo.qquid;
    }
    
    if (!self.weiboApi.isAuthValid) {
        [self.weiboApi loginWithAccesstoken:[RequestManager sharedManager].userInfo.txToken andOpenId:[RequestManager sharedManager].userInfo.txuid andExpires:[RequestManager sharedManager].userInfo.txExpiration andRefreshToken:self.weiboApi.refreshToken andDelegate:nil];
    }
    
    [[RequestManager sharedManager] getHobbyRequest];
    [[RequestManager sharedManager] getUsersNoteUidListRequest];

//初始化上传
    [self initGeeUploader];
    [self.geeUploadManager doTask];

//    [[NSNotificationCenter defaultCenter] postNotificationName:kChangeNameNotification object:nil];
}

-(void)closeButtonAction
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    cdv.alpha = 0;
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(hideCDV)];
    [UIView commitAnimations];
}

-(void)hideCDV
{
    cdv = nil;
}

- (void)initGeeUploader
{
    IGeeUploadTaskManager* manager = [[GeeUploadPlistTaskManager alloc] initWithUID:[RequestManager sharedManager].userInfo.uid isRemoveCompleteTask:YES isRemoveErrorTask:YES];
    GeeUploadManager *tempUploader = [[GeeUploadManager alloc] initWithUrl:[NSString stringWithFormat:@"%@%@%@",BaseAppURL,GetUploadURL,[RequestManager sharedManager].userInfo.token] uploadParentFolderName:kBundleName taskManager:manager];
    self.geeUploadManager = tempUploader;
}


#pragma mark -request

-(void)completeReadData:(NSString*)pmid
{
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:pmid,@"pmid",@"0",@"readtype",nil];
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeCompleteRead withData:dic];
}

-(void)getInfoInfo:(NSString*)infoid
{
    NSDictionary *dic = @{@"infoid":infoid,
                          @"getuserinfo":@"1",
                          @"getcomment":@"1",
                          @"ispush":@"1"};
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetInfoInfo withData:dic];
}

-(void)getNameSpaceInfo:(NSString*)nsid
{
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:nsid,@"nsid",@"1",@"getuserinfo",@"ispush",@"1" ,nil];
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetNameSpaceInfo withData:dic];
}

#pragma mark -request callback

-(void)webServiceRequest:(RequestType)requestType response:(id)response userData:(id)userData originalData:(id)data
{
    if (requestType == kRequestTypeAutoLogin) {
        [self initGeeUploader];
        UserInfoResponse *userinfo = (UserInfoResponse*)response;
        if ([userinfo.newfeed integerValue]>0    ||
            [userinfo.newcomment integerValue]>0 ||
            [userinfo.newpm integerValue]>0)
        {
            
            [Config shareInstance].hasNewMessage =[userinfo.newpm integerValue];
            NSLog(@"%d",[Config shareInstance].hasNewMessage);
        }
        else
            [Config shareInstance].hasNewMessage = 0;
        [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationLogin object:nil];
    }
    else if (requestType == kRequestTypeGetHobby)
    {
        NSMutableDictionary *hobbyDic = [[NSMutableDictionary alloc] init];
        for (NSDictionary *dic in response)
        {
            NSString *key = [NSString stringWithFormat:@"%@",[dic objectForKey:@"interestid"]];
            NSString *value = [dic objectForKey:@"name"];
            [hobbyDic setObject:value forKey:key];
        }
        [Config shareInstance].hobbyDic = hobbyDic;
    }
    else if (requestType == kRequestTypeGetNoteUids)
    {
        [Config shareInstance].myNoteUids = [NSMutableArray arrayWithArray:response];
    }
    else if (requestType == kRequestTypeCheckMobile)
    {
        [Config shareInstance].loginType = kLoginTypeUnicomNumber;
        [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationLogin object:nil];
    }
    else if (requestType == kRequestTypeSetDeviceToken)
    {
        FVLog(@"upload device token ok");
    }
    else if (requestType == kRequestTypeCompleteRead)
    {
        NSDictionary *user = (NSDictionary *)userData;
        if ([[user objectForKey:@"readtype"]integerValue]) {
            return;
        }
        if ([[user objectForKey:@"msg"]integerValue]) {
            AKTabBarController *ak = self.tabbar;
            ak.selectedViewController = [ak.viewControllers objectAtIndex:_indexPage];
            UIBaseNavigationController *navi = [ak.viewControllers objectAtIndex:_indexPage];
            NSDictionary *dic = [data objectForKey:@"data"];
            if ([dic count]>0) {
                MessageResponse *msg = [[MessageResponse alloc]initWithDict:dic withRequestType:0];
                ServicePushViewController *rvc = [[ServicePushViewController alloc]initWithNibName:@"ServicePushViewController" bundle:nil];
                rvc.response = msg;
                [navi pushViewController:rvc animated:YES];
            }
        }
    }
    else if (requestType == kRequestTypeGetInfoInfo)
    {
        if ([[userData objectForKey:@"ispush"]integerValue]) {
            AKTabBarController *ak = self.tabbar;
            UIBaseNavigationController *navi = [ak.viewControllers objectAtIndex:_indexPage];
            InfoListResponse*cat = (InfoListResponse*)response;
            if (cat.infoType == kInfoTypeTheme) {
                ThemePostViewController *svc = [[ThemePostViewController alloc]initWithNibName:@"ThemePostViewController" bundle:nil];
                svc.info = cat;
                [navi pushViewController:svc animated:YES];
            }
            else
            {
                SpecialViewController *svc = [[SpecialViewController alloc]initWithNibName:@"SpecialViewController" bundle:nil];
                svc.info = cat;
                [navi pushViewController:svc animated:YES];
            }
        }
    }
    else if (requestType == kRequestTypeGetNameSpaceInfo)
    {

    }
}

#pragma mark 微信需要重写的代码
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
    if ([[url scheme]isEqualToString:@"wxa84971f204e7d28d"]) {
        return  [WXApi handleOpenURL:url delegate:self];
    }
    
    if (YES == [TencentOAuth CanHandleOpenURL:url])
    {
        return [TencentOAuth HandleOpenURL:url];
    }
    return YES;
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    FVLog(@"%@",[url scheme]);
    if ([[url scheme]isEqualToString:@"wxa84971f204e7d28d"]) {
        
        return  [WXApi handleOpenURL:url delegate:self];
    }
    else
        return [TencentOAuth HandleOpenURL:url];
}

#pragma mark - wechat delegate

-(void) onReq:(BaseReq*)req
{
    [[WXManager shareInstance] onReq:req];
}
-(void) onResp:(BaseResp*)resp
{
    [[WXManager shareInstance] onResp:resp];
}

#pragma mark - QZone delegate

- (void)tencentDidLogin
{
    
}

- (void)tencentDidNotLogin:(BOOL)cancelled
{
    
}

- (void)tencentDidNotNetWork
{
    
}

#pragma mark WeiboAuthDelegate

- (void)DidAuthRefreshed:(WeiboApi *)wbapi_
{
    
}

- (void)DidAuthRefreshFail:(NSError *)error
{
    
}

- (void)DidAuthFinished:(WeiboApi *)wbapi_
{
    
}

- (void)DidAuthCanceled:(WeiboApi *)wbapi_
{
    
}

- (void)DidAuthFailWithError:(NSError *)error
{
    
}

-(void)progressCallback:(IOSProgressCallbackData*)obj
{
    
}

-(void)uploadCompleteCallback:(GeeUploadResult*)gr obj:(IGeeUploadData*)obj
{
    
}





@end
