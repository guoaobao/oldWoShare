//
//  CommentCell.m
//  HappyShare
//
//  Created by Lin Pan on 13-4-12.
//  Copyright (c) 2013年 Lin Pan. All rights reserved.
//

#import "CommentCell.h"
#import <QuartzCore/QuartzCore.h>
#import "FVKit.h"
@implementation CommentCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        _headImageView = [[EGOImageView alloc] initWithPlaceholderImage:kBoyHeadImage];
        _headImageView.frame = CGRectMake(21,10 , 27, 27);
        CALayer *layer = [_headImageView layer];
        [layer setMasksToBounds:YES];
        [layer setCornerRadius:3.0];
        [self.contentView addSubview:_headImageView];
        
        _titleLbl = [[UILabel alloc] initWithFrame:CGRectMake(57, 10, 190, 13)];
        _titleLbl.backgroundColor = [UIColor clearColor];
        _titleLbl.font = [UIFont systemFontOfSize:13];
        [self.contentView addSubview:_titleLbl];
        
        _commentLbl = [[UILabel alloc] initWithFrame:CGRectMake(57, 23, 190, 16)];
        _commentLbl.backgroundColor = [UIColor clearColor];
        _commentLbl.font = [UIFont systemFontOfSize:11];
        _commentLbl.numberOfLines = 0;
        _commentLbl.textColor = [UIColor grayColor];
    
        [self.contentView addSubview:_commentLbl];
        
        _timeLbl = [[UILabel alloc] initWithFrame:CGRectMake(57, 43, 80, 12)];
        _timeLbl.backgroundColor = [UIColor clearColor];
        _timeLbl.font = [UIFont systemFontOfSize:9];
        _timeLbl.textColor = [UIColor grayColor];
        [self.contentView addSubview:_timeLbl];
        
        _lineImageView = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"line.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 0, 0, 1)]];
        _lineImageView.frame = CGRectMake(0, self.contentView.frame.size.height-1, self.contentView.frame.size.width, 1);
        [self.contentView addSubview:_lineImageView];
        
        [self addObserver:self forKeyPath:@"commentLbl.text" options:NSKeyValueObservingOptionNew context:nil];
        
    }
    return self;
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    self.commentLbl.frame = CGRectMake(57, 23, 190, [NSString caluLabelHeight:[change objectForKey:@"new"] contentWidth:190 fontsize:11]);
    self.timeLbl.frame = CGRectMake(57, self.commentLbl.frame.origin.y + self.commentLbl.frame.size.height+3, 80, 12);
    self.lineImageView.frame = CGRectMake(0, self.timeLbl.frame.origin.y + self.timeLbl.frame.size.height + 3, self.contentView.frame.size.width, 1);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


@end
