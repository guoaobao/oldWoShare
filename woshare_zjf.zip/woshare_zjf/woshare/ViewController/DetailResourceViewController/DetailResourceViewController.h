//
//  DetailResourceViewController.h
//  HappyShare
//
//  Created by Lin Pan on 13-4-15.
//  Copyright (c) 2013年 Lin Pan. All rights reserved.
//

#import "UIBaseViewController.h"
#import "ResourceInfo.h"
#import "ResourceDetailView.h"
#import "SinaWeibo.h"
#import <MessageUI/MFMessageComposeViewController.h>
#import "ReplyTipsView.h"
@interface DetailResourceViewController : UIBaseViewController<UITableViewDataSource,UITableViewDelegate,ResourceDetailViewDelegate,SinaWeiboDelegate,SinaWeiboRequestDelegate,UIActionSheetDelegate,MFMessageComposeViewControllerDelegate>
{
    BOOL _bCommenting; //标记键盘是否升起
    BOOL _bShareing;
    ReplyTipsView   *replyTips;
}
@property(retain,nonatomic)ResourceInfo *resourceInfo;
@property(retain,nonatomic)NSString *playUrl;
@property(retain,nonatomic)UITableView *tableView;
@property(retain,nonatomic)IBOutlet UIView *commentView;
@property(retain,nonatomic)IBOutlet UITextField *commentTF;
@property(retain,nonatomic)NSMutableArray *commentList;
@property(copy,nonatomic) NSString *responsingCommentId; //当前正在回复的评论对象
@property(retain,nonatomic)ResourceDetailView *resourceDetailView;
@property(copy,nonatomic)NSString *eventId;
- (IBAction)sendComment:(id)sender;
- (IBAction)commentTFClick:(id)sender;
- (IBAction)textChange:(id)sender;


@end
