//
//  CommentCell.h
//  HappyShare
//
//  Created by Lin Pan on 13-4-12.
//  Copyright (c) 2013年 Lin Pan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EGOImageView.h"
@interface CommentCell : UITableViewCell

@property(retain,nonatomic) EGOImageView *headImageView;
@property(retain,nonatomic) UILabel *titleLbl;
@property(retain,nonatomic) UILabel *commentLbl;
@property(retain,nonatomic) UILabel *timeLbl;
@property(retain,nonatomic) UIImageView *lineImageView;
@end
