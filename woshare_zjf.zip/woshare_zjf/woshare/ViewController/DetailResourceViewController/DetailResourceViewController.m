//
//  DetailResourceViewController.m
//  HappyShare
//
//  Created by Lin Pan on 13-4-15.
//  Copyright (c) 2013年 Lin Pan. All rights reserved.
//

#import "DetailResourceViewController.h"
#import "CommentResponse.h"
#import "CommentCell.h"
#import "LoginViewController.h"
#import "EGOPhotoGlobal.h"
#import "MyPhoto.h"
#import "MyPhotoSource.h"
#import "ZoneViewController.h"
#import "SinaWeibo.h"
#import "SNSShareViewController.h"
#import "ShowGifViewController.h"
#import "ReportResourceViewController.h"
#import "PhotoPreviewViewController.h"
#import "MusicViewController.h"
#import "MovieViewController.h"
#import "FVKit.h"
@interface DetailResourceViewController ()
{
    CGRect      inputViewRect;
}
@end

#define kReplyTipsViewTag 10001
@implementation DetailResourceViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self hideTabbar];
    [self.commentTF resignFirstResponder];
    [self getComments];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self.tableView reloadData];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self hideTabbar];
    [self initBgImage];
    [self initNavigationBar];
    [self initBackButton];
    [self initNaviRefreshBtn];

    self.title = @"详情";
    //上报点击
    [self reportClicked];
    UITableView *tableView=nil;
    if (ISOS7()) {
         tableView= [[UITableView alloc] initWithFrame:CGRectMake(0, 44+20, 320, kWindowFrame.size.height - 108)];
    }
    else
    {
        tableView= [[UITableView alloc] initWithFrame:CGRectMake(0, 44, 320, kWindowFrame.size.height - 108)];
    }
    
    
    tableView.backgroundColor = [UIColor clearColor];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.bounces = NO;
    tableView.separatorStyle = UITableViewCellSelectionStyleNone;
    self.tableView = tableView;
    [self.view addSubview:self.tableView];

    //初始化资源详细的View
    ResourceDetailView *resource = [[ResourceDetailView alloc] initWithFrame:CGRectMake(0, 0, 320, 286)];
    resource.delegate = self;
    [resource setFavorite:YES];
    [resource setCollect:YES];
    
    if (self.resourceInfo.reviweStatus == kReviewNo)
    {
        [resource setBrief:[NSString stringWithFormat:@"未通过审核: %@",self.resourceInfo.reviewDesc]];
        resource.briefLbl.textColor = [UIColor redColor];
    }
    else
    {
        [resource setBrief: [self.resourceInfo.brief length] > 0? self.resourceInfo.brief:[Config shareInstance].defaultResourceBrief];   
    }
    [resource setFavoriteCount:self.resourceInfo.likedCount];
    [resource setCommmentCount:[NSString stringWithFormat:@"%lu",(unsigned long)[self.commentList count]]];
    [resource setIsVideo:(self.resourceInfo.type == kResourceVideo)||(self.resourceInfo.type == kResourceVoice)? YES : NO];
    if (self.resourceInfo.type == kResourceVoice) {
        resource.resourceImgView.placeholderImage = [UIImage imageNamed:@"mp3_big"];
    }
    else
        resource.resourceImgView.placeholderImage = kPlaceholderRectangleImage;
    [resource setIsVideo:self.resourceInfo.type == kResourceVoice? YES : NO];
    resource.resourceImgView.imageURL = [NSURL URLWithString:[self.resourceInfo getMidImageURlString]];
    [resource setUserName:self.resourceInfo.userinfo.username];
    resource.headImgView.imageURL = [NSURL URLWithString:self.resourceInfo.userinfo.avatar];
    resource.timeLbl.text = self.resourceInfo.publishTime;
    if ([self.eventId length] > 0)
    {
        [resource isShowVote:YES];
        [resource.voteBtn setVoteNum:[self.resourceInfo.voteCount intValue]];
    }
    self.tableView.tableHeaderView = resource;
    self.resourceDetailView = resource;
    
    
    

    
    [self getComments];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)navigationDoneButtonAction:(id)sender
{
    [self getComments];
}

-(void)viewDidDisappear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    [super viewDidDisappear:animated];
}

#pragma mark - UITableView Delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CommentResponse *comment = (CommentResponse *)[self.commentList objectAtIndex:indexPath.row];
    return [NSString caluLabelHeight:comment.comment contentWidth:190 fontsize:11] + 38;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return [self.commentList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"Cell";
    CommentResponse *comment = [self.commentList objectAtIndex:indexPath.row];
    CommentCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[CommentCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 41, 21)];
        [button setBackgroundImage:[UIImage imageNamed:@"comment_response_btn.png"] forState:UIControlStateNormal];
        [button setBackgroundImage:[UIImage imageNamed:@"comment_response_btn_down.png"] forState:UIControlStateHighlighted];
        [button setBackgroundImage:[UIImage imageNamed:@"comment_response_btn_down.png"] forState:UIControlStateSelected];
        [button setTitle:@"回复" forState:UIControlStateNormal];
        [button.titleLabel setFont:[UIFont systemFontOfSize:13]];
        [button addTarget:self action:@selector(responseComment:) forControlEvents:UIControlEventTouchUpInside];
        cell.accessoryView = button;
        
    }
    
    cell.accessoryView = nil;
    if ([[RequestManager sharedManager].userInfo.uid isEqualToString:comment.auid])
    {
        cell.accessoryView = nil;
    }
    else
    {
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 41, 21)];
        [button setBackgroundImage:[UIImage imageNamed:@"comment_response_btn.png"] forState:UIControlStateNormal];
        [button setBackgroundImage:[UIImage imageNamed:@"comment_response_btn_down.png"] forState:UIControlStateHighlighted];
        [button setBackgroundImage:[UIImage imageNamed:@"comment_response_btn_down.png"] forState:UIControlStateSelected];
        [button setTitle:@"回复" forState:UIControlStateNormal];
        [button.titleLabel setFont:[UIFont systemFontOfSize:13]];
        [button addTarget:self action:@selector(responseComment:) forControlEvents:UIControlEventTouchUpInside];
        cell.accessoryView = button;
    }

    
    
    NSString *titleStr;
    if ([comment.runm length] > 0)
    {
        titleStr = [NSString stringWithFormat:@"%@ 回复 %@:",comment.aunm,comment.runm];
    }
    else
    {
        titleStr = [comment.aunm length]>0? comment.aunm : @"游客";
    }
    cell.titleLbl.text = titleStr;
    cell.commentLbl.text = comment.comment;
    cell.timeLbl.text = [NSString stringWithDate:[NSDate dateWithTimeIntervalSince1970:comment.sst] formater:@"yyyy-MM-dd hh:mm"];
    cell.headImageView.imageURL = [NSURL URLWithString:comment.userInfo.avatar];
    
    ((UIButton *)cell.accessoryView).tag = indexPath.row;
    cell.backgroundColor = [UIColor clearColor];
    cell.contentView.backgroundColor = [UIColor clearColor];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CommentResponse *comment = [self.commentList objectAtIndex:indexPath.row];
    if (comment.userInfo)
    {
        ZoneViewController *zoneVC = [[ZoneViewController alloc] initWithNibName:@"ZoneViewController" bundle:nil];
        zoneVC.userInfo = comment.userInfo;
        [self.navigationController pushViewController:zoneVC animated:YES];
    }
    else
    {
        [self toast:@"用户不存在"];
    }
    
}

- (void)responseComment:(id)sender
{
    if (![RequestManager sharedManager].isLogined) {
        [[AppDelegate sharedAppDelegate]showLoginFrom:self];
        return;
    }
    UIButton *btn = (UIButton *)sender;
    int tag = btn.tag;
    CommentResponse *comment = [self.commentList objectAtIndex:tag];
    self.responsingCommentId = comment._id;
    
    self.commentTF.placeholder = @"";
    [self.commentTF becomeFirstResponder];
    
    //加上回复对象的提示
    if (!replyTips)
    {
        replyTips = [[ReplyTipsView alloc] initWithFrame:CGRectMake(0, 347+(FVIsIPhone5()?88+44:44), 320, 30)];
        replyTips.tag = kReplyTipsViewTag;
    }
    else
        replyTips.hidden = NO;
    
    replyTips.replyUsernameLbl.text = [NSString stringWithFormat:@"回复%@:",comment.aunm];
    [self.view addSubview:replyTips];
}



- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    
}


#pragma mark - ResourceDetailViewDelegate
- (void)resourceFavoriteClicked:(id)resourceView
{
    [self addFavorite];
}
- (void)resourceCommentClicked:(id)resourceView
{
    [self.commentTF becomeFirstResponder];
}
- (void)resourceCollectClicked:(id)resourceView
{
    [self addCollect];
}
- (void)resourcePlayClicked:(id)resourceView
{
    if (self.resourceInfo.type == kResourceVideo || self.resourceInfo.type == kResourceVoice || [self.resourceInfo.ext isEqualToString:@"gif"])
    {
        if ([self.playUrl length] > 0)
        {
            if (self.resourceInfo.type == kResourceVideo || self.resourceInfo.type == kResourceVoice)
            {
                [self playVideo:self.playUrl];
            }
            else if ([self.resourceInfo.ext isEqualToString:@"gif"])
            {
                [self showGif:self.playUrl];
            }
            else if (self.resourceInfo.type == kResourceVoice)
            {
                [self playMusic:0];
            }
        }
        else
        {
            [self getVideoPlayUrl];
        }
    }
    else if(self.resourceInfo.type == kResourcePicture)
    {
        if ([self.playUrl length]>0) {
            PhotoPreviewViewController *pvc = [[PhotoPreviewViewController alloc]initWithNibName:@"PhotoPreviewViewController" bundle:nil];
            [self hideTabbar];
            [self.navigationController pushViewController:pvc animated:YES];
            [pvc startLoadImage:self.resourceInfo withFid:self.resourceInfo.fid];
        }
        else
        {
            if ([self.resourceInfo.fsize floatValue]<100*1024) {
                [self getVideoPlayUrl];
            }
            else
            {
                PhotoPreviewViewController *pvc = [[PhotoPreviewViewController alloc]initWithNibName:@"PhotoPreviewViewController" bundle:nil];
                [self hideTabbar];
                [self.navigationController pushViewController:pvc animated:YES];
                [pvc startLoadImage:self.resourceInfo withFid:self.resourceInfo.fid];
            }
        }
    }
}

- (void)resourceHeadClicked:(id)resourceView
{
    ZoneViewController *zoneVC = [[ZoneViewController alloc] initWithNibName:@"ZoneViewController" bundle:nil];
    zoneVC.userInfo = self.resourceInfo.userinfo;
    [self.navigationController pushViewController:zoneVC animated:YES];
}
- (void)resourceShareClicked:(id)resourceView
{
    [self snsShareAction];
}

- (void)resourceVoteClicked:(id)resourceView
{
    if (![RequestManager sharedManager].isLogined)
    {
        [[AppDelegate sharedAppDelegate] showLoginFrom:self];
        return;
    }
    [self voteAction];
}
- (void)resourceReportClicked:(id)resourceView
{
    if (![RequestManager sharedManager].isLogined)
    {
        [[AppDelegate sharedAppDelegate] showLoginFrom:self];
        return;
    }
    
    ReportResourceViewController *reportVC = [[ReportResourceViewController alloc] initWithNibName:@"ReportResourceViewController" bundle:nil];
    reportVC.nsid = self.resourceInfo.resourceId;
    [self.navigationController pushViewController:reportVC animated:YES];
    reportVC.title = @"举报";
}

#pragma mark Private
- (void)sinaShare
{
    [super sinaShare];
    SNSShareViewController *sinaShareVC = [[SNSShareViewController alloc] initWithNibName:@"SNSShareViewController" bundle:nil];
    sinaShareVC.shareTag = 1;
    sinaShareVC.resource = self.resourceInfo;
    if (self.resourceInfo.type == kResourceVideo)
    {
        sinaShareVC.videoUrl = self.playUrl;
    }
    [self.navigationController pushViewController:sinaShareVC animated:YES];
    sinaShareVC.title = @"新浪微博分享";
}

-(void)copyLinkAction
{
    [super copyLinkAction];
    NSString *content = [NSString stringWithFormat:@"%@%@",[Config shareInstance].sinaShareInfoLink,self.resourceInfo.resourceId];
    [[UIPasteboard generalPasteboard] setPersistent:YES];
    [[UIPasteboard generalPasteboard] setValue:content forPasteboardType:[UIPasteboardTypeListString objectAtIndex:0]];
}

-(void)qzoneShare
{
    [super qzoneShare];
    SNSShareViewController *sinaShareVC = [[SNSShareViewController alloc] initWithNibName:@"SNSShareViewController" bundle:nil];
    sinaShareVC.shareTag = 2;
    sinaShareVC.resource = self.resourceInfo;
    sinaShareVC.isInfo = NO;
    if (self.resourceInfo.type == kResourceVideo)
    {
        sinaShareVC.videoUrl = self.playUrl;
    }
    [self.navigationController pushViewController:sinaShareVC animated:YES];
    sinaShareVC.title = @"QQ分享";
}


-(void)tencentShare
{
    [super tencentShare];
    SNSShareViewController *sinaShareVC = [[SNSShareViewController alloc] initWithNibName:@"SNSShareViewController" bundle:nil];
    sinaShareVC.shareTag = 3;
    sinaShareVC.resource = self.resourceInfo;
    sinaShareVC.isInfo = NO;
    if (self.resourceInfo.type == kResourceVideo)
    {
        sinaShareVC.videoUrl = self.playUrl;
    }
    [self.navigationController pushViewController:sinaShareVC animated:YES];
    sinaShareVC.title = @"腾讯微博分享";
}

- (void)smsShare
{
    [super smsShare];
    [self initSMS];
    if (accessGranted) {
        Class messageClass = (NSClassFromString(@"MFMessageComposeViewController"));
        
        if (messageClass != nil && [messageClass canSendText])
        {
            NSString *content ;
            content = [NSString stringWithFormat:@"%@ %@%@",[Config shareInstance].smsShareContent,[Config shareInstance].smsShareLink,self.resourceInfo.resourceId];
            MFMessageComposeViewController *picker = [[MFMessageComposeViewController alloc] init];
            picker.messageComposeDelegate = self;
            picker.body = content;
            [self presentViewController:picker animated:YES completion:nil];
        }
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"授权提示"
                                                        message:LJSMSALERTTEXT
                                                       delegate:nil
                                              cancelButtonTitle:nil
                                              otherButtonTitles:@"确定", nil];
        alert.tag = 100202;
        [alert show];
    }
}

-(void)WXShare
{
    [super WXShare];
    [[WXManager shareInstance] setScene:WXSceneSession];
    NSString *content = [NSString stringWithFormat:@"%@ %@%@",[Config shareInstance].sinaShareContent,[Config shareInstance].sinaShareInfoLink,self.resourceInfo.resourceId];
    UIImage *newsImage = [UIImage imageFromURLString:[self.resourceInfo getSmallestImageURLString]];
    [[WXManager shareInstance] sendNewsContent:content title:self.resourceInfo.title thumbImage:newsImage webPageUrl:[NSString stringWithFormat:@"%@%@",[Config shareInstance].sinaShareInfoLink,self.resourceInfo.resourceId]];
}

-(void)timeLineShare
{
    [super timeLineShare];
    [[WXManager shareInstance] setScene:WXSceneTimeline];
    NSString *content = [NSString stringWithFormat:@"%@ %@%@",[Config shareInstance].sinaShareContent,[Config shareInstance].sinaShareInfoLink,self.resourceInfo.resourceId];
    UIImage *newsImage = [UIImage imageFromURLString:[self.resourceInfo getSmallestImageURLString]];
    [[WXManager shareInstance] sendNewsContent:content title:self.resourceInfo.title thumbImage:newsImage webPageUrl:[NSString stringWithFormat:@"%@%@",[Config shareInstance].sinaShareInfoLink,self.resourceInfo.resourceId]];
}

#pragma mark - IBAction
#pragma mark 键盘监听
- (void)keyboardWillShow:(NSNotification *)notification
{
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        NSValue *keyboardBoundsValue = [[notification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey];
        
        CGRect keyboardBounds;
        [keyboardBoundsValue getValue:&keyboardBounds];
        NSInteger offset =self.view.frame.size.height-keyboardBounds.origin.y;
        NSInteger os7 = ISOS7()?0:20;
        offset = offset + os7;
        CGRect listFrame = CGRectMake(0, -offset, self.view.frame.size.width,self.view.frame.size.height);
        
        [UIView beginAnimations:@"anim" context:NULL];
        [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
        [UIView setAnimationBeginsFromCurrentState:YES];
        [UIView setAnimationDuration:0.3];
        //处理移动事件，将各视图设置最终要达到的状态
        self.view.frame=listFrame;
        _bCommenting = YES;
//        self.commentView.frame = CGRectMake(0, self.commentView.top - offset, self.commentView.width, self.commentView.height);
        [UIView commitAnimations];
    }
}
- (void)keyboardWillHide:(NSNotification *)notification
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [self.view setFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    _bCommenting = NO;
    self.commentTF.placeholder = @"我想说两句";
    
    [UIView commitAnimations];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self sendComment:nil];
    
    return [super textFieldShouldReturn:textField];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (!textField.window.isKeyWindow) {
        [textField.window makeKeyAndVisible];
    }
    if (![RequestManager sharedManager].isLogined)
    {
        [self.commentTF resignFirstResponder];
        [[AppDelegate sharedAppDelegate]showLoginFrom:self];
        return;
    }
}

- (IBAction)textChange:(id)sender
{
    if ([self.commentTF.text length] > 0)
    {
        self.commentTF.keyboardType = UIReturnKeySend;
    }
    else
    {
        self.commentTF.keyboardType = UIReturnKeyDone;
    }
}


- (IBAction)commentTFClick:(id)sender
{
    if (_bCommenting) {
        [self.commentTF resignFirstResponder];
    }
}

- (void)playVideo:(NSString *)url
{
    NSMutableArray *array = [[NSMutableArray alloc]initWithCapacity:0];
    [array addObject:self.resourceInfo.playUrl];
    MovieViewController *mvc = [[MovieViewController
                                 alloc]initWithNibName:@"MovieViewController" bundle:nil];
    UIBaseNavigationController *nav = [[UIBaseNavigationController alloc]initWithRootViewController:mvc];
    nav.navigationBarHidden = YES;
    [self presentViewController:nav animated:YES completion:nil];
    [mvc startLoadMovie:array withIndex:0];
}

-(void)playMusic:(int)index
{
    NSMutableArray *array = [[NSMutableArray alloc]initWithCapacity:0];
    if (self.resourceInfo.type==kResourceVoice) {
        MusicObject *music = [[MusicObject alloc]init];
        music.imageUrl = [self.resourceInfo getBiggestImageURLString];
        music.songName = self.resourceInfo.name;
        music.userName = self.resourceInfo.userinfo.username;
        music.songUrl  = self.resourceInfo.playUrl;
        [array addObject:music];
    }
    MusicViewController *mvc = [[MusicViewController
                                 alloc]initWithNibName:@"MusicViewController" bundle:nil];
    
    [self.navigationController pushViewController:mvc
                                         animated:YES];
    mvc.title = @"音乐播放";
    [mvc startLoadMusic:array withIndex:index];
}

- (void)showGif:(NSString *)url
{
    ShowGifViewController *gifVC = [[ShowGifViewController alloc] initWithNibName:@"ShowGifViewController" bundle:nil];
    gifVC.gifURLStr = self.playUrl;
    [self.navigationController pushViewController:gifVC animated:YES];
}

- (void)showShareViewController
{

}

#pragma mark - SMSDelegate
// 处理发送完的响应结果
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    [self dismissViewControllerAnimated:YES completion:nil];
    if (result == MessageComposeResultCancelled)
        FVLog(@"Message cancelled");
    else if (result == MessageComposeResultSent)
        FVLog(@"Message sent");
    else
        FVLog(@"Message failed")  ;
    
}



#pragma mark - HttpRequest
- (void)getComments
{
    [self showIndicator];
    NSDictionary *dic = @{@"id": self.resourceInfo.resourceId,
                          @"getuserinfo":kRequestGetUserInfo,
                          @"getcomment":@"1"};
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetCommentList withData:dic];
}

- (IBAction)sendComment:(id)sender
{
    
    [self.commentTF resignFirstResponder];
    if ([self.commentTF.text length] == 0)
    {
        [self toast:@"评论不能为空哦"];
        return;
    }
    else if ([self.commentTF.text length] < 2 && [self.commentTF.text length] > 140)
    {
        [self toast:@"评论需为2-140个字符"];
        return;
    }
    [self showIndicator];
    NSDictionary *dic = @{@"id": self.resourceInfo.resourceId,
                          @"content":self.commentTF.text,
                          @"cid":[self.view viewWithTag:kReplyTipsViewTag]? self.responsingCommentId : @""
                          };

    
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeAddComment withData:dic];
    self.commentTF.text = nil;
    replyTips.hidden = YES;
}

- (void)addFavorite
{
    
    if (![RequestManager sharedManager].isLogined)
    {
        [[AppDelegate sharedAppDelegate] showLoginFrom:self];
        return;
    }
    
    NSDictionary *dic = @{@"nsid": self.resourceInfo.resourceId};
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeLikens withData:dic];
}

- (void)addCollect
{
    if (![RequestManager sharedManager].isLogined)
    {
        [[AppDelegate sharedAppDelegate] showLoginFrom:self];
        return;
    }
    
    NSDictionary *dic = @{@"favid": self.resourceInfo.resourceId,
                          @"idtype":@"resource",
                          @"topid":@"0"};
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeAddFavorite withData:dic];
}

- (void)getVideoPlayUrl
{
    [self showIndicator];
    NSDictionary *dic = @{@"nsid": self.resourceInfo.resourceId};
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetDownloadURL withData:dic];
}

- (void)voteAction
{
    [self showIndicator];
    NSDictionary *dic = @{
                          @"nsid": self.resourceInfo.resourceId,
                          @"eventid":self.eventId};
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeVote withData:dic];
}

- (void)reportClicked
{
    NSDictionary *dic = @{@"nsid": self.resourceInfo.resourceId};
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeClickns withData:dic];
}

#pragma mark request callback
-(void)webServiceRequest:(RequestType)requestType response:(id)response userData:(id)userData originalData:(id)data
{
    [self hideIndicator];
    if(requestType == kRequestTypeGetCommentList){
        self.commentList = [NSMutableArray arrayWithArray:response];
        [self.tableView reloadData];
        [self.resourceDetailView.commentBtn setTitle:[NSString stringWithFormat:@"%lu",(unsigned long)[self.commentList count]] forState:UIControlStateNormal];

    }
    else if (requestType == kRequestTypeAddComment)
    {
        [self getComments];
    }
    else if (requestType == kRequestTypeLikens)
    {
        [self toast:@"爱意表达成功"];
        int favoriteCount = [self.resourceInfo.likedCount intValue] + 1;
        [self.resourceDetailView setFavoriteCount:[NSString stringWithFormat:@"%d",favoriteCount]];
        [self.resourceDetailView setFavorite:YES];
    }
    else if (requestType == kRequestTypeAddFavorite)
    {
        [self toast:@"收藏资源成功"];
        [self.resourceDetailView setCollect:YES];
    }
    else if (requestType == kRequestTypeGetDownloadURL)
    {
        if (_bShareing)
        {
            _bShareing = NO;
            [self showShareViewController];
        }
        else
        {
            self.playUrl = response;
            if ([self.resourceInfo.ext isEqualToString:@"gif"])
            {
                [self showGif:self.playUrl];
            }
            else if (self.resourceInfo.type == kResourceVideo || self.resourceInfo.type == kResourceVoice)
            {
                [self playVideo:self.playUrl];
            }
            else
            {
                self.resourceInfo.playUrl = response;
                PhotoPreviewViewController *pvc = [[PhotoPreviewViewController alloc]initWithNibName:@"PhotoPreviewViewController" bundle:nil];
                [self hideTabbar];
                [self.navigationController pushViewController:pvc animated:YES];
                [pvc startLoadImage:self.resourceInfo withFid:self.resourceInfo.fid];
            }
        }
    }
    else if (requestType == kRequestTypeVote)
    {
        [self toast:@"投票成功"];
        int voteCount = [self.resourceInfo.voteCount intValue];
        self.resourceInfo.voteCount =  [NSString stringWithFormat:@"%d", voteCount];
        [self.resourceDetailView.voteBtn setVoteNum:++voteCount];
    }
}

@end
