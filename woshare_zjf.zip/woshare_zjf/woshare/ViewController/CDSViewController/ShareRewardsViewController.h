//
//  ShareRewardsViewController.h
//  HappyShareSE
//
//  Created by 胡波 on 13-12-12.
//  Copyright (c) 2013年 胡 波. All rights reserved.
//

#import "UIBaseViewController.h"
#import "WeiboFriendViewController.h"

@protocol ShareRewardsDelegate <NSObject>

-(void)shareRewardsSuccess;
-(void)shareRewardsCancel;
@end
@interface ShareRewardsViewController : UIBaseViewController <WeiboFriendChooseDelegate,WeiboRequestDelegate,SinaWeiboDelegate>
{
    NSMutableArray  *friendsArray;
    NSMutableArray  *chooseArray;
    WeiboFriendViewController *wvc;
    int oldsharetype;
}

@property (nonatomic,assign)int         shareType;
@property (nonatomic,strong)NSString    *content;
@property (nonatomic,strong)NSString    *url;
@property (nonatomic,strong)IBOutlet    UITextView  *textView;
@property (nonatomic,assign)id<ShareRewardsDelegate> delegate;
-(IBAction)AtAction:(id)sender;
@end
