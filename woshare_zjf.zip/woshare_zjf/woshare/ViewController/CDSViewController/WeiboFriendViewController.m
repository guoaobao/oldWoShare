//
//  WeiboFriendViewController.m
//  HappyShareSE
//
//  Created by 胡波 on 13-12-11.
//  Copyright (c) 2013年 胡 波. All rights reserved.
//

#import "WeiboFriendViewController.h"
#import "SinaWeibo.h"
#import <TencentOpenAPI/sdkdef.h>
#import <TencentOpenAPI/TencentOAuthObject.h>
#import "TencentOpenAPI/QQApiInterface.h"
#import "WBFriendCell.h"
#import "FriendObject.h"
#import "JSONKit.h"
@interface WeiboFriendViewController () <SinaWeiboRequestDelegate,SinaWeiboDelegate>
{
    int cursor;
}
@end

@implementation WeiboFriendViewController
@synthesize friendsArray=friendsArray,chooseArray=chooseArray;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        friendsArray = [[NSMutableArray alloc]initWithCapacity:0];
        chooseArray = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self initNavigationBar];
    [self initBackButton];
    [self initNaviDoneBtn];
    [self hideTabbar];
    self.title = @"好友选择";
    sinaWeibo = [self getSinaWeibo];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //    if (_shareType == 1) {
    //        sinaWeibo.delegate = self;
    //        [self sinaGetFriendCursor:cursor];
    //    }
    //    else if (_shareType == 2)
    //    {
    //        [self tencentGetFriend:cursor];
    //    }
    //    [self showIndicator];
    [tableView_ reloadData];
}

-(void)viewWillDisappear:(BOOL)animated
{
    //    if (_shareType == 1) {
    //        sinaWeibo.delegate = nil;
    //    }
    //    else if (_shareType == 2)
    //    {
    //
    //    }
    [super viewWillDisappear:animated];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)navigationDoneButtonAction:(id)sender
{
    if ([chooseArray count]>=3) {
        if (_delegate && [_delegate respondsToSelector:@selector(chooseFinishWithArray:)]) {
            [self.delegate chooseFinishWithArray:chooseArray];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
    else
        [self showTips:@"悦分享" message:@"请至少@三位好友，谢谢!"];
}

#pragma mark - tableview datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [friendsArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"WBFriendCell";
    WBFriendCell *cell = (WBFriendCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"WBFriendCell" owner:self options:nil] objectAtIndex:0];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    FriendObject *fo = [friendsArray objectAtIndex:indexPath.row];
    cell.nameLabel.text = fo.userName;
    cell.headView.placeholderImage = kBoyHeadImage;
    cell.headView.imageURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@/50",fo.headURL]];
    [cell.selectedButton setSelected:fo.selected];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    FriendObject *fo = [friendsArray objectAtIndex:indexPath.row];
    fo.selected = !fo.selected;
    if (fo.selected) {
        [chooseArray addObject:fo];
    }
    else
        [chooseArray removeObject:fo];
    [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}

//-(void)tencentGetFriend:(int)startIndex
//{
//    if (self.wbApi.isAuthValid) {
//        NSMutableDictionary *params = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"json",@"format",@"30", @"reqnum",[NSString stringWithFormat:@"%d",startIndex*3], @"startindex",nil];
//        [self.wbApi requestWithParams:params apiName:@"friends/idollist" httpMethod:@"GET" delegate:self];
//    }
//    else
//    {
//        [self.wbApi loginWithDelegate:self andRootController:self];
//    }
//}
//
//-(void)sinaGetFriendCursor:(int)next_cursor
//{
//    NSMutableDictionary *params = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"100",@"count",[NSString stringWithFormat:@"%d",next_cursor], @"cursor",sinaWeibo.userID,@"uid",[Config shareInstance].sinaAppKey,@"source",nil];
//    [sinaWeibo requestWithURL:@"friendships/friends.json"
//                           params:params
//                       httpMethod:@"GET"
//                         delegate:self];
//
//}
//
//-(void)randomNum
//{
//    for (int i = 0; i<3; i++) {
//        int value = (arc4random() % [friendsArray count]) + 1;
//        FriendObject *fo = [friendsArray objectAtIndex:value];
//        fo.selected = YES;
//    }
//}
//
//#pragma mark - sinaweibo delegate
//- (void)request:(SinaWeiboRequest *)request didFailWithError:(NSError *)error
//{
//    if ([request.url hasSuffix:@"friendships/friends.json"])
//    {
//        [self toast:error.description];
//    }
//}
//
//- (void)request:(SinaWeiboRequest *)request didFinishLoadingWithResult:(id)result
//{
//    if ([request.url hasSuffix:@"friendships/friends.json"])
//    {
//        NSString *errorCode = [result objectForKey:@"error_code"];
//        if (errorCode)
//        {
//
//        }
//        else
//        {
//            NSDictionary *dic = (NSDictionary *)result;
//            NSArray *array = [dic objectForKey:@"users"];
//            for (NSDictionary *obj in array) {
//                FriendObject *fo = [[FriendObject alloc]init];
//                fo.headURL = [obj objectForKey:@"avatar_large"];
//                fo.userName = [obj objectForKey:@"screen_name"];
//                [friendsArray addObject:fo];
//            }
//
//            if ([[dic objectForKey:@"next_cursor"]integerValue]>0) {
//                [self sinaGetFriendCursor:[[dic objectForKey:@"next_cursor"]integerValue]];
//            }
//            else
//            {
//                [self randomNum];
//                [tableView_ reloadData];
//                [self hideIndicator];
//            }
//        }
//    }
//
//}
//
//#pragma mark - tencentweibo delegate
//- (void)didReceiveRawData:(NSData *)data reqNo:(int)reqno
//{
//    NSDictionary *dic = [data objectFromJSONData];
//    NSDictionary *dataDic = [dic objectForKey:@"data"];
//    NSArray *info = [dataDic objectForKey:@"info"];
//    for(NSDictionary *obj in info)
//    {
//        FriendObject *fo = [[FriendObject alloc]init];
//        fo.headURL = [obj objectForKey:@"head"];
//        fo.userName = [obj objectForKey:@"nick"];
//        [friendsArray addObject:fo];
//    }
//    if (![[dataDic objectForKey:@"hasnext"]integerValue]) {
//        [self tencentGetFriend:++cursor];
//    }
//    else
//    {
//        [self randomNum];
//        [tableView_ reloadData];
//        [self hideIndicator];
//    }
//}
//
//- (void)didFailWithError:(NSError *)error reqNo:(int)reqno
//{
//    NSLog(@"%@",[error localizedDescription]);
//}


@end
