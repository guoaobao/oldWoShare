//
//  PhoneViewController.m
//  HappyShareSE
//
//  Created by 胡 波 on 13-12-3.
//  Copyright (c) 2013年 胡 波. All rights reserved.
//

#import "PhoneViewController.h"
#import "CDSViewController.h"
#import "FVKit.h"
@interface PhoneViewController ()

@end

@implementation PhoneViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self initBgImage];
    [self initNavigationBar];
    [self initBackButton];
    [self initNaviDoneBtn];
    self.title = @"验证手机号";
    int capthaTime = [[Config shareInstance].capthcaTime intValue];
    _countDown = capthaTime == 0? 120 : capthaTime;
    
    NSDate *preDate = [Config shareInstance].sendCaptchaTime;
    NSDate *nowDate = [NSDate date];
    NSTimeInterval timeDifference = [nowDate timeIntervalSinceDate:preDate];
    if (timeDifference < _countDown && timeDifference > 0)
    {
        self.captcha = [Config shareInstance].captchaString;
        _countDown = _countDown - timeDifference;
        self.sendCaptchaBtn.enabled = NO;
        [self.sendCaptchaBtn setTitle:[NSString stringWithFormat:@"%d秒后发送",_countDown] forState:UIControlStateNormal];
        [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(sendCaptchaCountDown:) userInfo:nil repeats:YES];
        
        self.phoneTF.text = [Config shareInstance].sendCapthcaPhone;
    }
    
    [self setHidesBottomBarWhenPushed:YES];
    if ([[RequestManager sharedManager].userInfo.mobile length]>0) {
        self.phoneTF.text = [RequestManager sharedManager].userInfo.mobile;
    }
    
}

- (void)initNaviDoneBtn
{
    _doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
    if (ISOS7()) {
        _doneButton.frame = CGRectMake(260, 20, 56, 44);
    }
    else
    {
        _doneButton.frame = CGRectMake(260, 0, 56, 44);
    }
//    [_doneButton setBackgroundImage:[UIImage imageNamed:@"back_btn_bg.png"] forState:UIControlStateNormal];
//    [_doneButton setBackgroundImage:[UIImage imageNamed:@"back_btn_bg_on.png"] forState:UIControlStateHighlighted];
//    [_doneButton setImage:[UIImage imageNamed:@"hs_cds_confirm_pic"] forState:UIControlStateNormal];
//    [_doneButton setImage:[UIImage imageNamed:@"hs_cds_confirmdown_pic"] forState:UIControlStateHighlighted];
    [_doneButton.titleLabel setFont: [UIFont systemFontOfSize:18.0]];
    [_doneButton.titleLabel setTextColor:[UIColor blueColor]];
    [_doneButton setTitle:@"下一步" forState:UIControlStateNormal];
    [_doneButton setTitleColor:[UIColor colorWithRed:55/255 green:60/255 blue:79/255 alpha:1] forState:UIControlStateNormal];
    [_doneButton addTarget:self action:@selector(navigationDoneButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_doneButton];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)sendCaptchaCountDown:(id)sender
{
    NSTimer *timer = (NSTimer *)sender;
    if (_countDown-- > 0)
    {
        [self.sendCaptchaBtn setTitle:[NSString stringWithFormat:@"%d秒后重发",_countDown] forState:UIControlStateNormal];
    }
    else
    {
        [timer invalidate];
        [self.sendCaptchaBtn setTitle:@"发送验证码" forState:UIControlStateNormal];
        self.sendCaptchaBtn.enabled = YES;
    }
}

#pragma mark Button Click
- (IBAction)sendCaptcha:(id)sender{
    if ([NSString JudgmentMobilePhoneNumber:_phoneTF.text]) {
//        SendCaptchaParameter *sendCaptchaPmt = [[SendCaptchaParameter alloc] init];
//        sendCaptchaPmt.mobile = _phoneTF.text;
        [[RequestManager sharedManager] startRequestWithType:kRequestTypeSendCaptcha withData:[NSDictionary dictionaryWithObjectsAndKeys:_phoneTF.text,@"mobile",@"opt",@"type", nil]];
    }else{
        [self showTips:kBundleName message:@"请输入手机号码"];
    }
}


- (void)navigationDoneButtonAction:(id)sender
{
    [self.phoneTF resignFirstResponder];
    [self.captchaTF resignFirstResponder];
    NSString *phoneStr = [self.phoneTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *captchStr = [self.captchaTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if ([phoneStr length] == 0 || ![NSString JudgmentMobilePhoneNumber:phoneStr])
    {
        [self showTips:kBundleName message:@"请输入手机号码"];
    }
    else if([captchStr length] == 0)
    {
        [self showTips:kBundleName message:@"请输入验证码"];
    }
    else
    {
        if ([captchStr isEqualToString:self.captcha]) {
            //next page
            [Config shareInstance].cdsPhoneNumber = self.phoneTF.text;
            CDSViewController *cvc = [[CDSViewController alloc]initWithNibName:nil bundle:nil];
            cvc.data = [Config shareInstance].cdsUploadData;
            cvc.gift = [Config shareInstance].cdsGift;
            cvc.event = [Config shareInstance].cdsEvent;
            [self.navigationController pushViewController:cvc animated:YES];
        }
        else
            [self toast:@"验证码错误"];
    }
}

- (void)hideKeybord
{
    [self.phoneTF resignFirstResponder];
    [self.captchaTF resignFirstResponder];
}

#pragma mark request callback
-(void)webServiceRequest:(RequestType)requestType response:(id)response userData:(id)userData originalData:(id)data
{
    if (requestType == kRequestTypeSendCaptcha) {
        [self hideIndicator];
        NSString *captchaStr = (NSString*)response;
        self.captcha = captchaStr;
        NSLog(@"captcha %@",captchaStr);
        self.sendCaptchaBtn.enabled = NO;
        [self.sendCaptchaBtn setTitle:[NSString stringWithFormat:@"%d秒后重发",_countDown] forState:UIControlStateNormal];
        [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(sendCaptchaCountDown:) userInfo:nil repeats:YES];
        [Config shareInstance].sendCaptchaTime = [NSDate date];
        [Config shareInstance].sendCapthcaPhone = self.phoneTF.text;
        [Config shareInstance].captchaString = self.captcha;
    }
}

-(void)webServiceRequest:(RequestType)requestType error:(NSError *)error userData:(id)userData
{
    [self hideIndicator];
}

-(void)webServiceRequest:(RequestType)requestType errorString:(NSString*)errorString userData:(id)userData
{
    [self hideIndicator];
    [self toast:errorString];
}

-(void)webServiceRequest:(RequestType)requestType errorData:(NSDictionary*)errorData userData:(id)userData
{
    [self hideIndicator];
}

#pragma mark UITextField delegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    // When the user presses return, take focus away from the text field so that the keyboard is dismissed.
//    [super textFieldShouldReturn:textField];
    [self hideKeybord];
    if (textField == self.captchaTF)
    {
        [self navigationDoneButtonAction:nil];
    }
    return YES;
}

@end
