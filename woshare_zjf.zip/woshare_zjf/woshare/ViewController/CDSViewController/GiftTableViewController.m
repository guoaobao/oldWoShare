//
//  GiftTableViewController.m
//  HappyShareSE
//
//  Created by 胡 波 on 13-12-3.
//  Copyright (c) 2013年 胡 波. All rights reserved.
//

#import "GiftTableViewController.h"
#import "CDSViewController.h"
#import "PhoneViewController.h"
@interface GiftTableViewController ()

@end

@implementation GiftTableViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        giftArray = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self initBgImage];
    [self initNavigationBar];
    [self initBackButton];
//    [self initNaviDoneBtn];
    [self hideTabbar];
    self.title = @"选择礼品";
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.backgroundColor = [UIColor clearColor];
    [_tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if (![Config shareInstance].cdsEvent) {
        [self getActivityInfo:[Config shareInstance].cdsEventID];
    }
    else
    {
        [self showIndicator];
        [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetProductList withData:[NSDictionary dictionaryWithObjectsAndKeys:[Config shareInstance].cdsEventID,@"eventid", nil]];
    }
}

- (void)initNaviDoneBtn
{
    _doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _doneButton.frame = CGRectMake(272, 5, 44, 34);
    [_doneButton.titleLabel setFont: [UIFont systemFontOfSize:12.0]];
    [_doneButton.titleLabel setTextColor:[UIColor blueColor]];
    [_doneButton setTitle:@"下一步" forState:UIControlStateNormal];
    [_doneButton setTitleColor:[UIColor colorWithRed:55/255 green:60/255 blue:79/255 alpha:1] forState:UIControlStateNormal];
    [_doneButton addTarget:self action:@selector(navigationDoneButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_doneButton];
}

-(void)navigationDoneButtonAction:(id)sender
{
    CDSViewController *cvc = [[CDSViewController alloc]initWithNibName:nil bundle:nil];
    [self.navigationController pushViewController:cvc
                                         animated:YES];
}


-(void)buttonAction:(UIButton*)button
{
    GiftObject *gift = [giftArray objectAtIndex:button.tag];
    [Config shareInstance].cdsGift = gift;
    if ([gift.giftID integerValue]==4) {
        CDSViewController *cvc = [[CDSViewController alloc]initWithNibName:nil bundle:nil];
        cvc.data = [Config shareInstance].cdsUploadData;
        cvc.gift = [Config shareInstance].cdsGift;
        cvc.event = [Config shareInstance].cdsEvent;
        [self.navigationController pushViewController:cvc animated:YES];
        return;
    }
    if ([[Config shareInstance].cdsPhoneNumber length]==0) {
        PhoneViewController *pvc = [[PhoneViewController alloc]initWithNibName:nil bundle:nil];
        [self.navigationController pushViewController:pvc animated:YES];
    }
    else
    {
        CDSViewController *cvc = [[CDSViewController alloc]initWithNibName:nil bundle:nil];
        cvc.data = [Config shareInstance].cdsUploadData;
        cvc.gift = [Config shareInstance].cdsGift;
        cvc.event = [Config shareInstance].cdsEvent;
        [self.navigationController pushViewController:cvc animated:YES];
    }
}

- (void)getActivityInfo:(NSString*)eventId
{
    NSDictionary *dic = @{@"eventid": eventId};
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetEventInfo withData:dic];
}

#pragma mark - tableview datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [giftArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.accessoryView = nil;
    }
    GiftObject *obj = [giftArray objectAtIndex:indexPath.row];
    EGOImageButton  *imgBtn = [[EGOImageButton alloc]initWithFrame:CGRectMake(18, 15, 282, 85)];
    imgBtn.tag = indexPath.row;
    imgBtn.placeholderImage = kPlaceholderRectangleImage;
    imgBtn.imageURL = [NSURL URLWithString:obj.giftURL];
    [imgBtn addTarget: self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    cell.backgroundColor = [UIColor clearColor];
    cell.contentView.backgroundColor = [UIColor clearColor];
    [cell addSubview:imgBtn];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

}


#pragma mark request callback
-(void)webServiceRequest:(RequestType)requestType response:(id)response userData:(id)userData originalData:(id)data
{
    if (requestType == kRequestTypeGetProductList) {
        [self hideIndicator];
        NSDictionary *dict = [data objectForKey:@"data"];
        NSArray *keys = [dict allKeys];
        NSArray *array2 = [keys sortedArrayUsingComparator:^(id obj1, id obj2){
            if ([obj1 integerValue] > [obj2 integerValue]) {
                return (NSComparisonResult)NSOrderedAscending;
            }
            if ([obj1 integerValue] < [obj2 integerValue]) {
                return (NSComparisonResult)NSOrderedDescending;
            }
            return (NSComparisonResult)NSOrderedSame;
            
        }];
        [giftArray removeAllObjects];
        for (NSString *key in array2) {
            NSDictionary *dic = [dict objectForKey:key];
            GiftObject *go = [[GiftObject alloc]initWithDic:dic];
            [giftArray addObject:go];
        }
        [_tableView reloadData];
    }
    else if (requestType == kRequestTypeGetEventInfo) {
        [Config shareInstance].cdsEvent = (EventResponse*)response;
        [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetProductList withData:nil];
    }
}


@end
