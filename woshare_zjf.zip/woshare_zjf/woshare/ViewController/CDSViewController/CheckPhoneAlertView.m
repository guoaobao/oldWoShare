//
//  CheckPhoneAlertView.m
//  HappyShareSE
//
//  Created by 胡 波 on 13-12-4.
//  Copyright (c) 2013年 胡 波. All rights reserved.
//

#import "CheckPhoneAlertView.h"

@implementation CheckPhoneAlertView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
