//
//  WeiboFriendViewController.h
//  HappyShareSE
//
//  Created by 胡波 on 13-12-11.
//  Copyright (c) 2013年 胡 波. All rights reserved.
//

#import "UIBaseViewController.h"

@protocol WeiboFriendChooseDelegate <NSObject>

-(void)chooseFinishWithArray:(NSArray*)userArrary;

@end

@interface WeiboFriendViewController : UIBaseViewController
{
    SinaWeibo *sinaWeibo;
    IBOutlet UITableView *tableView_;
    NSMutableArray  *friendsArray;
    NSMutableArray  *chooseArray;
}
@property (nonatomic,assign)int     shareType;
@property (nonatomic,retain)NSMutableArray *friendsArray;
@property (nonatomic,retain)NSMutableArray *chooseArray;
@property (nonatomic,assign)id<WeiboFriendChooseDelegate> delegate;
@end
