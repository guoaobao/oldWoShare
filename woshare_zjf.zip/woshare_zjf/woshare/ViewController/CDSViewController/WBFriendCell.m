//
//  WBFriendCell.m
//  HappyShareSE
//
//  Created by 胡波 on 13-12-12.
//  Copyright (c) 2013年 胡 波. All rights reserved.
//

#import "WBFriendCell.h"

@implementation WBFriendCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

//- (void)setSelected:(BOOL)selected animated:(BOOL)animated
//{
//    [super setSelected:selected animated:animated];
//    [self.selectedButton setSelected:selected];
//    // Configure the view for the selected state
//}

@end
