//
//  PhoneViewController.h
//  HappyShareSE
//
//  Created by 胡 波 on 13-12-3.
//  Copyright (c) 2013年 胡 波. All rights reserved.
//

#import "UIBaseViewController.h"

@interface PhoneViewController : UIBaseViewController
{
    int  _countDown;
}
@property(retain,nonatomic)IBOutlet UITextField *phoneTF;
@property(retain,nonatomic)IBOutlet UITextField *captchaTF;
@property(retain,nonatomic)IBOutlet UIButton    *sendCaptchaBtn;
@property(retain,nonatomic)IBOutlet UILabel     *tipsLabel;
@property(copy,nonatomic) NSString *captcha;
- (IBAction)sendCaptcha:(id)sender;
@end
