//
//  ValentineViewController.h
//  HappyShareSE
//
//  Created by 胡波 on 14-2-12.
//  Copyright (c) 2014年 胡 波. All rights reserved.
//

#import "UIBaseViewController.h"
#import "UploadData.h"
#import "EGOImageView.h"
@interface ValentineViewController : UIBaseViewController<GeeUploadDelegate,WeiboRequestDelegate,SinaWeiboDelegate>
{
    NSString *phoneNumber;
}
@property (nonatomic,strong)IBOutlet    UITextField *phoneTextField;
@property (nonatomic,strong)IBOutlet    UITextField *nameTextField;
@property (nonatomic,strong)IBOutlet    EGOImageView *videoView;
@property (nonatomic,strong)IBOutlet    UIButton *sinaButton;
@property (nonatomic,strong)IBOutlet    UIButton *tencentButton;
@property (nonatomic,strong)UploadData  *data;
@property (nonatomic,strong)EventResponse   *event;
-(IBAction)sinaAction:(id)sender;
-(IBAction)tencentAction:(id)sender;
@end
