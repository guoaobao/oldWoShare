//
//  ShareRewardsViewController.m
//  HappyShareSE
//
//  Created by 胡波 on 13-12-12.
//  Copyright (c) 2013年 胡 波. All rights reserved.
//

#import "ShareRewardsViewController.h"
#import "WeiboFriendViewController.h"
#import "FriendObject.h"
#import "JSONKit.h"
@interface ShareRewardsViewController ()
{
    int cursor;
}
@end

@implementation ShareRewardsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        friendsArray = [[NSMutableArray alloc]initWithCapacity:0];
        chooseArray = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initNavigationBar];
    [self initBackButton];
    [self initNaviDoneBtn];
    self.title = @"分享";
    [self hideTabbar];
    self.textView.text = [NSString stringWithFormat:@"%@ %@",self.content,self.url];
    wvc = [[WeiboFriendViewController alloc]initWithNibName:nil bundle:nil];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if ([chooseArray count]==0) {
        if (_shareType == 1) {
            [self getSinaWeibo].delegate = self;
            [self sinaGetFriendCursor:cursor];
        }
        else if (_shareType == 2)
        {
            [self tencentGetFriend:cursor];
        }
        [self showIndicator];
    }
}

-(void)viewWillDisappear:(BOOL)animated
{
    if (_shareType == 1) {
        [self getSinaWeibo].delegate = nil;
    }
    else if (_shareType == 2)
    {
        
    }
    [super viewWillDisappear:animated];
}

-(void)backAction
{
    if (_delegate && [_delegate respondsToSelector:@selector(shareRewardsCancel)]) {
        [_delegate shareRewardsCancel];
    }
    //    [chooseArray removeAllObjects];
    //    [friendsArray removeAllObjects];
    [super backAction];
}

-(void)AtAction:(id)sender
{
    wvc.shareType = self.shareType;
    wvc.friendsArray = friendsArray;
    wvc.chooseArray = chooseArray;
    wvc.delegate = self;
    [self.navigationController pushViewController:wvc animated:YES];
}

-(void)chooseFinishWithArray:(NSArray *)userArrary
{
    chooseArray = [NSMutableArray arrayWithArray:userArrary];
    NSMutableString *str = [[NSMutableString alloc]init];
    for (FriendObject *obj in userArrary) {
        [str appendString:[NSString stringWithFormat:@" @%@",obj.userName]];
    }
    NSString *contents = [NSString stringWithFormat:@"%@%@%@",self.content,self.url,str];
    self.textView.text = contents;
}

-(void)navigationDoneButtonAction:(id)sender
{
    if (_shareType == 1) {
        [[self getSinaWeibo] requestWithURL:@"statuses/update.json"
        params:[NSMutableDictionary dictionaryWithObjectsAndKeys:self.textView.text,@"status",nil] httpMethod:@"POST" delegate:self];
    }
    else
    {
        NSMutableDictionary *params = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"json",@"format",self.textView.text, @"content",nil];
        [self.wbApi requestWithParams:params apiName:@"t/add" httpMethod:@"POST" delegate:self];
    }
    //    [chooseArray removeAllObjects];
    //    [friendsArray removeAllObjects];
}

#pragma mark - SinaWeiboRequest Delegate

- (void)request:(SinaWeiboRequest *)request didFailWithError:(NSError *)error
{
    
    if ([request.url hasSuffix:@"statuses/update.json"])
    {
        [self toast:error.description];
    }
}

- (void)request:(SinaWeiboRequest *)request didFinishLoadingWithResult:(id)result
{
    if ([request.url hasSuffix:@"statuses/update.json"])
    {
        NSString *errorCode = [result objectForKey:@"error_code"];
        if (errorCode)
        {
            if ([errorCode intValue] == 20012)
            {
                [self toast:@"分享文字太长了哦！"];
            }
            else
            {
                [self toast:@"分享失败"];
            }
        }
        else
        {
            [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetCredit withData:[NSDictionary dictionaryWithObjectsAndKeys:@"share",@"action", nil]];
        }
    }
    if ([request.url hasSuffix:@"friendships/friends.json"])
    {
        NSString *errorCode = [result objectForKey:@"error_code"];
        if (errorCode)
        {
            
        }
        else
        {
            NSDictionary *dic = (NSDictionary *)result;
            NSArray *array = [dic objectForKey:@"users"];
            for (NSDictionary *obj in array) {
                FriendObject *fo = [[FriendObject alloc]init];
                fo.headURL = [obj objectForKey:@"avatar_large"];
                fo.userName = [obj objectForKey:@"screen_name"];
                fo.userID = [obj objectForKey:@"screen_name"];
                [friendsArray addObject:fo];
            }
            
            if ([[dic objectForKey:@"next_cursor"]integerValue]>0) {
                [self sinaGetFriendCursor:[[dic objectForKey:@"next_cursor"]integerValue]];
            }
            else
            {
                [self randomNum];
                [self hideIndicator];
            }
        }
    }
}

#pragma mark - tencentweibo Delegate

- (void)didReceiveRawData:(NSData *)data reqNo:(int)reqno
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *dataDic = [dic objectForKey:@"data"];
    if (![dataDic objectForKey:@"info"]) {
        if (![[dic objectForKey:@"ret"]integerValue]) {
            [[RequestManager sharedManager]startRequestWithType:kRequestTypeGetCredit withData:[NSDictionary dictionaryWithObjectsAndKeys:@"share",@"action", nil]];
        }
    }
    else
    {
        NSArray *info = [dataDic objectForKey:@"info"];
        for(NSDictionary *obj in info)
        {
            FriendObject *fo = [[FriendObject alloc]init];
            fo.headURL = [obj objectForKey:@"head"];
            fo.userName = [obj objectForKey:@"nick"];
            fo.userID = [obj objectForKey:@"name"];
            [friendsArray addObject:fo];
        }
        if (![[dataDic objectForKey:@"hasnext"]integerValue]) {
            [self tencentGetFriend:++cursor];
        }
        else
        {
            [self randomNum];
            [self hideIndicator];
        }
    }
}

- (void)didFailWithError:(NSError *)error reqNo:(int)reqno
{
    [self toast:[error localizedDescription]];
}

-(void)tencentGetFriend:(int)startIndex
{
    if (self.wbApi.isAuthValid) {
        NSMutableDictionary *params = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"json",@"format",@"30", @"reqnum",[NSString stringWithFormat:@"%d",startIndex*3], @"startindex",nil];
        [self.wbApi requestWithParams:params apiName:@"friends/idollist" httpMethod:@"GET" delegate:self];
    }
    else
    {
        [self.wbApi loginWithDelegate:self andRootController:self];
    }
}

-(void)sinaGetFriendCursor:(int)next_cursor
{
    NSMutableDictionary *params = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"100",@"count",[NSString stringWithFormat:@"%d",next_cursor], @"cursor",[self getSinaWeibo].userID,@"uid",[Config shareInstance].sinaAppKey,@"source",nil];
    [[self getSinaWeibo] requestWithURL:@"friendships/friends.json"
                                 params:params
                             httpMethod:@"GET"
                               delegate:self];
    
}



-(void)randomNum
{
    for (int i = 0; i<3; i++) {
        int value = (arc4random() % [friendsArray count]) + 1;
        FriendObject *fo = [friendsArray objectAtIndex:value];
        fo.selected = YES;
        [chooseArray addObject:fo];
    }
    NSMutableString *str = [[NSMutableString alloc]init];
    for (FriendObject *obj in chooseArray) {
        [str appendString:[NSString stringWithFormat:@" @%@",obj.userID]];
    }
    NSString *contents = [NSString stringWithFormat:@"%@%@%@",self.content,self.url,str];
    self.textView.text = contents;
}

-(void)webServiceRequest:(RequestType)requestType response:(id)response userData:(id)userData originalData:(id)data
{
    if (requestType == kRequestTypeGetCredit) {
        NSString *str;
        if ([[[data objectForKey:@"data"]objectForKey:@"addcredit"]integerValue]>0) {
            str= [NSString stringWithFormat:@"获得分享币%@个",[[data objectForKey:@"data"]objectForKey:@"addcredit"]];
        }
        else
            str = nil;
        [[AppDelegate sharedAppDelegate] creditView:@"分享成功" withCredit:str];
        if (_delegate && [_delegate respondsToSelector:@selector(shareRewardsSuccess)]) {
            [_delegate shareRewardsSuccess];
        }
        [self.navigationController popViewControllerAnimated:YES];
    }
}


@end
