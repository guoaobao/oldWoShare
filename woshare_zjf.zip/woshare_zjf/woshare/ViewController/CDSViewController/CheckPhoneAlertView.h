//
//  CheckPhoneAlertView.h
//  HappyShareSE
//
//  Created by 胡 波 on 13-12-4.
//  Copyright (c) 2013年 胡 波. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CheckPhoneAlertView : UIView
@property (nonatomic,strong)IBOutlet    UIButton    *cancleButton;
@property (nonatomic,strong)IBOutlet    UIButton    *confirmButton;
@property (nonatomic,strong)IBOutlet    UITextField *inputField;
@property (nonatomic,strong)IBOutlet    UILabel     *placeholderLabel;
@property (nonatomic,strong)NSString    *phoneNumber;
@end
