//
//  WBFriendCell.h
//  HappyShareSE
//
//  Created by 胡波 on 13-12-12.
//  Copyright (c) 2013年 胡 波. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EGOImageView.h"
@interface WBFriendCell : UITableViewCell
@property (nonatomic,strong)IBOutlet EGOImageView *headView;
@property (nonatomic,strong)IBOutlet UILabel      *nameLabel;
@property (nonatomic,strong)IBOutlet UIButton     *selectedButton;
@property (nonatomic,assign)BOOL    isSelected;
@end
