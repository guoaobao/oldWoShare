//
//  GiftTableViewController.h
//  HappyShareSE
//
//  Created by 胡 波 on 13-12-3.
//  Copyright (c) 2013年 胡 波. All rights reserved.
//

#import "UIRefreshTableViewController.h"
#import "EGOImageButton.h"
#import "GiftObject.h"
@interface GiftTableViewController : UIBaseViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray  *giftArray;
}
@property (nonatomic,retain)IBOutlet    UITableView     *tableView;
@end
