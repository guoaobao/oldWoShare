//
//  ValentineViewController.m
//  HappyShareSE
//
//  Created by 胡波 on 14-2-12.
//  Copyright (c) 2014年 胡 波. All rights reserved.
//

#import "ValentineViewController.h"
#import "TKContactsMultiPickerController.h"
#import "CheckPhoneAlertView.h"

#import "EventClassResponse.h"
#import "EventResponse.h"
#import "GeeUploadParam.h"
#import "JSONKit.h"
#import "GeeUploadManager.h"
#import "SinaWeibo.h"
#import "AppDelegate.h"
#import <MobileCoreServices/UTCoreTypes.h>
#import "CoreMedia/CoreMedia.h"
#import "AVFoundation/AVFoundation.h"
#import "InfoListResponse.h"
#import "FVKit.h"

@interface ValentineViewController ()<TKContactsMultiPickerControllerDelegate>
{
    TKAddressBook   *address;
    CheckPhoneAlertView *phoneAlertView;
    MBProgressHUD *hud;
}
@end

@implementation ValentineViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        address = [[TKAddressBook alloc]init];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self initBgImage];
    [self initNavigationBar];
    [self initBackButton];
    [self initNaviDoneBtn];
    self.title = @"参加活动";
    phoneAlertView = [[[NSBundle mainBundle] loadNibNamed:@"CheckPhoneAlertView" owner:self options:nil] objectAtIndex:0];
    [phoneAlertView setFrame:CGRectMake(27, FVIF_IS_P5_ELSE(160, 110), 267, 156)];
    [self.view addSubview:phoneAlertView];
    phoneAlertView.hidden = YES;
    phoneAlertView.alpha = 0;
    [phoneAlertView.confirmButton addTarget:self action:@selector(confirmButton:) forControlEvents:UIControlEventTouchUpInside];
    [phoneAlertView.cancleButton addTarget:self action:@selector(cancleButton:) forControlEvents:UIControlEventTouchUpInside];
    [self setHidesBottomBarWhenPushed:YES];
    _videoView.placeholderImage = kPlaceholderSquareImage;
    _videoView.image = _data.coverImage;
    if (_data.infoid) {
        self.nameTextField.text = _data.oldTitle;
    }
    _phoneTextField.placeholder = [Config shareInstance].phoneplaceholder;
    _nameTextField.placeholder = [Config shareInstance].detialplaceholder;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self getGeeUploadManager].delegate = self;
    [self getSinaWeibo].delegate = self;
}

-(void)viewWillDisappear:(BOOL)animated
{
    [self getGeeUploadManager].delegate = nil;
    [self getSinaWeibo].delegate = nil;
    [super viewWillDisappear:animated];
}



//- (void)initNaviDoneBtn
//{
//    _doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
//    _doneButton.frame = CGRectMake(260, 0, 56, 44);
//    [_doneButton.titleLabel setFont: [UIFont systemFontOfSize:18.0]];
//    [_doneButton setTitle:@"赠送" forState:UIControlStateNormal];
//    [_doneButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//    [_doneButton addTarget:self action:@selector(navigationDoneButtonAction:) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:_doneButton];
//}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)sinaAction:(id)sender
{
    if (_sinaButton.isSelected) {
        [_sinaButton setSelected:NO];
    }
    else
    {
        if ([self getSinaWeibo].isAuthValid) {
            [_sinaButton setSelected:YES];
        }
        else
            [[self getSinaWeibo] logIn];
    }
}

-(IBAction)tencentAction:(id)sender
{
    if (_tencentButton.isSelected) {
        [_tencentButton setSelected:NO];
    }
    else{
        
        if ([self.wbApi isAuthValid])
        {
            [_tencentButton setSelected:YES];
        }
        else
        {
            [self.wbApi loginWithDelegate:self andRootController:self];
        }
    }
}

-(void)confirmButton:(id)sender
{
    NSString *phoneStr = [phoneAlertView.inputField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if ([phoneStr length] == 0 || ![NSString JudgmentMobilePhoneNumber:phoneStr])
    {
        [self showTips:kBundleName message:@"请输入手机号码"];
    }
    else
    {
        phoneNumber = phoneStr;
        self.phoneTextField.text = phoneNumber;
        [self dissmissAlertAction];
    }
}

-(void)cancleButton:(id)sender
{
    [self dissmissAlertAction];
}

-(void)showAlertAction
{
    [self.view bringSubviewToFront:underView];
    [self.view bringSubviewToFront:phoneAlertView];
    phoneAlertView.phoneNumber = phoneNumber;
    phoneAlertView.hidden = NO;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationDelegate:self];
    phoneAlertView.alpha = 1;
    [UIView setAnimationDidStopSelector:@selector(showUnderView)];
    [UIView commitAnimations];
}

-(void)dissmissAlertAction
{
    [phoneAlertView.inputField resignFirstResponder];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationDelegate:self];
    phoneAlertView.alpha = 0;
    [UIView setAnimationDidStopSelector:@selector(hideUnderView)];
    [UIView commitAnimations];
}

-(void)showUnderView
{
    underView.hidden = NO;
}

-(void)hideUnderView
{
    underView.hidden = YES;
    phoneAlertView.hidden = YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField.tag == 23909) {
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"请选择"
                                                                 delegate:self
                                                        cancelButtonTitle:@"取消"
                                                   destructiveButtonTitle:nil
                                                        otherButtonTitles:@"通讯录选取",@"手动输入", nil];
        [actionSheet showInView:self.view];
        return NO;
    }
    else if (textField.tag == 23908)
    {
        if ([self.nameTextField.text length]>0 && _data.infoid) {
            return NO;
        }
    }
    return YES;
}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex)
    {
        case 0:
        {
            [self initSMS];
            if (!accessGranted) {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"授权提示"
                                                                message:LJSMSALERTTEXT
                                                               delegate:nil
                                                      cancelButtonTitle:nil
                                                      otherButtonTitles:@"确定", nil];
                alert.tag = 100202;
                [alert show];
            }
            else
            {
                TKContactsMultiPickerController *controller = [[TKContactsMultiPickerController alloc] initWithNibName:@"TKContactsMultiPickerController" bundle:nil] ;
                controller.delegate = self;
                UIBaseNavigationController *navController = [[UIBaseNavigationController alloc] initWithRootViewController:controller];
                [self presentViewController:navController animated:YES completion:nil];
            }
        }
            break;
        case 1:
        {
            [self showAlertAction];
        }
            break;
        default:
            break;
    }
}

#pragma mark - TKContactsMultiPickerControllerDelegate

- (void)contactsMultiPickerController:(TKContactsMultiPickerController*)picker didFinishPickingDataWithInfo:(NSArray*)data
{
    [self dismissViewControllerAnimated:YES completion:nil];
    for (id obj in data) {
        if ([obj isKindOfClass:[TKAddressBook class]]) {
            TKAddressBook *content = (TKAddressBook*)obj;
            if (![content.tel isEqualToString:address.tel]) {
                address = content;
            }
            phoneNumber = address.tel;
            self.phoneTextField.text = address.tel;
        }
    }
}

- (void)contactsMultiPickerControllerDidCancel:(TKContactsMultiPickerController*)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)navigationDoneButtonAction:(id)sender
{
    [self.nameTextField resignFirstResponder];
    if ([self.nameTextField.text isEqualToString:@"添加一个有吸引力的标题"] || self.nameTextField.text.length == 0)
    {
        [self toast:@"标题不能为空"];
        return;
    }
    
    if ([RequestManager sharedManager].currentReachabilityStatus == NotReachable)
    {
        [self toast:@"没有可用网络"];
        return;
    }
    [self uploadMessage];
}

-(void)uploadMessage
{
    GeeUploadParam* param = [GeeUploadParam alloc];
    param.uid = [RequestManager sharedManager].userInfo.uid;
    param.brief = @"";
    NSMutableArray *array = [[NSMutableArray alloc]initWithCapacity:0];
    param.fileinfos =array;
    param.title = self.nameTextField.text;
    GeeUploadFileInfo *info = [[GeeUploadFileInfo alloc]init];
    info.filename = _data.fileName;
    info.image = [UIImage imageWithData:_data.fileData];
    info.videourl = _data.videoURL;
    [param.fileinfos addObject:info];
    EventResponse *event = self.event;
    if (event)
    {
        param.eventid = event.eventid;
        param.eventtitle = event.title;
    }
    else
    {
        param.eventid = @"";
        param.eventtitle = @"";
    }
    if (self.sinaButton.selected)
    {
        param.sinaShare = YES;
    }
    else
    {
        param.sinaShare = NO;
    }
    
    if ([[Config shareInstance].vdUploadData.infoid length]==0) {
        [[self getGeeUploadManager] addTask:param];
        if (!hud)
        {
            MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:[AppDelegate sharedAppDelegate].window];
            hud = HUD;
            hud.mode = MBProgressHUDModeAnnularDeterminate;
        }
        [self.view addSubview:hud];
        [hud show:YES];
    }
    else
    {
        [self orderProduct];
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag == 101010)
    {
        if (buttonIndex == 1) {
            [self uploadMessage];
        }
    }
}

//您的好友%参与了#越爱越分享#活动，拍摄了Ta爱的视频，并委托我们送达给您，快去看看Ta爱的宣言吧！#越爱越分享，集赞赢大奖#视频地址：
- (void)orderProduct
{
    [self showIndicator];
//    NSString *time = [[Config shareInstance].smsShareWords copy];
//    NSMutableString *string = [[NSMutableString alloc]initWithString:time];
//    NSString *time1 = [string stringByReplacingOccurrencesOfString:@"%" withString:[RequestManager sharedManager].userInfo.username];
//    NSString *content = [NSString stringWithFormat:@"%@%@",time1,[NSString stringWithFormat:@"%@%@",[Config shareInstance].sinaShareInfoLink,[Config shareInstance].vdUploadData.infoid]];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:phoneNumber,@"bmobile",[Config shareInstance].vdUploadData.infoid,@"infoid",[Config shareInstance].cdsEventID,@"eventid", nil];
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeJoinEvent withData:dic];
}

- (void)addInfo:(NSArray*)nsids
{
    NSString *ft;
    if ([nsids count]<=6)
    {
        if ([nsids count]==1) {
            ft = [NSString stringWithFormat:@"%d",kInfoTypeOther];
        }
        else
        {
            ft = [NSString stringWithFormat:@"%d",kInfoTypeTheme];
        }
    }
    else if ([nsids count]>6)
    {
        ft = [NSString stringWithFormat:@"%d",kInfoTypePicture];
    }
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:self.nameTextField.text,@"title",self.nameTextField.text,@"brief",nsids,@"nsids", ft,@"ft",self.event==nil?@"":self.event.eventid,@"eventid",nil];
    [[RequestManager sharedManager]startRequestWithType:kRequestTypeAddInfo withData:dic];
}

-(void)setProgress:(NSString*)progress
{
    if (hud) {
        hud.progress = [progress floatValue];
    }
}

-(void)setHudHidden
{
    if (hud) {
        [hud hide:YES];
    }
}

#pragma mark - GeeUploadManager Delegate

- (void)progressCallback:(IOSProgressCallbackData*)obj
{
    [self performSelectorOnMainThread:@selector(setProgress:) withObject:[NSString stringWithFormat:@"%lf",obj.per] waitUntilDone:NO];
}

- (void)uploadCompleteCallback:(GeeUploadResult *)gr obj:(IGeeUploadData *)obj
{
    NSMutableArray *nsids = [[NSMutableArray alloc]initWithCapacity:0];
    for (GeeUploadFileInfo *info in obj.param.fileinfos) {
        if ([info.nsid length]>0) {
            [nsids addObject:info.nsid];
        }
    }
    [self performSelectorOnMainThread:@selector(setHudHidden) withObject:nil waitUntilDone:NO];
    if (gr.result == 1) {
        
        [self performSelectorOnMainThread:@selector(addInfo:) withObject:nsids waitUntilDone:YES];
    }
    else
    {
        [self performSelectorOnMainThread:@selector(toast:) withObject:[gr toString] waitUntilDone:YES];
    }
}

#pragma mark request callback
-(void)webServiceRequest:(RequestType)requestType response:(id)response userData:(id)userData originalData:(id)data
{
    if (requestType == kRequestTypeAddInfo) {
        [Config shareInstance].vdUploadData.infoid = [(NSDictionary*)response objectForKey:@"_id"];
        [Config shareInstance].vdUploadData.oldTitle = self.nameTextField.text;
        if (self.sinaButton.selected) {
            [self sinaShareAction];
        }
        if (self.tencentButton.selected) {
            [self tencnetShareAction];
        }
        [self toast:@"您的爱已宣告成功！"];
        [self orderProduct];
    }
    else if (requestType == kRequestTypeJoinEvent)
    {
        [self hideIndicator];
        [self.navigationController popToViewController:[Config shareInstance].vc animated:YES];
    }
}

-(void)webServiceRequest:(RequestType)requestType errorString:(NSString*)errorString userData:(id)userData
{
    [self hideIndicator];
    if (requestType == kRequestTypeAutoLogin) {
        
    }
    else if (requestType == kRequestTypeJoinEvent)
    {
        [self hideIndicator];
        [self.navigationController popToViewController:[Config shareInstance].vc animated:YES];
    }
    else
    {
        [self toast:errorString];
    }
}

-(void)webServiceRequest:(RequestType)requestType errorData:(NSDictionary*)errorData userData:(id)userData
{
    [self hideIndicator];
}


#pragma mark - share
- (void)sinaShareAction
{
    // post image status
    SinaWeibo *sinaweibo = [self getSinaWeibo];
    
    if ([sinaweibo isAuthValid])
    {
        [sinaweibo requestWithURL:@"statuses/upload.json"
                           params:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [NSString stringWithFormat:@"%@%@",[Config shareInstance].snsShareWords,[NSString stringWithFormat:@"%@%@",[Config shareInstance].sinaShareInfoLink,[Config shareInstance].vdUploadData.infoid]] , @"status",
                                   self.videoView.image, @"pic", nil]
                       httpMethod:@"POST"
                         delegate:nil];
    }
    else
    {
        [sinaweibo logIn];
    }
}

- (void)tencnetShareAction
{
    if ([self.wbApi isAuthValid])
    {
        UIImage *pic = self.videoView.image;
        NSMutableDictionary *params = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"json",@"format",
                                       [NSString stringWithFormat:@"%@%@",[Config shareInstance].snsShareWords,[NSString stringWithFormat:@"%@%@",[Config shareInstance].sinaShareInfoLink,[Config shareInstance].vdUploadData.infoid]], @"content",
                                       pic, @"pic",
                                       nil];
        [self.wbApi requestWithParams:params apiName:@"t/add_pic" httpMethod:@"POST" delegate:nil];
    }
    else
    {
        [self.wbApi loginWithDelegate:self andRootController:self];
    }
}

#pragma mark SinaWeiboAuthDelegate

- (void)sinaweiboDidLogIn:(SinaWeibo *)sinaweibo
{
    FVLog(@"sinaweiboDidLogIn userID = %@ accesstoken = %@ expirationDate = %@ refresh_token = %@", sinaweibo.userID, sinaweibo.accessToken, sinaweibo.expirationDate,sinaweibo.refreshToken);
    [self.sinaButton setSelected:YES];
}

- (void)sinaweibo:(SinaWeibo *)sinaweibo logInDidFailWithError:(NSError *)error
{
    FVLog(@"sinaweibo logInDidFailWithError %@", error);
    [self toast:@"新浪微博授权失败"];
}

#pragma mark - SinaWeiboRequest Delegate

- (void)request:(SinaWeiboRequest *)request didFailWithError:(NSError *)error
{
    if ([request.url hasSuffix:@"statuses/update.json"])
    {
        [self toast:error.description];
    }
}

- (void)request:(SinaWeiboRequest *)request didFinishLoadingWithResult:(id)result
{
    if ([request.url hasSuffix:@"statuses/update.json"])
    {
        NSString *errorCode = [result objectForKey:@"error_code"];
        if (errorCode)
        {
            if ([errorCode intValue] == 20012)
            {
                [self toast:@"分享文字太长了哦！"];
            }
            else
            {
                [self toast:@"分享失败"];
            }
        }
        else
        {
            [self toast:@"分享成功 "];
            //            if (_delegate && [_delegate respondsToSelector:@selector(shareRewardsSuccess)]) {
            //                [_delegate shareRewardsSuccess];
            //            }
            //            [self.navigationController popViewControllerAnimated:YES];
        }
    }
}

#pragma mark WeiboAuthDelegate

- (void)DidAuthRefreshed:(WeiboApi *)wbapi_
{
    [self.tencentButton setSelected:YES];
}

- (void)DidAuthRefreshFail:(NSError *)error
{
    FVLog(@"tencent weibo error = %@\n",[error localizedDescription]);
    [self toast:@"腾讯微博授权失败"];
}

- (void)DidAuthFinished:(WeiboApi *)wbapi_
{
    [self.tencentButton setSelected:YES];
}

- (void)DidAuthCanceled:(WeiboApi *)wbapi_
{
    
}

- (void)DidAuthFailWithError:(NSError *)error
{
    FVLog(@"tencent weibo error = %@\n",[error localizedDescription]);
    [self toast:@"腾讯微博授权失败"];
}

#pragma mark - tencentweibo Delegate

- (void)didReceiveRawData:(NSData *)data reqNo:(int)reqno
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *dataDic = [dic objectForKey:@"data"];
    if (![dataDic objectForKey:@"info"]) {
        if (![[dic objectForKey:@"ret"]integerValue]) {
            [self toast:@"分享成功 "];
            //            if (_delegate && [_delegate respondsToSelector:@selector(shareRewardsSuccess)]) {
            //                [_delegate shareRewardsSuccess];
            //            }
            //            [self.navigationController popViewControllerAnimated:YES];
        }
    }
}

- (void)didFailWithError:(NSError *)error reqNo:(int)reqno
{
    [self toast:[error localizedDescription]];
}





@end

