//
//  CDSViewController.h
//  HappyShareSE
//
//  Created by 胡 波 on 13-12-3.
//  Copyright (c) 2013年 胡 波. All rights reserved.
//

#import "UIBaseViewController.h"
#import "UploadData.h"
#import "GiftObject.h"
#import "EGOImageView.h"
@interface CDSViewController : UIBaseViewController<GeeUploadDelegate,WeiboRequestDelegate,SinaWeiboDelegate>
{
    NSString *phoneNumber;
    
}
@property (nonatomic,strong)IBOutlet    UITextField *phoneTextField;
@property (nonatomic,strong)IBOutlet    UITextField *nameTextField;
@property (nonatomic,strong)IBOutlet    EGOImageView *videoView;
@property (nonatomic,strong)IBOutlet    UIButton *sinaButton;
@property (nonatomic,strong)IBOutlet    UIButton *tencentButton;
@property (nonatomic,strong)UploadData  *data;
@property (nonatomic,strong)GiftObject  *gift;
@property (nonatomic,strong)EventResponse   *event;
-(IBAction)sinaAction:(id)sender;
-(IBAction)tencentAction:(id)sender;
@end
