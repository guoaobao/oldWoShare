//
//  GCAppDelegate.h
//  woshare
//
//  Created by 胡波 on 14-2-21.
//  Copyright (c) 2014年 胡波. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "IntroView.h"
#import "UIBaseNavigationController.h"
#import "PPRevealSideViewController.h"
#import "Request/RequestManager.h"
#import "GeeUploadManager.h"
#import "AKTabBarController.h"

#import "CreditDayView.h"


#import "SinaWeibo.h"
#import "WXManager.h"
#import <TencentOpenAPI/TencentOAuth.h>
#import "WeiboApi.h"

#define kWindowFrame ((AppDelegate *)[UIApplication sharedApplication].delegate).window.frame

@interface AppDelegate : UIResponder <UIApplicationDelegate,UIAlertViewDelegate,SinaWeiboDelegate,SinaWeiboRequestDelegate,GeeUploadDelegate,RequestManagerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,WXApiDelegate,TencentSessionDelegate,WeiboRequestDelegate,WeiboAuthDelegate,IntroDelegate>
{
    UILabel *text;
    CreditDayView *cdv;
}
@property (strong, nonatomic) MBProgressHUD                     *HUD;
@property (strong, nonatomic) UIWindow                          *window;
@property (strong, nonatomic) UIBaseNavigationController        *navigationController;
@property (strong, nonatomic) AKTabBarController                *tabbar;
@property (strong, nonatomic) PPRevealSideViewController                  *slideview;
//push userinfo block
@property (retain, nonatomic) NSDictionary              *pushUserInfo;
@property (assign, nonatomic) BOOL                      hasPush;

@property (strong, nonatomic) GeeUploadManager          *geeUploadManager;

@property (assign, nonatomic) int                       indexPage;
@property (strong, nonatomic) SinaWeibo                 *sinaWeibo;
@property (strong, nonatomic) TencentOAuth              *tencentOAuth;
@property (strong, nonatomic) WeiboApi                  *weiboApi;
@property (strong ,nonatomic) NSMutableArray            *bootArray;
@property (strong ,nonatomic) NSMutableArray            *bootViewArray;
+(AppDelegate*)sharedAppDelegate;

- (kUpdateType)checkVersion;
- (void)showMustUpdateAlert;
- (void)showChoiceUpdateAlert;

-(void)showHelp;

- (void)creditView:(NSString *)string withCredit:(NSString *)credit;

- (void)showIndicator;
- (void)hideIndicator;

-(void)loginQzone:(id)owner;
-(void)logOutQzone:(id)owner;
-(void)getQQUserInfo:(id)owner;

-(void)showLoginFrom:(id)owner;
-(BOOL)determineTheAddressBookUpload;

-(void)handlePushMessage:(NSDictionary*)userInfo;
@end
